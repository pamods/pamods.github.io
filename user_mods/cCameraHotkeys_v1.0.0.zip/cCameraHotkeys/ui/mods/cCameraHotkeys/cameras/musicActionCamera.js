/**
 * All cameras must have the following:
 *	function startCameraMode()
 *	function endCameraMode()
 *	var inCameraMode
 **/

cCameraHotkeys.cameras.musicActionCamera = (function () {
	var musicActionCamera = {};

	musicActionCamera.inCameraMode = false;
	musicActionCamera.cameraModeTimer;
	musicActionCamera.rollDirection = 1;
	musicActionCamera.savedVolume = parseInt(model.settings().music_volume);
	musicActionCamera.currentVolume = parseInt(model.settings().music_volume);

	musicActionCamera.startCameraMode = function() {
		musicActionCamera.inCameraMode = true;
		musicActionCamera.rollDirection *= -1;

		cCameraHotkeys.handleDisablePoleLock();

		api.game.toggleUI();
		api.arch.toggleAR();
		api.camera.changeKeyPanSpeed(-.97);

		musicActionCamera.smoothMoveCamera();
	};

	musicActionCamera.endCameraMode = function() {
		musicActionCamera.inCameraMode = false;
		clearTimeout(musicActionCamera.cameraModeTimer);
	};

	musicActionCamera.smoothMoveCamera = function() {
		if(!musicActionCamera.inCameraMode) {
			api.game.toggleUI();
			api.arch.toggleAR();

			cCameraHotkeys.handleEnablePoleLock();

			musicActionCamera.smoothMoveCamera_endMusic(musicActionCamera.currentVolume, 2);

			api.camera.changeKeyPanSpeed(.97);
		} else {
			api.camera.zoom(.02);

				console.log(musicActionCamera.currentVolume);
			if(musicActionCamera.currentVolume < 100) {
				engine.call("set_volume", "music", (musicActionCamera.currentVolume+2)/100);
				musicActionCamera.currentVolume += 2;
			}

			engine.call("camera.roll", .1*musicActionCamera.rollDirection).then(function() {
				musicActionCamera.smoothMoveCamera();
			});
		}
	};

	musicActionCamera.smoothMoveCamera_endMusic = function(currentVolume, increment) {
		if(currentVolume <= musicActionCamera.savedVolume+increment) {
			engine.call("set_volume", "music", (musicActionCamera.savedVolume)/100);
		} else {
			engine.call("set_volume", "music", (currentVolume-increment)/100).then(function() {
				musicActionCamera.smoothMoveCamera_endMusic(currentVolume-increment, increment);
			});
			musicActionCamera.currentVolume -= increment;
		}
	}

	// Register with the mod
	var keyBind = default_keybinds["eXodus eSports Camera Modes"]["Music Action Camera"];
	cCameraHotkeys.keyMapping.cameras[keyBind] = "musicActionCamera";

	return musicActionCamera;
})();