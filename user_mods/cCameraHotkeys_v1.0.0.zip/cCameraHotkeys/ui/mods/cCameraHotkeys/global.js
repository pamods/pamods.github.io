(function () {
    action_sets["eXodus eSports Camera Modes"] = {};

    action_sets["eXodus eSports Camera Modes"]["Action Camera"] = function (event) { };
    action_sets["eXodus eSports Camera Modes"]["Slow Motion Replay"] = function (event) { };
    action_sets["eXodus eSports Camera Modes"]["PiP Action Camera"] = function (event) { };
    action_sets["eXodus eSports Camera Modes"]["Music Action Camera"] = function (event) { };
    action_sets["eXodus eSports Camera Modes"]["Smooth Zoom In"] = function (event) { };
    action_sets["eXodus eSports Camera Modes"]["Smooth Zoom Out"] = function (event) { };

    default_keybinds["eXodus eSports Camera Modes"] = {};

    default_keybinds["eXodus eSports Camera Modes"]["Action Camera"] = 'alt+z';
	default_keybinds["eXodus eSports Camera Modes"]["Slow Motion Replay"] = 'alt+x';
    default_keybinds["eXodus eSports Camera Modes"]["PiP Action Camera"] = 'alt+c';
    default_keybinds["eXodus eSports Camera Modes"]["Music Action Camera"] = 'alt+v';
    default_keybinds["eXodus eSports Camera Modes"]["Smooth Zoom In"] = 'pageup';
    default_keybinds["eXodus eSports Camera Modes"]["Smooth Zoom Out"] = 'pagedown';

})();
