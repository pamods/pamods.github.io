//load html dynamically
function loadAnchorHtmlTemplate(element, url) {
    element.load(url, function () {
        console.log("Loading html " + url);
        ko.applyBindings(model, element.get(0));
    });
}

var settings = decode(localStorage.settings);

//debugger;
model.bAnchorButtonsAmount = ko.observable(parseInt(settings.bAnchorButtonsAmount));
model.bAnchorButtonsUnitsAmount = ko.observable(parseInt(settings.bAnchorButtonsUnitsAmount));
//forgetFramePosition('bAnchorButtons_info_frame');

model.bAnchorButtonsFlat = ko.computed(function () {
    if (settings.bAnchorButtonsStyle == "FLAT") {
        return true;
    }
    else {
        return false;
    }
});

model.bAnchorButtonsAngle = ko.computed(function () {
    if (settings.bAnchorButtonsStyle == "ANGLE") {
        return true;
    }
    else {
        return false;
    }
});

model.bAnchorButtonsVisible = ko.computed(function () {
    if (model.bAnchorButtonsAmount() > 0) {
		model.bAnchorButtonsArr = ko.observableArray([]);
		for (var i = 0; i < model.bAnchorButtonsAmount(); i++)	{
				model.bAnchorButtonsArr().push(i+1);
		}
        return true;
    }
    else {
        return false;
    }
});

model.bAnchorButtonsUnitsVisible = ko.computed(function () {
    if (model.bAnchorButtonsUnitsAmount() > 0) {
		model.bAnchorButtonsUnitsArr = ko.observableArray([]);
		for (var i = 0; i < model.bAnchorButtonsUnitsAmount(); i++)	{
			model.bAnchorButtonsUnitsArr().push(i+1);
		}
        return true;
    }
    else {
        return false;
    }
});

createFloatingFrame('bAnchorButtons_info_frame', 475, 70, {'offset': 'topCenter', 'top':42});
loadAnchorHtmlTemplate($('#bAnchorButtons_info_frame_content'), '../../mods/bAnchorButtons/live_game/bAnchorButtons.html');