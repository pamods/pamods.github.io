model.addSetting_DropDown('Style','bAnchorButtonsStyle','UI',["FLAT","ANGLE"],0,'Anchor Buttons');
model.addSetting_Slider('Number of Anchor Buttons','bAnchorButtonsAmount','UI',1,8,8,'Anchor Buttons');
model.addSetting_Slider('Number of Unit Group Buttons <span style="color:red">(experimental!)</span>','bAnchorButtonsUnitsAmount','UI',0,8,0,'Anchor Buttons');
model.registerFrameSetting('bAnchorButtons_info_frame', 'Anchor Buttons', true);