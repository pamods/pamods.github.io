initialSettingValue('bAnchorButtonsStyle','FLAT');
initialSettingValue('bAnchorButtonsAmount',1);
initialSettingValue('bAnchorButtonsUnitsAmount',0);