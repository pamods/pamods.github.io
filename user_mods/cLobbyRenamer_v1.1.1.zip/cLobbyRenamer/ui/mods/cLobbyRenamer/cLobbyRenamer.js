(function() {
	model.lobbyName = ko.observable(model.system().name);
	$("#main .header").html("<div id=\"lobby_name_container\"><label for=\"lobby_name\">Lobby Name</label><input id=\"lobby_name\" data-bind=\"value: model.lobbyName, valueUpdate: 'afterkeydown', enable: isGameCreator\" type=\"text\" /></div>");
})();

$("#lobby_name").on("keyup", function() {
	var system = model.system();
	system.name = model.lobbyName();
	model.system(system);
	model.send_message('modify_system', model.fixupPlanetConfig(model.system()));
});