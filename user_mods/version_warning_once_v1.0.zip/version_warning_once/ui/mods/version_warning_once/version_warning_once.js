model.ubernetBuildVersion = ko.observable().extend({ local: 'ubernet_build_version' });
