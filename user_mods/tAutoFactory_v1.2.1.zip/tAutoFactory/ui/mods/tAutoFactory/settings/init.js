model.addSetting_Slider('Metal % threshold', 'tAutoFactory_s_metal', 'UI', 1, 99, 80, 'Auto Factory');
model.addSetting_Slider('Energy % threshold', 'tAutoFactory_s_energy', 'UI', 1, 99, 80, 'Auto Factory');

model.addSetting_DropDown('T1 BOT', 'tAutoFactory_dd_t1_bot', 'UI', ['FABBER', 'COMBAT FABBER', 'STINGER', 'DOX', 'NONE'], 3, 'Auto Factory');
model.addSetting_DropDown('T2 BOT', 'tAutoFactory_dd_t2_bot', 'UI', ['ADV FABBER', 'ADV COMBAT FABBER', 'GIL-E', 'SLAMMER', 'NONE'], 3, 'Auto Factory');

model.addSetting_DropDown('T1 VEHICLE', 'tAutoFactory_dd_t1_veh', 'UI', ['FABBER', 'SKITTER', 'INFERNO', 'SPINNER', 'POUNDER', 'NONE'], 4, 'Auto Factory');
model.addSetting_DropDown('T2 VEHICLE', 'tAutoFactory_dd_t2_veh', 'UI', ['ADV FABBER', 'VANGUARD', 'SHELLER', 'LEVELER', 'NONE'], 3, 'Auto Factory');

model.addSetting_DropDown('T1 AIR', 'tAutoFactory_dd_t1_air', 'UI', ['FABBER', 'FIREFLY', 'HUMMINGBIRD', 'BUMBLEBEE', 'NONE'], 2, 'Auto Factory');
model.addSetting_DropDown('T2 AIR', 'tAutoFactory_dd_t2_air', 'UI', ['ADV FABBER', 'GUNSHIP', 'PEREGRINE', 'HORNET', 'NONE'], 2, 'Auto Factory');

model.addSetting_DropDown('T1 NAVAL', 'tAutoFactory_dd_t1_nav', 'UI', ['FABBER', 'SUN FISH', 'NARWHAL', 'BLUEBOTTLE', 'NONE'], 3, 'Auto Factory');
model.addSetting_DropDown('T2 NAVAL', 'tAutoFactory_dd_t2_nav', 'UI', ['ADV FABBER', 'LEVIATHAN', 'STINGRAY', 'NONE'], 1, 'Auto Factory');

model.addSetting_DropDown('ORBITAL', 'tAutoFactory_dd_t1_orb', 'UI', ['FABBER', 'ANCHOR', 'ASTRAEUS', 'RADAR SATELLITE', 'NONE'], 0, 'Auto Factory');

model.addSetting_DropDown('NUKE LAUNCHER', 'tAutoFactory_dd_t1_nuk', 'UI', ['NUKE', 'NONE'], 1, 'Auto Factory');
model.addSetting_DropDown('ANTI-NUKE LAUNCHER', 'tAutoFactory_dd_t1_ank', 'UI', ['ANTI-NUKE', 'NONE'], 1, 'Auto Factory');
