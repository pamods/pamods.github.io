wEconomyGraphs
==============

A PA mod for showing a live visual representation of economy history.
