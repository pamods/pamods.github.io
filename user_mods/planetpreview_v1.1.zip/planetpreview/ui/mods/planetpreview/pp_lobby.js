/* VARIABLES
------------------------------------ */
var $pp_lobbydivplanettable = $( ".div_planet_selector_tbl" );

/* FUNCTIONS
------------------------------------ */
model.pp_planetBiomeString = function (value) {
	return value + " - ";
	}

model.pp_planetDiameterString = function (value) {
	return (2 * value) + "m";
	}

model.pp_planetRadiusString = function (value) {
	return "Radius: " + value + "m";
	}

model.pp_planetSeedString = function (value) {
	return "Seed # " + value;
	}

model.pp_planetBiomeScaleString = function (value) {
	return "Biome Scale: " + value;
	}

model.pp_planetHeightRangeString = function (value) {
	return "Height Range: " + value;
	}

model.pp_planetWaterHeightString = function (value) {
	return "Water Height: " + value;
	}

model.pp_planetTemperatureString = function (value) {
	return "Temperature: " + value;
	}

/* INNER HTML
------------------------------------ */
var $pp_lobby_planet_tbl = $( '<table class="div_planet_selector_tbl"> \
	<tbody> \
		<tr> \
			<td> \
				<img style="margin-right: 8px;" height="56px" width="56px" data-bind="attr: { src: model.imageSourceForPlanet(primaryPlanet()) }" /> \
			</td> \
			<td> \
				<div class="input_label">STARTING PLANET: </div> \
				<div class="input_field_static" style="text-transform: uppercase;" data-bind="text: primaryPlanet().name"></div> \
				<div> \
						<span class="input_field_static">BIOME: </span> \
						<span class="input_field_static" style="text-transform:uppercase;" data-bind="text: model.pp_planetBiomeString(primaryPlanet().biome)"></span> \
						<span class="input_field_static" style="text-transform:uppercase;" data-bind="text: model.pp_planetDiameterString(primaryPlanet().radius)"></span> \
				</div> \
			</td> \
		</tr> \
		<tr> \
			<td> \
				<a href="#" class="text_link_btn" style="font-size:0.7em" onClick="$( this ).parent().next().children().show(); $( this ).next().show(); $( this ).hide();" data-bind="click_sound:' + "'default', rollover_sound: 'default'" + '">Show Details</a> \
				<a href="#" class="text_link_btn" style="font-size:0.7em;display:none;" onClick="$( this ).parent().next().children().hide(); $( this ).prev().show(); $( this ).hide();" data-bind="click_sound:' + "'default', rollover_sound: 'default'" + '">Hide Details</a> \
			</td> \
			<td> \
				<div style="display:none;line-height:0.75em;margin-bottom:0.5em;"> \
					<span class="input_field_static" style="text-transform:uppercase;" data-bind="text: model.pp_planetSeedString(primaryPlanet().seed)"></span> \
					<br> \
					<span class="input_field_static" style="text-transform:uppercase;" data-bind="text: model.pp_planetRadiusString(primaryPlanet().radius)"></span> \
					<br> \
					<span class="input_field_static" style="text-transform:uppercase;" data-bind="text: model.pp_planetBiomeScaleString(primaryPlanet().biomeScale)"></span> \
					<br> \
					<span class="input_field_static" style="text-transform:uppercase;" data-bind="text: model.pp_planetHeightRangeString(primaryPlanet().heightRange)"></span> \
					<br> \
					<span class="input_field_static" style="text-transform:uppercase;" data-bind="text: model.pp_planetWaterHeightString(primaryPlanet().waterHeight)"></span> \
					<br> \
					<span class="input_field_static" style="text-transform:uppercase;" data-bind="text: model.pp_planetTemperatureString(primaryPlanet().temperature)"></span> \
					<br> \
				</div> \
			</td> \
		</tr> \
	</tbody> \
</table>' );

/* MODIFY DOM
------------------------------------ */
$( $pp_lobbydivplanettable ).replaceWith( $pp_lobby_planet_tbl );