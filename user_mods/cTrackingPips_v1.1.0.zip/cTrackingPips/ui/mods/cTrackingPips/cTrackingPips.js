var cTrackingPips_trackingPips = [];

(function() {
	// Get the hotkey from settings.
	initialSettingValue("cTrackingPips_hotkey", "ctrl+t");
	var settings = decode(localStorage.settings);
	var cTrackingPips_hotkey = settings["cTrackingPips_hotkey"];

	var selectionCounter = 9000;

	var trackedIds = [];


	var selectionResult;

	// Try to get the selectionResult (Which has the unit ids) before it somehow gets magically deleted.
	api.Holodeck.prototype.selectAt = function(option, x,y, offset) {
		var _selectAt = engine.call('holodeck.selectAt', this.id, option, x, y, offset);
		delete selectionResult;

		_selectAt.then(function() {
			selectionResult = $.parseJSON(this.result).selectionResult;
		});

		return _selectAt;
	};

	alertsManager.addListener(function(payload) {
		for (var i = 0; i < payload.list.length; i++) {
			var notice = payload.list[i];
			if (trackedIds[notice.id]) {
				var pipId = trackedIds[notice.id];
				flashAlert("#cTrackingPip_" + pipId);
			}
		}
	});

	function flashAlert(element) {
		$(element).stop().animate({
				backgroundColor: "rgba(255,0,0,.5)"
			}, 250).animate({
				backgroundColor: "transparent"
			}, 250).animate({
				backgroundColor: "rgba(255,0,0,.5)"
			}, 250).animate({
				backgroundColor: "transparent"
			}, 250).animate({
				backgroundColor: "rgba(255,0,0,.5)"
			}, 250).animate({
				backgroundColor: "transparent"
		}, 250);
	}

	Mousetrap.bind(cTrackingPips_hotkey, function() {
		// Don't try to track if nothing is selected.
		if(!model.selection())
			return false;

		// Create a unique id for the pip
		var pipId = selectionCounter++;

		// Insert the new tracking pip
		var trackingPip = $("body").append("<div id=\"cTrackingPip_" + pipId + "\" class=\"cTrackingPip_cont\"><holodeck no-focus class=\"cTrackingPip\"></holodeck></div>");

		// Register the new holodeck with the engine
		trackingPip = new api.Holodeck($("#cTrackingPip_" + pipId + " holodeck"), {}, function() {
			cTrackingPips_trackingPips[pipId] = trackingPip;

			// Remember the selection
			api.select.captureGroup(pipId);

			// Get the selected unit ids
			var sel = model.selection().selectionResult;
			if(!sel)
				sel = selectionResult;

			// Try to add an event listener for the units. Not really well-supported for more than one unit.
			if(sel) {
				for (var i = 0; i < sel.length; i++) {
					trackedIds[sel[i]] = pipId;
				}
			}

			// Start the tracking
			trackingPip.focus();
			api.camera.track(true);
			model.holodeck.focus();

			// Keeps them from opening directly on top of each other
			var documentHeight = $(document).height();
			var maxStacked = Math.floor((277 + documentHeight) / 327);
			var count = $(".cTrackingPip_cont").length - 1;
			var _left = 5 + Math.floor(count / maxStacked) * 300;
			var _top = 50 + (count % maxStacked) * 327;

			// Make it draggable
			createFloatingFrame("cTrackingPip_" + pipId, 0, 0, {
				"rememberPosition" : false,
				"left": _left,
				"top": _top
			});

			// Add a close button
			$("#cTrackingPip_" + pipId).append("<div class=\"cTrackingPip_closeButton cTrackingPip_button\" onclick=\"$(this).closest('.cTrackingPip_cont').remove();\">X</div>");

			// Add a zoom button
			$("#cTrackingPip_" + pipId).append("<div class=\"cTrackingPip_zoomInButton cTrackingPip_zoomButton cTrackingPip_button\" onclick=\"cTrackingPip_toggleZoom(this);\"></div>");

			// Click on a tracking pip to center the main view and select the unit
			$("#cTrackingPip_" + pipId + ", #cTrackingPip_" + pipId + " holodeck").on("click", function() {
				var thisPipId = $(this).attr("id")
				thisPipId = parseInt(thisPipId.substring(thisPipId.indexOf('_') + 1, thisPipId.length));
				model.holodeck.copyCamera(trackingPip);
				api.select.recallGroup(thisPipId);
			}).children().click(function(e) {
  				return false;
			});

			// Allocate more resources to drawing the pip so that it can be moved around more smoothly.
			var endAnimation;

			$("#cTrackingPip_" + pipId).mousedown(function() {
				endAnimation = trackingPip.beginAnimation();
			});

			$("#cTrackingPip_" + pipId).mouseup(function() {
				endAnimation();
			});
		});
	});
}());

function cTrackingPip_toggleZoom(element) {
	var zoomState = $(element).hasClass("cTrackingPip_zoomInButton") ? "zoomedOut" : "zoomedIn" ;

	var container_element = $(element).closest('.cTrackingPip_cont');
	var thisPipId = $(container_element).attr("id");
	thisPipId = parseInt(thisPipId.substring(thisPipId.indexOf('_') + 1, thisPipId.length));
	var trackingPip = cTrackingPips_trackingPips[thisPipId];

	if(zoomState === "zoomedOut") {
		trackingPip.focus();
		api.camera.setZoom("surface");
		model.holodeck.focus();

		$(element).addClass("cTrackingPip_zoomOutButton");
		$(element).removeClass("cTrackingPip_zoomInButton");
	} else {
		trackingPip.focus();
		api.camera.setZoom("air");
		model.holodeck.focus();

		$(element).addClass("cTrackingPip_zoomInButton");
		$(element).removeClass("cTrackingPip_zoomOutButton");
	}
}