dFavouriteColour
======

Mod for Planetary Annihilation to preselect your favourite colour in the lobby.
