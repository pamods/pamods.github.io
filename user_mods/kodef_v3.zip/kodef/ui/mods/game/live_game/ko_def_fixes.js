(function() {	
		// unrelated to ko deferred: fix the alerts container that blocks
		// mouse input to the holodeck at the top of the view
		$('.div_alert_panel_cont').addClass('ignoreMouse');
		$('.div_alert_panel table').addClass('receiveMouse');
		
		
		var oldChat = model.startOrSendChat;
		model.startOrSendChat = function() {
			oldChat();
			// ko deferred also effects UI updates, so we need to ensure that jQuery will see the updated values
			// thus we just push all updates, a better solution would use ko.tasks.processImmediate around the setting
			// of the chatSelected, but I cannot add that via a UI mod
			ko.processAllDeferredBindingUpdates();
			$(".div_chat_log_feed").scrollTop($(".div_chat_log_feed")[0].scrollHeight);
		};
		
		var oldCM = handlers.chat_message;
		handlers.chat_message = function(payload) {
			oldCM(payload);
			// same as above
			ko.processAllDeferredBindingUpdates();
			$(".div_chat_log_feed").scrollTop($(".div_chat_log_feed")[0].scrollHeight);
		};
}());