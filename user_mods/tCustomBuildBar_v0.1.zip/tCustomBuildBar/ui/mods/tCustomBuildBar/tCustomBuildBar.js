
    var tCustomBuildBar_start = /[^\/]*$/;  // ^ : start , \/ : '/', $ : end // as wildcard: /*.json 
    var tCustomBuildBar_end = /[.]json$/;

    //same as SelectionViewModel, just edited to work here (hack to remove error)
    function SelectionViewModel_copy(map) {
        var self = this;
        var key;
        var i;

        self.types = ko.observableArray([]);
        self.counts = ko.observableArray([]);

        for (key in map) {
            self.types().push(key);
            self.counts().push(map[key].length);
        }

        self.iconForSpec = function (id) {
            return 'img/build_bar/units/' + id.substring(id.search(tCustomBuildBar_start), id.search(tCustomBuildBar_end)) + '.png';//tCustomBuildBar
        };

        self.list = ko.computed(function () {
            var output = [];
            var i;
  
            for (i = 0; i < self.types().length; i++) {
                output.push({
                    type: self.types()[i],
                    count: self.counts()[i],
                    icon: self.iconForSpec(self.types()[i])
                });
            }

            return output;
        });
    }

    handlers.unit_specs = function (payload) {
        delete payload.message_type;
        model.unitSpecs = payload;
        
        // Fix up cross-unit references
        function crossRef(units) {
            for (var id in units) {
                var unit = units[id];
                unit.id = id;
                if (unit.build) {
                    for (var b = 0; b < unit.build.length; ++b) {
                        var ref = units[unit.build[b]];
                        if (!ref)
                        {
                            ref = {id: unit.build[b]};
                            units[ref.id] = ref;
                        }
                        unit.build[b] = ref;
                    }
                }
                if (unit.projectiles) {
                    for (var p = 0; p < unit.projectiles.length; ++p) {
                        var ref = units[unit.projectiles[p]];
                        if (!ref)
                        {
                            ref = {id: unit.projectiles[p]};
                            units[ref.id] = ref;
                        }
                        unit.projectiles[p] = ref;
                    }
                }
            }
        }
        crossRef(model.unitSpecs);
        
        function getBaseFileName(unit) {
            return unit.id.substring(unit.id.search(tCustomBuildBar_start), unit.id.search(tCustomBuildBar_end));//tCustomBuildBar made variables less generic
        }
        function getBuildKey(unit) {
            return ('000' + (999 - (unit.group || 0))).slice(-3) + 
                   ('000' + (999 - (unit.index || 0))).slice(-3) + 
                   (unit.name || getBaseFileName(unit));
        }
        function addBuildInfo(unit) {

            var custom_buildings = ['metal_extractor', 'metal_extractor_adv', 'energy_plant', 'energy_plant_adv', 'energy_storage', 'bot_factory', 'bot_factory_adv', 'vehicle_factory', 'vehicle_factory_adv', 'air_factory', 'air_factory_adv', 'radar', 'radar_adv', 'air_defense', 'air_defense_adv', 'laser_defense', 'laser_defense_adv', 'land_barrier'];//tCustomBuildBar

            //tCustomBuildBar: add items to custom tab
            for(var f = 0; f < custom_buildings.length; f = f + 1) {//tCustomBuildBar
                if(getBaseFileName(unit) === custom_buildings[f]) {//tCustomBuildBar
                    unit.categories.push("common");//tCustomBuildBar
                }//tCustomBuildBar
            }//tCustomBuildBar
            //tCustomBuildBar: remove items from standard tabs TODO
            //tCustomBuildBar: if (unit.categories.indexOf('defense')!=-1) unit.categories.splice(unit.categories.indexOf('defense'), 1);

            unit.buildKey = getBuildKey(unit);
            unit.buildIcon = 'img/build_bar/units/' + getBaseFileName(unit) + '.png'
            unit.buildStructure = (unit.categories || []).indexOf('structure') >= 0;
        }
        for (var id in model.unitSpecs) {
            addBuildInfo(model.unitSpecs[id]);
        }
        
        function makeBuildLists(units)
        {
            var buildableCategories = {
                'economy' : true,
                'factory' : true,
                'defense' : true,
                'recon' : true,
                'common' : true,//tCustomBuildBar
            };
            var result = {};
            for (var id in units)
            {
                var unit = units[id];
                if (!unit.build && !unit.projectiles)
                    continue;
                result[id] = {};
                if (unit.build) {
                    result[id].all = unit.build;
                    for (var b = 0; b < unit.build.length; ++b) {
                        var target = unit.build[b];
                        if (typeof(target) === 'string')
                            continue;
                        for (var c = 0; c < target.categories.length; ++c) {
                            var category = target.categories[c];
                            if (!buildableCategories[category])
                                continue;
                            if (!result[id][category])
                                result[id][category] = [];
                            result[id][category].push(target);
                        }
                    }
                }
                if (unit.projectiles) {
                    result[id].all = (result[id].all || []).concat(unit.projectiles);
                }
            }
            return result;
        }
        
        model.buildLists = makeBuildLists(model.unitSpecs);
    };

        var old_parseSelection = model.parseSelection;
        model.parseSelection = function(payload) {
            var self = this;
            var i = 0;
            var a = [];
            var key;
            var tabs = {
                'common': {},//tCustomBuildBar
                'all': {},
                'defense': {},
                'economy': {},
                'factory': {},
                'recon': {},
                'projectiles': {},
            };
            var selectionCanBuild = false;
            var selectionConsumesEnergy = false;

            self.allowedCommands = {};

            self.buildItemMinIndex(0);

            self.selection(null);
            self.cmdIndex(-1);
            self.selectionTypes([]);

            if (self.reviewMode())
                return;

            self.buildTabs([]);
            self.buildTabLists([]);
            self.buildOrders(payload.build_orders);

            function processBuildList(tab, items) {
                for (var j = 0; j < items.length; j++) {
                    tab[items[j].buildKey] = items[j];
                }
            }

            for (id in payload.spec_ids) {
                for (key in self.buildLists[id]) {
                    processBuildList(tabs[key], self.buildLists[id][key]);
                    selectionCanBuild = true;
                }

                for (i = 0; i < self.unitSpecs[id].commands.length; i++)
                    self.allowedCommands[self.unitSpecs[id].commands[i]] = true;
                
                if (self.unitSpecs[id].consumption.energy > 0)
                    selectionConsumesEnergy = true;

                self.selectionTypes().push(id);
            }
      
            self.allowMove(self.allowedCommands['Move']);
            self.allowAttack(self.allowedCommands['Attack']);
            self.allowAssist(self.allowedCommands['Assist']);
            self.allowRepair(self.allowedCommands['Repair']);
            self.allowReclaim(self.allowedCommands['Reclaim']);
            self.allowPatrol(self.allowedCommands['Patrol']);
            self.allowUse(self.allowedCommands['Use']);

            self.allowSpecialMove(self.allowedCommands['SpecialMove']);
            self.allowUnload(self.allowedCommands['Unload'] && payload.has_transport_payload);
            self.allowLoad(self.allowedCommands['Load'] && !payload.has_transport_payload);

            self.allowStop(!jQuery.isEmptyObject(self.allowedCommands));
            
            self.selectedMobile(payload.selected_mobile);

            self.allowFireOrders(self.allowAttack() && (self.selectedMobile() || !selectionCanBuild));
            self.allowMoveOrders(self.allowMove() && self.selectedMobile() && self.allowFireOrders());
            self.allowEnergyOrders(selectionCanBuild || selectionConsumesEnergy || self.allowRepair() || self.allowReclaim());
            self.allowBuildStanceOrders(selectionCanBuild && !self.selectedMobile());

            for (key in tabs) {
                var tab_list = [];
                var sorted_keys = Object.keys(tabs[key]).sort();

                for (i = 0; i < sorted_keys.length; i++) {
                    var a = [];
                    tab_list.push(tabs[key][sorted_keys[i]]);
                }

                if (tab_list.length) {
                    self.buildTabs.push(key);
                    self.buildTabLists.push(tab_list);
                }  
            }

            if (!$.isEmptyObject(payload.spec_ids))
                self.selection(payload);

            self.selectionModel(new SelectionViewModel_copy(payload.spec_ids));//tCustomBuildBar use copied function (hack)

            if (self.fireOrdersMap[payload.weapon[0]] != undefined)
                self.selectedFireOrderIndex(self.fireOrdersMap[payload.weapon[0]]);

            if (self.moveOrdersMap[payload.movement[0]] != undefined)
                self.selectedMoveOrderIndex(self.moveOrdersMap[payload.movement[0]]);

            if (self.energyOrdersMap[payload.energy[0]] != undefined)
                self.selectedEnergyOrderIndex(self.energyOrdersMap[payload.energy[0]]);

            if (self.allowBuildStanceOrders()) {
                if (self.buildStanceOrdersMap[payload.build[0]] != undefined)
                    self.selectedBuildStanceOrderIndex(self.buildStanceOrdersMap[payload.build[0]]);
            }
        };
