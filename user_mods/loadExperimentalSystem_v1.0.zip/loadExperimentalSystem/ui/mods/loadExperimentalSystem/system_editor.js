$("#slider_radius").replaceWith(" ");
$("#slider_radius").slider({
        range: "max",
        min: 200,
        max: 4000,
        value: model.radius(),
        slide: function (event, ui) { model.radius(ui.value); model.update_planet_spec(); }
    });
	
model.radiusError = ko.computed(function () { return model.radius() > 4000 ? 'experimental' : '' });