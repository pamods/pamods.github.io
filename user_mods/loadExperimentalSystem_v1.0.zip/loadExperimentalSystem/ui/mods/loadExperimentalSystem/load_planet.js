model.validatePlanetConfig = function (config) {
	var planet = config ? config.planet : null;
	if (!planet || planet.radius > 4000 || planet.waterHeight > 80)
		return false;

	return true;   
}
