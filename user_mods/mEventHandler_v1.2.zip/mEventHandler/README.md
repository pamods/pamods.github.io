Forum thread:
https://forums.uberent.com/threads/rel-wip-reventhandler-a-pa-engine-process-event-framework.57858

