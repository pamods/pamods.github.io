initialSettingValue("cTrackingPips_hotkey", "ctrl+t");
model.addSetting_Text("Tracking pip hotkey", "cTrackingPips_hotkey", "UI", "Text", "ctrl+t");
