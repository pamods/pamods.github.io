//Add an extra view for metal spot count
$('.div_planet_list_item_left:last').append('<div class="planet_mex_count" data-bind="text: $data.metalSpots"></div>');
