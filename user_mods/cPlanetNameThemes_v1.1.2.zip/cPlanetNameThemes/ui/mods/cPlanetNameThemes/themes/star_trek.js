cPlanetNameThemes.themes["Star Trek"] = {
	earth: new Array(
		"Bajor",
		"Cardassia Prime",
		"Earth",
		"Ferenginar",
		"Romulus",
		"Trill"
	),

	ice: new Array(
		"Andoria",
		"Delta Vega",
		"Remus",
		"Rura Penthe"
	),

	desert: new Array(
		"Ceti Alpha V",
		"Iconia",
		"Nausicaa",
		"Ocampa",
		"Qo'noS",
		"Vulcan"
	),

	moon: new Array(
		"AR-558",
		"Barzan II",
		"Celtris III",
		"Galorndon Core",
		"Memory Alpha",
		"Regula",
		"Vandor IV",
		"Weytahn"
	),

	tropical: new Array(
		"Betazed",
		"Bolarus IX",
		"Haven",
		"Malon Prime"
	),

	lava: new Array(
		"Inferna Prime",
		"Demon",
		"Deneb IV",
		"Excalbia",
		"Genesis",
		"Tholia"
	),

	metal: new Array(
		"Borg Sphere ox70F9",
		"Delphic Expanse Sphere",
		"Dyson Sphere"
	)
}