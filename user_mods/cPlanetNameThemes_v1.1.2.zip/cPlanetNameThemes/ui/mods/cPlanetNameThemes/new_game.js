// Keep a reference to Uber's version of this function.
var original_loadRandomSystem = model.loadRandomSystem;

// Override Uber's random system generator.
// This WILL be compatible with any other mods that override the random system generator,
// but only if the other mod loads first.
model.loadRandomSystem = function () {
	// Run Uber's random system generator
	original_loadRandomSystem();

	var system = model.loadedSystem();

	// Get a new name for every planet in the system
	var planet, planetName;
	for(var i=0; i<system.planets.length; i++) {
		planet = system.planets[i].planet;
		planetName = cPlanetNameThemes.getPlanetName(planet);
     	system.planets[i].name = planetName;

     	// HACK: work around some ui weirdness to get the name to show every time.
     	// This is likely to break every time uber changes something.
   		$(".div_planet_selector_tbl").find("tr:nth-child(" + (i*2+1) + ") td:last-child div:nth-child(2)").html(planetName);
	}

	// Uber's function that makes an engine call to send the new system to the server.
	model.loadedSystem(system);
}

