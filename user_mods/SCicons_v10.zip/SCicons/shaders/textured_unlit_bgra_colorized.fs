#version 150

#ifdef GL_ES
precision mediump float;
#endif

uniform sampler2D Texture;
uniform vec4 TeamColor_Primary;
uniform vec4 TeamColor_Secondary;
in vec2 v_TexCoord;
out vec4 out_FragColor;

// lightness calculation
float getLuma (in vec3 col)
    { return ( 0.3*col.r+0.59*col.g+0.11*col.b ); }

// arguments: input colour, and blending colours (edges of RGB cube)
// i.e. col000 corresponds to what the black pixels turn into,
// col100 what the red pixels turn into, col101 the magenta pixels, etc...
// this function turns the input colour into a blend of the given colours
vec4 combo(in vec3 col,    in vec4 col000, in vec4 col111,
           in vec4 col100, in vec4 col010, in vec4 col001,
           in vec4 col110, in vec4 col101, in vec4 col011)
    {
    vec3 loc = vec3(1.0,1.0,1.0) - col;
    return ( col.x*col.y*col.z*col111 + col.x*col.y*loc.z*col110
           + col.x*loc.y*col.z*col101 + col.x*loc.y*loc.z*col100
           + loc.x*col.y*col.z*col011 + loc.x*col.y*loc.z*col010
           + loc.x*loc.y*col.z*col001 + loc.x*loc.y*loc.z*col000
           );
    }

void main() {
    vec4 texel = texture(Texture, v_TexCoord);

    vec4 Black = vec4(0.0,0.0,0.0,1.0);
    vec4 White = vec4(1.0,1.0,1.0,1.0);

    float luma = getLuma(TeamColor_Primary.rgb);

    vec4 border;
    if (luma > 0.2)
    { border = Black; }
    else
    { border = White; }

    // temporary hack to allow icon highlight on selection
    // works because primary team colour is converted to cyan upon selection,
    // and because no actual team colour is pure cyan RGB(0,1,1)
    vec4 highlight;
    vec4 primary;
    if (TeamColor_Primary == vec4(0.0,1.0,1.0,1.0))
    { highlight = vec4(0.0,0.8,0.8,0.8);
      primary = vec4(0.0,0.0,0.0,0.0); }
    else
    { highlight = vec4(0.0,0.0,0.0,0.0);
        primary = TeamColor_Primary; }
 
    vec4 pip = vec4(1-border.x, 1-border.y, 1-border.z,border.a);
    vec4 shots = vec4(0.8,0.8,0,1);

    // NOTE: it seems that texel.r and texel.b are switched?!
    // this is why I'm using texel.bgr instead of texel.rgb
    vec4 final_color = combo(texel.bgr, border, pip, primary, TeamColor_Secondary, White, shots, White, highlight);

    out_FragColor = texel.a * final_color.a * final_color;
}
