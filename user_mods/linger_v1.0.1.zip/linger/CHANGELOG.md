## 1.0.1

- Typo correction in description
