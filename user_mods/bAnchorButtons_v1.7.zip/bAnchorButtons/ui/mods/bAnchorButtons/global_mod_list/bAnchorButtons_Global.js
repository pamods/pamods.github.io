initialSettingValue('bAnchorButtonsStyle','FLAT');
initialSettingValue('bAnchorButtonsAmount',3);
initialSettingValue('bAnchorButtonsUnitsAmount',3);
initialSettingValue('bAnchorButtonsRight',0);