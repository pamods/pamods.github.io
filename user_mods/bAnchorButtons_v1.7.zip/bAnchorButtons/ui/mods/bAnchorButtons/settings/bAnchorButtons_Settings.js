/* model.addSetting_DropDown('Style','bAnchorButtonsStyle','UI',["FLAT","ANGLE"],0,'Anchor Buttons'); */
model.addSetting_Slider('Number of Anchor Buttons','bAnchorButtonsAmount','UI',1,8,3,'Anchor Buttons');
model.addSetting_DropDown('Right Side Function','bAnchorButtonsRight','UI',["OFF","UNIT GROUPS","NORTH"],0,'Anchor Buttons');
model.addSetting_Slider('Number of Unit Group Buttons.','bAnchorButtonsUnitsAmount','UI',1,8,3,'Anchor Buttons');
model.registerFrameSetting('bAnchorButtons_info_frame', 'Anchor Buttons', true);