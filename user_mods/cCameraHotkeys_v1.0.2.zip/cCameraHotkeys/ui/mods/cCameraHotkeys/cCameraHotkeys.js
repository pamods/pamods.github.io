cCameraHotkeys = (function () {
	var cCameraHotkeys = { };

	cCameraHotkeys.cameras = { };

	cCameraHotkeys.keyMapping = { };

	cCameraHotkeys.keyMapping.cameras = { };

	cCameraHotkeys.keyMapping.cameraControls = { };

	cCameraHotkeys.usePoleLock = false;
	cCameraHotkeys.activeCamera = undefined;
	cCameraHotkeys.activeCameraControl = undefined;
	cCameraHotkeys.cameraControl_keydown = undefined;
	cCameraHotkeys.keypressTimestamp = undefined;
	cCameraHotkeys.keypressTimerInterval = 500;

	cCameraHotkeys.toggleCamera = function(cameraName) {
		var currentTimestamp = Date.now();
		if(cCameraHotkeys.keypressTimestamp) {
			if(currentTimestamp - cCameraHotkeys.keypressTimestamp < cCameraHotkeys.keypressTimerInterval) {
				return;
			}
		}
		cCameraHotkeys.keypressTimestamp = currentTimestamp;

		var camera = cCameraHotkeys.cameras[cameraName];

		if(cCameraHotkeys.activeCamera && cCameraHotkeys.activeCamera != camera) {
			cCameraHotkeys.activeCamera.endCameraMode();
			cCameraHotkeys.activeCamera = undefined;
		} else {
			if(!camera.inCameraMode) {
				camera.startCameraMode();
				cCameraHotkeys.activeCamera = camera;
			} else {
				camera.endCameraMode();
				cCameraHotkeys.activeCamera = undefined;
			}
		}
	};

	cCameraHotkeys.toggleCameraControl = function(cameraName, e) {
		if(e) { // keydown
			if(e.which == cCameraHotkeys.cameraControl_keydown) {
				return;
			}
			cCameraHotkeys.cameraControl_keydown = e.which;
		}

		var camera = cCameraHotkeys.cameras[cameraName];

		if(cCameraHotkeys.activeCameraControl && cCameraHotkeys.activeCameraControl != camera) {
			cCameraHotkeys.activeCameraControl.endCameraMode();
			cCameraHotkeys.activeCameraControl = undefined;
		} else {
			if(!camera.inCameraMode) {
				camera.startCameraMode();
				cCameraHotkeys.activeCameraControl = camera;
			} else {
				camera.endCameraMode();
				cCameraHotkeys.activeCameraControl = undefined;
			}
		}
	};

	cCameraHotkeys.setupKeybinds = function() {
		cCameraHotkeys.setupKeybinds_cameras();
		cCameraHotkeys.setupKeybinds_cameraControls();
	};

	cCameraHotkeys.setupKeybinds_cameras = function() {
		for(keyBind in cCameraHotkeys.keyMapping.cameras) {
			var cameraName = cCameraHotkeys.keyMapping.cameras[keyBind];

			(function(cameraName) {
				Mousetrap.bind(keyBind, function() {
					cCameraHotkeys.toggleCamera(cameraName);
					return false;
				});
			})(cameraName);
		}
	};

	cCameraHotkeys.setupKeybinds_cameraControls = function() {
		for(keyBind in cCameraHotkeys.keyMapping.cameraControls) {
			var cameraName = cCameraHotkeys.keyMapping.cameraControls[keyBind];

			(function(cameraName) {
				Mousetrap.bind(keyBind, function(e) {
					cCameraHotkeys.toggleCameraControl(cameraName, e);
					return false;
				}, "keydown");
				Mousetrap.bind(keyBind, function(e) {
					cCameraHotkeys.cameraControl_keydown = undefined;
					cCameraHotkeys.toggleCameraControl(cameraName);
					return false;
				}, "keyup");
			})(cameraName);
		}
	};

	cCameraHotkeys.isPoleLockEnabled = function() {
		var allSettings = decode(localStorage[localStorage.uberName + ".paSettings"]);
		var currentPoleLock = allSettings.camera.pole_lock; // the settings store this upper case, the engine processes it in lowercase... wtf

		if (currentPoleLock === 'OFF') {
			return false;
		} else {
			return true;
		}
	};

	cCameraHotkeys.setPoleLock = function(activate) {
		console.log("setPoleLock(" + activate +")");
		var allSettings = decode(localStorage[localStorage.uberName + ".paSettings"]);

		if(activate) {
			engine.call("set_camera_pole_lock", "on");
			allSettings.camera.pole_lock = "ON";
		} else {
			engine.call("set_camera_pole_lock", "off");
			allSettings.camera.pole_lock = "OFF";
		}

		localStorage.settings = encode(allSettings);
	};

	cCameraHotkeys.handleDisablePoleLock = function() {
		cCameraHotkeys.usePoleLock = cCameraHotkeys.isPoleLockEnabled();
		if(cCameraHotkeys.usePoleLock)
			cCameraHotkeys.setPoleLock(false);
	};

	cCameraHotkeys.handleEnablePoleLock = function() {
		if(cCameraHotkeys.usePoleLock) {
			cCameraHotkeys.setPoleLock(true);
			cCameraHotkeys.usePoleLock(false);
		}
	};

	return cCameraHotkeys;
})();


model.settings = ko.observable({}).extend({ local: 'settings' });