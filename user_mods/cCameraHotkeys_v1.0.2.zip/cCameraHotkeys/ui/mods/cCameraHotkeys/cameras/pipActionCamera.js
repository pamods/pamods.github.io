/**
 * All cameras must have the following:
 *	function startCameraMode()
 *	function endCameraMode()
 *	var inCameraMode
 **/

cCameraHotkeys.cameras.pipActionCamera = (function () {
	var pipActionCamera = {};

	pipActionCamera.inCameraMode = false;
	pipActionCamera.cameraModeTimer;
	pipActionCamera.rollDirection = 1;

	pipActionCamera.startCameraMode = function() {
		pipActionCamera.inCameraMode = true;
		pipActionCamera.rollDirection *= -1;

		cCameraHotkeys.handleDisablePoleLock();

		api.camera.changeKeyPanSpeed(-.97);

		model.showPips(true);
		model.pips[0].copyCamera(model.holodeck);
		model.pips[0].focus();
		api.camera.setZoom("air");
		model.holodeck.focus();

		pipActionCamera.smoothMoveCamera();
	};

	pipActionCamera.endCameraMode = function() {
		pipActionCamera.inCameraMode = false;
		clearTimeout(pipActionCamera.cameraModeTimer);
	};

	pipActionCamera.smoothMoveCamera = function() {
		if(!pipActionCamera.inCameraMode) {
			cCameraHotkeys.handleEnablePoleLock();
			api.camera.changeKeyPanSpeed(.97);
		} else {
			api.camera.zoom(.02);
			engine.call("camera.roll", .1*pipActionCamera.rollDirection).then(function() {
				pipActionCamera.smoothMoveCamera();
			});
		}
	};

	// Register with the mod
	var keyBind = default_keybinds["eXodus eSports Camera Modes"]["PiP Action Camera"];
	cCameraHotkeys.keyMapping.cameras[keyBind] = "pipActionCamera";

	return pipActionCamera;
})();