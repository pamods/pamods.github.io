/**
 * All cameras must have the following:
 *	function startCameraMode()
 *	function endCameraMode()
 *	var inCameraMode
 **/

cCameraHotkeys.cameras.smoothZoomOut = (function () {
	var smoothZoomOut = {};

	smoothZoomOut.inCameraMode = false;
	smoothZoomOut.cameraModeTimer;

	smoothZoomOut.startCameraMode = function() {
		smoothZoomOut.inCameraMode = true;
		smoothZoomOut.smoothMoveCamera();

	};

	smoothZoomOut.endCameraMode = function() {
		smoothZoomOut.inCameraMode = false;
		clearTimeout(smoothZoomOut.cameraModeTimer);
	};

	smoothZoomOut.smoothMoveCamera = function() {
		if(!smoothZoomOut.inCameraMode) {
			smoothZoomOut.smoothMoveCameraMomentum(-.225, .025, 0);
		} else {
			engine.call("camera.zoom", -.25).then(function() {
				smoothZoomOut.smoothMoveCamera();
			});
		}
	};

	smoothZoomOut.smoothMoveCameraMomentum = function(cameraSpeed, increment, stopAtSpeed) {
		console.log(cameraSpeed);
		if(cameraSpeed >= stopAtSpeed) {
			return;
		} else {
			engine.call("camera.zoom", cameraSpeed).then(function() {
				smoothZoomOut.smoothMoveCameraMomentum(cameraSpeed+increment, increment, stopAtSpeed);
			});
		}
	};

	// Register with the mod
	var keyBind = default_keybinds["eXodus eSports Camera Modes"]["Smooth Zoom Out"];
	cCameraHotkeys.keyMapping.cameraControls[keyBind] = "smoothZoomOut";

	return smoothZoomOut;
})();