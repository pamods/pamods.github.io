(function() {
	model.TNNameToPlanet = function(words){
		var all=model.celestialViewModels();
		var name_length=0;
		var match=false;
		var target_planet=-1;
		var i=0;
		var j=0;
		for (i=0;i<all.length;i++){
			if (!all[i].isSun()){
				name_split=all[i].name().split(" ");
				name_length=name_split.length;
				match=true;
				for (j=0;j<name_length;j++){
					if (j<words.length){
						if (words[j]!=name_split[j]){
							match=false;
							break;
						}
					}else{
						match=false;
						break;
					}
				}
				if (match){
					break;
				}
			}
		}
		if (match){
			target_planet=all[i];
		}
		var basket={};
		basket.planet=target_planet;
		basket.read_index=name_length;
		return basket;
	}

	model.TNCheckForNextWords = function(start,words,checks){
		var i=0;
		if (words.length>=start+checks.length){
			for (i=0;i<checks.length;i++){
				if (words[start+i]!=checks[i]){
					return -1;
				}
			}
			return start+i;
		}else{
			return -1;
		}
	}


	model.celestialchangesafe=[];
	model.celestialmax=0;

	model.TeamNoteSaver = function(){
		var all=model.celestialViewModels();
		var i=0;
		model.celestialchangesafe=[];
		for (i=0;i<all.length;i++){
			model.celestialchangesafe.push({TNShowScoutedEmpty:all[i].TNShowScoutedEmpty(),
				TNShowScoutedLight:all[i].TNShowScoutedLight(),
				TNShowScoutedMedium:all[i].TNShowScoutedMedium(),
				TNShowScoutedHeavy:all[i].TNShowScoutedHeavy(),
				TNShowScoutedUnknown:all[i].TNShowScoutedUnknown(),
				TNShowAllyCoreworld:all[i].TNShowAllyCoreworld(),
				TNShowAllyColony:all[i].TNShowAllyColony(),
				TNShowAllyOutpost:all[i].TNShowAllyOutpost(),
				TNShowAllyUnbuilt:all[i].TNShowAllyUnbuilt(),
				TNShowEnemyCoreworld:all[i].TNShowEnemyCoreworld(),
				TNShowEnemyColony:all[i].TNShowEnemyColony(),
				TNShowEnemyOutpost:all[i].TNShowEnemyOutpost(),
				TNShowEnemyUnbuilt:all[i].TNShowEnemyUnbuilt()
			});
		}
	}

	model.TeamNoteRecovery = function(){
		var all=model.celestialViewModels();
		var i=0;
		for (i=0;i<all.length;i++){
			all[i].TNShowScoutedEmpty(model.celestialchangesafe[i].TNShowScoutedLight);
			all[i].TNShowScoutedLight(model.celestialchangesafe[i].TNShowScoutedLight);
			all[i].TNShowScoutedMedium(model.celestialchangesafe[i].TNShowScoutedMedium);
			all[i].TNShowScoutedHeavy(model.celestialchangesafe[i].TNShowScoutedHeavy);
			all[i].TNShowScoutedUnknown(model.celestialchangesafe[i].TNShowScoutedUnknown);
			all[i].TNShowAllyCoreworld(model.celestialchangesafe[i].TNShowAllyCoreworld);
			all[i].TNShowAllyColony(model.celestialchangesafe[i].TNShowAllyColony);
			all[i].TNShowAllyOutpost(model.celestialchangesafe[i].TNShowAllyOutpost);
			all[i].TNShowAllyUnbuilt(model.celestialchangesafe[i].TNShowAllyUnbuilt);
			all[i].TNShowEnemyCoreworld(model.celestialchangesafe[i].TNShowEnemyCoreworld);
			all[i].TNShowEnemyColony(model.celestialchangesafe[i].TNShowEnemyColony);
			all[i].TNShowEnemyOutpost(model.celestialchangesafe[i].TNShowEnemyOutpost);
			all[i].TNShowEnemyUnbuilt(model.celestialchangesafe[i].TNShowEnemyUnbuilt);
		}
	}

	model.TeamNoteParsing = function (newchat){
		var last=newchat[newchat.length-1];
		if (!!last.team){
			var words=last.message.split(" ");
			var planetoid=model.TNNameToPlanet(words);
			if (planetoid.planet!=-1){
				index=model.TNCheckForNextWords(planetoid.read_index,words,["has"]);
				if (index!=-1){
					var index2=model.TNCheckForNextWords(index,words,["no"]);
					if (index2!=-1){
						var index3=model.TNCheckForNextWords(index2,words,["enemies"]);
						if (index3!=-1){
							planetoid.planet["TNShowScoutedEmpty"](true);
							planetoid.planet["TNShowScoutedLight"](false);
							planetoid.planet["TNShowScoutedMedium"](false);
							planetoid.planet["TNShowScoutedHeavy"](false);
							planetoid.planet["TNShowScoutedUnknown"](false);
							if (planetoid.planet==model.celestialViewModels()[model.selectedCelestialIndex()]){
								model.TNCurrentChanger(model.selectedCelestialIndex());
							}
							model.TeamNoteSaver();
						}
						index3=model.TNCheckForNextWords(index2,words,["base","by","us","now"]);
						if (index3!=-1){
							planetoid.planet["TNShowAllyCoreworld"](false);
							planetoid.planet["TNShowAllyColony"](false);
							planetoid.planet["TNShowAllyOutpost"](false);
							planetoid.planet["TNShowAllyUnbuilt"](true);
							if (planetoid.planet==model.celestialViewModels()[model.selectedCelestialIndex()]){
								model.TNCurrentChanger(model.selectedCelestialIndex());
							}
							model.TeamNoteSaver();
						}
						index3=model.TNCheckForNextWords(index2,words,["enemy","base"]);
						if (index3!=-1){
							planetoid.planet["TNShowEnemyCoreworld"](false);
							planetoid.planet["TNShowEnemyColony"](false);
							planetoid.planet["TNShowEnemyOutpost"](false);
							planetoid.planet["TNShowEnemyUnbuilt"](true);
							if (planetoid.planet==model.celestialViewModels()[model.selectedCelestialIndex()]){
								model.TNCurrentChanger(model.selectedCelestialIndex());
							}
							model.TeamNoteSaver();
						}
					}
					index2=model.TNCheckForNextWords(index,words,["light","enemy","presence"]);
					if (index2!=-1){
						planetoid.planet["TNShowScoutedEmpty"](false);
						planetoid.planet["TNShowScoutedLight"](true);
						planetoid.planet["TNShowScoutedMedium"](false);
						planetoid.planet["TNShowScoutedHeavy"](false);
						planetoid.planet["TNShowScoutedUnknown"](false);
						if (planetoid.planet==model.celestialViewModels()[model.selectedCelestialIndex()]){
							model.TNCurrentChanger(model.selectedCelestialIndex());
						}
						model.TeamNoteSaver();
					}
					index2=model.TNCheckForNextWords(index,words,["moderate","enemy","presence"]);
					if (index2!=-1){
						planetoid.planet["TNShowScoutedEmpty"](false);
						planetoid.planet["TNShowScoutedLight"](false);
						planetoid.planet["TNShowScoutedMedium"](true);
						planetoid.planet["TNShowScoutedHeavy"](false);
						planetoid.planet["TNShowScoutedUnknown"](false);
						if (planetoid.planet==model.celestialViewModels()[model.selectedCelestialIndex()]){
							model.TNCurrentChanger(model.selectedCelestialIndex());
						}
						model.TeamNoteSaver();
					}
					index2=model.TNCheckForNextWords(index,words,["heavy","enemy","presence"]);
					if (index2!=-1){
						planetoid.planet["TNShowScoutedEmpty"](false);
						planetoid.planet["TNShowScoutedLight"](false);
						planetoid.planet["TNShowScoutedMedium"](false);
						planetoid.planet["TNShowScoutedHeavy"](true);
						planetoid.planet["TNShowScoutedUnknown"](false);
						if (planetoid.planet==model.celestialViewModels()[model.selectedCelestialIndex()]){
							model.TNCurrentChanger(model.selectedCelestialIndex());
						}
						model.TeamNoteSaver();
					}
					index2=model.TNCheckForNextWords(index,words,["our"]);
					if (index2!=-1){
						var index3=model.TNCheckForNextWords(index2,words,["outpost","now"]);
						if (index3!=-1){
							planetoid.planet["TNShowAllyCoreworld"](false);
							planetoid.planet["TNShowAllyColony"](false);
							planetoid.planet["TNShowAllyOutpost"](true);
							planetoid.planet["TNShowAllyUnbuilt"](false);
							if (planetoid.planet==model.celestialViewModels()[model.selectedCelestialIndex()]){
								model.TNCurrentChanger(model.selectedCelestialIndex());
							}
							model.TeamNoteSaver();
						}
						index3=model.TNCheckForNextWords(index2,words,["colony","now"]);
						if (index3!=-1){
							planetoid.planet["TNShowAllyCoreworld"](false);
							planetoid.planet["TNShowAllyColony"](true);
							planetoid.planet["TNShowAllyOutpost"](false);
							planetoid.planet["TNShowAllyUnbuilt"](false);
							if (planetoid.planet==model.celestialViewModels()[model.selectedCelestialIndex()]){
								model.TNCurrentChanger(model.selectedCelestialIndex());
							}
							model.TeamNoteSaver();
						}
					}
					index2=model.TNCheckForNextWords(index,words,["enemy"]);
					if (index2!=-1){
						var index3=model.TNCheckForNextWords(index2,words,["colony"]);
						if (index3!=-1){
							planetoid.planet["TNShowEnemyCoreworld"](false);
							planetoid.planet["TNShowEnemyColony"](true);
							planetoid.planet["TNShowEnemyOutpost"](false);
							planetoid.planet["TNShowEnemyUnbuilt"](false);
							if (planetoid.planet==model.celestialViewModels()[model.selectedCelestialIndex()]){
								model.TNCurrentChanger(model.selectedCelestialIndex());
							}
							model.TeamNoteSaver();
						}
						var index3=model.TNCheckForNextWords(index2,words,["outpost"]);
						if (index3!=-1){
							planetoid.planet["TNShowEnemyCoreworld"](false);
							planetoid.planet["TNShowEnemyColony"](false);
							planetoid.planet["TNShowEnemyOutpost"](true);
							planetoid.planet["TNShowEnemyUnbuilt"](false);
							if (planetoid.planet==model.celestialViewModels()[model.selectedCelestialIndex()]){
								model.TNCurrentChanger(model.selectedCelestialIndex());
							}
							model.TeamNoteSaver();
						}
					}
				}
				index=model.TNCheckForNextWords(planetoid.read_index,words,["might","have","enemy"]);
				if (index!=-1){
					planetoid.planet["TNShowScoutedEmpty"](false);
					planetoid.planet["TNShowScoutedLight"](false);
					planetoid.planet["TNShowScoutedMedium"](false);
					planetoid.planet["TNShowScoutedHeavy"](false);
					planetoid.planet["TNShowScoutedUnknown"](true);
					if (planetoid.planet==model.celestialViewModels()[model.selectedCelestialIndex()]){
						model.TNCurrentChanger(model.selectedCelestialIndex());
					}
					model.TeamNoteSaver();
				}
				index=model.TNCheckForNextWords(planetoid.read_index,words,["is","one","of"]);
				if (index!=-1){
					var index2=model.TNCheckForNextWords(index,words,["our","coreworlds","now"]);
					if (index2!=-1){
						planetoid.planet["TNShowAllyCoreworld"](true);
						planetoid.planet["TNShowAllyColony"](false);
						planetoid.planet["TNShowAllyOutpost"](false);
						planetoid.planet["TNShowAllyUnbuilt"](false);
						if (planetoid.planet==model.celestialViewModels()[model.selectedCelestialIndex()]){
							model.TNCurrentChanger(model.selectedCelestialIndex());
						}
						model.TeamNoteSaver();
					}
					index2=model.TNCheckForNextWords(index,words,["enemy","coreworlds"]);
					if (index2!=-1){
						planetoid.planet["TNShowEnemyCoreworld"](true);
						planetoid.planet["TNShowEnemyColony"](false);
						planetoid.planet["TNShowEnemyOutpost"](false);
						planetoid.planet["TNShowEnemyUnbuilt"](false);
						if (planetoid.planet==model.celestialViewModels()[model.selectedCelestialIndex()]){
							model.TNCurrentChanger(model.selectedCelestialIndex());
						}
						model.TeamNoteSaver();
					}
				}
			}			
		}		
	}


	model.TNcelestialViewModel = function (element) {
		if (element.length>0){
			if (["TNShowScoutedEmpty"] in element[element.length-1]){
			}else{ 
				element[element.length-1]["TNShowScoutedEmpty"]=ko.observable(false);
				element[element.length-1]["TNShowScoutedUnknown"]=ko.observable(true);
				element[element.length-1]["TNShowScoutedLight"]=ko.observable(false);
				element[element.length-1]["TNShowScoutedMedium"]=ko.observable(false);
				element[element.length-1]["TNShowScoutedHeavy"]=ko.observable(false);
				element[element.length-1]["TNShowAllyUnbuilt"]=ko.observable(true);
				element[element.length-1]["TNShowAllyCoreworld"]=ko.observable(false);
				element[element.length-1]["TNShowAllyColony"]=ko.observable(false);
				element[element.length-1]["TNShowAllyOutpost"]=ko.observable(false);
				element[element.length-1]["TNShowEnemyUnbuilt"]=ko.observable(true);
				element[element.length-1]["TNShowEnemyCoreworld"]=ko.observable(false);
				element[element.length-1]["TNShowEnemyColony"]=ko.observable(false);
				element[element.length-1]["TNShowEnemyOutpost"]=ko.observable(false);
			}
			if (element.length==model.celestialmax){
				model.TeamNoteRecovery();
			}
			if (element.length>model.celestialmax){
				model.celestialmax=element.length;
				model.TeamNoteSaver();
			}
		}
	}


	model.celestialViewModels.subscribe(model.TNcelestialViewModel);
	

	model.ScoutUnknown = function () {
		var msg={};
		msg.message=model.selectedPlanetName()+" might have enemy";
		if (!model.TNChatAutistic()){
			model.send_message("team_chat_message",msg);
		}else{
			msg.team=true;
			model.TeamNoteParsing([msg]);
		}
		
	};

	model.ScoutEmpty = function () {
		var msg={};
		msg.message=model.selectedPlanetName()+" has no enemies";
		if (!model.TNChatAutistic()){
			model.send_message("team_chat_message",msg);
		}else{
			msg.team=true;
			model.TeamNoteParsing([msg]);
		}
	};
	model.ScoutLight = function () {
		var msg={};
		msg.message=model.selectedPlanetName()+" has light enemy presence";
		if (!model.TNChatAutistic()){
			model.send_message("team_chat_message",msg);
		}else{
			msg.team=true;
			model.TeamNoteParsing([msg]);
		}
	};
	model.ScoutMedium = function () {
		var msg={};
		msg.message=model.selectedPlanetName()+" has moderate enemy presence";
		if (!model.TNChatAutistic()){
			model.send_message("team_chat_message",msg);
		}else{
			msg.team=true;
			model.TeamNoteParsing([msg]);
		}
	};
	model.ScoutHeavy = function() {
		var msg={};
		msg.message=model.selectedPlanetName()+" has heavy enemy presence";
		if (!model.TNChatAutistic()){
			model.send_message("team_chat_message",msg);
		}else{
			msg.team=true;
			model.TeamNoteParsing([msg]);
		}
	};

	model.ClaimCoreworld = function() {
		var msg={};
		msg.message=model.selectedPlanetName()+" is one of our coreworlds now";
		if (!model.TNChatAutistic()){
			model.send_message("team_chat_message",msg);
		}else{
			msg.team=true;
			model.TeamNoteParsing([msg]);
		}
	};

	model.ClaimColony = function() {
		var msg={};
		msg.message=model.selectedPlanetName()+" has our colony now";
		if (!model.TNChatAutistic()){
			model.send_message("team_chat_message",msg);
		}else{
			msg.team=true;
			model.TeamNoteParsing([msg]);
		}
	};

	model.ClaimOutpost = function() {
		var msg={};
		msg.message=model.selectedPlanetName()+" has our outpost now";
		if (!model.TNChatAutistic()){
			model.send_message("team_chat_message",msg);
		}else{
			msg.team=true;
			model.TeamNoteParsing([msg]);
		}
	};

	model.TNClaimUnbuilt = function() {
		var msg={};
		msg.message=model.selectedPlanetName()+" has no base by us now";
		if (!model.TNChatAutistic()){
			model.send_message("team_chat_message",msg);
		}else{
			msg.team=true;
			model.TeamNoteParsing([msg]);
		}
	};

	model.LocateCoreworld = function() {
		var msg={};
		msg.message=model.selectedPlanetName()+" is one of enemy coreworlds";
		if (!model.TNChatAutistic()){
			model.send_message("team_chat_message",msg);
		}else{
			msg.team=true;
			model.TeamNoteParsing([msg]);
		}
	};

	model.LocateColony = function() {
		var msg={};
		msg.message=model.selectedPlanetName()+" has enemy colony";
		if (!model.TNChatAutistic()){
			model.send_message("team_chat_message",msg);
		}else{
			msg.team=true;
			model.TeamNoteParsing([msg]);
		}
	};

	model.LocateOutpost = function() {
		var msg={};
		msg.message=model.selectedPlanetName()+" has enemy outpost";
		if (!model.TNChatAutistic()){
			model.send_message("team_chat_message",msg);
		}else{
			msg.team=true;
			model.TeamNoteParsing([msg]);
		}
	};

	model.LocateUnbuilt = function() {
		var msg={};
		msg.message=model.selectedPlanetName()+" has no enemy base";
		if (!model.TNChatAutistic()){
			model.send_message("team_chat_message",msg);
		}else{
			msg.team=true;
			model.TeamNoteParsing([msg]);
		}
	};


	model.ChatAutistic = function() {
		model.TNChatAutistic(true);
		model.TNChatOutistic(false);
	};

	model.ChatOutistic = function() {
		model.TNChatAutistic(false);
		model.TNChatOutistic(true);
	};


	model.TNShowCurrentEmpty = ko.observable(false);
	model.TNShowCurrentLight = ko.observable(false);
	model.TNShowCurrentMedium = ko.observable(false);
	model.TNShowCurrentHeavy = ko.observable(false);
	model.TNShowCurrentUnknown = ko.observable(true);
	model.TNShowCurrentAllyCoreworld = ko.observable(false);
	model.TNShowCurrentAllyColony = ko.observable(false);
	model.TNShowCurrentAllyOutpost = ko.observable(false);
	model.TNShowCurrentAllyUnbuilt = ko.observable(true);
	model.TNShowCurrentEnemyCoreworld = ko.observable(false);
	model.TNShowCurrentEnemyColony = ko.observable(false);
	model.TNShowCurrentEnemyOutpost = ko.observable(false);
	model.TNShowCurrentEnemyUnbuilt = ko.observable(true);

	model.TNChatAutistic=ko.observable(false);
	model.TNChatOutistic=ko.observable(true);

	model.TNCurrentChanger= function(element){
		var all=model.celestialViewModels();
		model.TNShowCurrentEmpty(all[element]["TNShowScoutedEmpty"]());
		model.TNShowCurrentLight(all[element]["TNShowScoutedLight"]());
		model.TNShowCurrentMedium(all[element]["TNShowScoutedMedium"]());
		model.TNShowCurrentHeavy(all[element]["TNShowScoutedHeavy"]());
		model.TNShowCurrentUnknown(all[element]["TNShowScoutedUnknown"]());
		model.TNShowCurrentAllyUnbuilt(all[element]["TNShowAllyUnbuilt"]());
		model.TNShowCurrentAllyCoreworld(all[element]["TNShowAllyCoreworld"]());
		model.TNShowCurrentAllyColony(all[element]["TNShowAllyColony"]());
		model.TNShowCurrentAllyOutpost(all[element]["TNShowAllyOutpost"]());
		model.TNShowCurrentEnemyUnbuilt(all[element]["TNShowEnemyUnbuilt"]());
		model.TNShowCurrentEnemyCoreworld(all[element]["TNShowEnemyCoreworld"]());
		model.TNShowCurrentEnemyColony(all[element]["TNShowEnemyColony"]());
		model.TNShowCurrentEnemyOutpost(all[element]["TNShowEnemyOutpost"]());
	};

	model.selectedCelestialIndex.subscribe(model.TNCurrentChanger);

	model.ShowCommunication=ko.computed(function () {return !model.isSunSelected()});

	$(".div_planet_list_item_left").prepend("<img class=\"celestial_menu_item\" data-bind= \"visible: $data.TNShowAllyCoreworld\" src=\"coui://ui/mods/sTeamNotes/ally_coreworld.png\" ></img>");
	$(".div_planet_list_item_left").prepend("<img class=\"celestial_menu_item\" data-bind= \"visible: $data.TNShowAllyColony\" src=\"coui://ui/mods/sTeamNotes/ally_colony.png\" ></img>");
	$(".div_planet_list_item_left").prepend("<img class=\"celestial_menu_item\" data-bind= \"visible: $data.TNShowAllyOutpost\" src=\"coui://ui/mods/sTeamNotes/ally_outpost.png\" ></img>");
	$(".div_planet_list_item_left").prepend("<img class=\"celestial_menu_item\" data-bind= \"visible: $data.TNShowEnemyCoreworld\" src=\"coui://ui/mods/sTeamNotes/enemy_coreworld.png\" ></img>");
	$(".div_planet_list_item_left").prepend("<img class=\"celestial_menu_item\" data-bind= \"visible: $data.TNShowEnemyColony\" src=\"coui://ui/mods/sTeamNotes/enemy_colony.png\" ></img>");
	$(".div_planet_list_item_left").prepend("<img class=\"celestial_menu_item\" data-bind= \"visible: $data.TNShowEnemyOutpost\" src=\"coui://ui/mods/sTeamNotes/enemy_outpost.png\" ></img>");
	$(".div_planet_list_item_left").prepend("<img class=\"celestial_menu_item\" data-bind= \"visible: $data.TNShowScoutedEmpty\" src=\"coui://ui/mods/sTeamNotes/scout_empty.png\" ></img>");
	$(".div_planet_list_item_left").prepend("<img class=\"celestial_menu_item\" data-bind= \"visible: $data.TNShowScoutedLight\" src=\"coui://ui/mods/sTeamNotes/scout_light.png\" ></img>");
	$(".div_planet_list_item_left").prepend("<img class=\"celestial_menu_item\" data-bind= \"visible: $data.TNShowScoutedMedium\" src=\"coui://ui/mods/sTeamNotes/scout_medium.png\" ></img>");
	$(".div_planet_list_item_left").prepend("<img class=\"celestial_menu_item\" data-bind= \"visible: $data.TNShowScoutedHeavy\" src=\"coui://ui/mods/sTeamNotes/scout_heavy.png\" ></img>");
	$(".div_planet_list_item_left").prepend("<img class=\"celestial_menu_item\" data-bind= \"visible: $data.TNShowScoutedUnknown\" src=\"coui://ui/mods/sTeamNotes/scout_unknown.png\" ></img>");
	$(".div_chat_log").prepend("<div class=\"div_chat_options receiveMouse\"></div>");
	$(".div_chat_options").prepend("<div class=\"icon_team_notes\" data-bind= \"visible: TNChatOutistic,event: {mousedown: ChatAutistic}\"> <a href=\"#\" id=\"TN5\" data-bind=\"click_sound:'default', rollover_sound:'default'\"><img class=\"icon_team_notes\" src=\"coui://ui/mods/sTeamNotes/outistic.png\"></a></div>");
	$(".div_chat_options").prepend("<div class=\"icon_team_notes\" data-bind= \"visible: TNChatAutistic,event: {mousedown: ChatOutistic}\"> <a href=\"#\" id=\"TN5\" data-bind=\"click_sound:'default', rollover_sound:'default'\"><img class=\"icon_team_notes\" src=\"coui://ui/mods/sTeamNotes/autistic.png\"></a></div>");
	$(".div_sidebar_right").append("<div class=\"div_team_notes_bar_top_cont\" ></div>");
	$(".div_team_notes_bar_top_cont").append("<div class=\"div_team_notes_bar receiveMouse\" , data-bind=\"visible:ShowCommunication\" ></div>");
	$(".div_team_notes_bar").append("<div class=\"div_team_notes_bar_cont\" data-bind=\"event:{mouseout: function(){maybeClearHoverIndex(4)}}\" ></div>");
	$(".div_team_notes_bar_cont").append("<div id=\"TNScoutBar\" class=\"div_command_item\" data-bind=\"event:{mouseover: function() { setHoverIndex(4)}}\" title=\"SCOUT\" ><a href=\"#\" id=\"TN1a\"><img class=\"icon_team_notes\" data-bind=\"visible: TNShowCurrentEmpty,event:{mouseover: function() { setHoverIndex(4)}}\" src=\"coui://ui/mods/sTeamNotes/scout_empty.png\" ></img></a></div>");
	$(".div_team_notes_bar_cont").append("<a href=\"#\" id=\"TN1b\"><img class=\"icon_team_notes\" data-bind=\"visible: TNShowCurrentLight,event:{mouseover: function() { setHoverIndex(4)}}\" src=\"coui://ui/mods/sTeamNotes/scout_light.png\" ></img></a>");
	$(".div_team_notes_bar_cont").append("<a href=\"#\" id=\"TN1c\"><img class=\"icon_team_notes\" data-bind=\"visible: TNShowCurrentMedium,event:{mouseover: function() { setHoverIndex(4)}}\" src=\"coui://ui/mods/sTeamNotes/scout_medium.png\" ></img></a>");
	$(".div_team_notes_bar_cont").append("<a href=\"#\" id=\"TN1d\"><img class=\"icon_team_notes\" data-bind=\"visible: TNShowCurrentHeavy,event:{mouseover: function() { setHoverIndex(4)}}\" src=\"coui://ui/mods/sTeamNotes/scout_heavy.png\" ></img></a>");
	$(".div_team_notes_bar_cont").append("<a href=\"#\" id=\"TN1e\"><img class=\"icon_team_notes\" data-bind=\"visible: TNShowCurrentUnknown,event:{mouseover: function() { setHoverIndex(4)}}\" src=\"coui://ui/mods/sTeamNotes/scout_unknown.png\" ></img></a>");
	$(".div_team_notes_bar_cont").append("<div class=\"div_scout_menu\" data-bind=\"visible: hoverOrderIndex()==4,event: {mouseover: function(){setHoverIndex(4)}}\" ></div>");
	$(".div_team_notes_bar_cont").append("<div id=\"TNAllyBaseBar\" class=\"div_command_item\" data-bind=\"event:{mouseover: function() { setHoverIndex(5)}}\" title=\"BASE\" ><a href=\"#\" id=\"TN2a\"><img class=\"icon_team_notes\" data-bind=\"visible: TNShowCurrentAllyCoreworld,event:{mouseover: function() { setHoverIndex(5)}}\" src=\"coui://ui/mods/sTeamNotes/ally_coreworld.png\" ></img></a></div>");
	$(".div_team_notes_bar_cont").append("<a href=\"#\" id=\"TN2b\"><img class=\"icon_team_notes\" data-bind=\"visible: TNShowCurrentAllyColony,event:{mouseover: function() { setHoverIndex(5)}}\" src=\"coui://ui/mods/sTeamNotes/ally_colony.png\" ></img></a>");
	$(".div_team_notes_bar_cont").append("<a href=\"#\" id=\"TN2c\"><img class=\"icon_team_notes\" data-bind=\"visible: TNShowCurrentAllyOutpost,event:{mouseover: function() { setHoverIndex(5)}}\" src=\"coui://ui/mods/sTeamNotes/ally_outpost.png\" ></img></a>");
	$(".div_team_notes_bar_cont").append("<a href=\"#\" id=\"TN2d\"><img class=\"icon_team_notes\" data-bind=\"visible: TNShowCurrentAllyUnbuilt,event:{mouseover: function() { setHoverIndex(5)}}\" src=\"coui://ui/mods/sTeamNotes/ally_unbuilt.png\" ></img></a>");
	$(".div_team_notes_bar_cont").append("<div class=\"div_base_menu\" data-bind=\"visible: hoverOrderIndex()==5,event: {mouseover: function(){setHoverIndex(5)}}\" ></div>");
	$(".div_team_notes_bar_cont").append("<div id=\"TNEnemyBaseBar\" class=\"div_command_item\" data-bind=\"event:{mouseover: function() { setHoverIndex(6)}}\" title=\"BASE\" ><a href=\"#\" id=\"TN3a\"><img class=\"icon_team_notes\" data-bind=\"visible: TNShowCurrentEnemyCoreworld,event:{mouseover: function() { setHoverIndex(6)}}\" src=\"coui://ui/mods/sTeamNotes/enemy_coreworld.png\" ></img></a></div>");
	$(".div_team_notes_bar_cont").append("<a href=\"#\" id=\"TN3b\"><img class=\"icon_team_notes\" data-bind=\"visible: TNShowCurrentEnemyColony,event:{mouseover: function() { setHoverIndex(6)}}\" src=\"coui://ui/mods/sTeamNotes/enemy_colony.png\" ></img></a>");
	$(".div_team_notes_bar_cont").append("<a href=\"#\" id=\"TN3c\"><img class=\"icon_team_notes\" data-bind=\"visible: TNShowCurrentEnemyOutpost,event:{mouseover: function() { setHoverIndex(6)}}\" src=\"coui://ui/mods/sTeamNotes/enemy_outpost.png\" ></img></a>");
	$(".div_team_notes_bar_cont").append("<a href=\"#\" id=\"TN3d\"><img class=\"icon_team_notes\" data-bind=\"visible: TNShowCurrentEnemyUnbuilt,event:{mouseover: function() { setHoverIndex(6)}}\" src=\"coui://ui/mods/sTeamNotes/enemy_unbuilt.png\" ></img></a>");
	$(".div_team_notes_bar_cont").append("<div class=\"div_hostile_base_menu\" data-bind=\"visible: hoverOrderIndex()==6,event: {mouseover: function(){setHoverIndex(6)}}\" ></div>");
	$(".div_scout_menu").append("<div class=\"div_command_menu_item\" data-bind=\"visible: hoverOrderIndex()==4, click: function(){ScoutEmpty();}\" title=\"SCOUT\"><a href=\"#\" id=\"TN1\" data-bind=\"click_sound:'default', rollover_sound:'default'\"><img class=\"icon_team_notes\" src=\"coui://ui/mods/sTeamNotes/scout_empty.png\"></a></div>");
	$(".div_scout_menu").append("<div class=\"div_command_menu_item\" data-bind=\"visible: hoverOrderIndex()==4, event: {mousedown: function(){ScoutLight();}}\" title=\"SCOUT\"><a href=\"#\" id=\"TN2\" data-bind=\"click_sound:'default', rollover_sound:'default'\"><img class=\"icon_team_notes\" src=\"coui://ui/mods/sTeamNotes/scout_light.png\"></a></div>");
	$(".div_scout_menu").append("<div class=\"div_command_menu_item\" data-bind=\"visible: hoverOrderIndex()==4, event: {mousedown: model.ScoutMedium}\" title=\"SCOUT\"><a href=\"#\" id=\"TN3\" data-bind=\"click_sound:'default', rollover_sound:'default'\"><img class=\"icon_team_notes\" src=\"coui://ui/mods/sTeamNotes/scout_medium.png\"></a></div>");
	$(".div_scout_menu").append("<div class=\"div_command_menu_item\" data-bind=\"visible: hoverOrderIndex()==4, event: {mousedown: function(){ScoutHeavy();}}\" title=\"SCOUT\"><a href=\"#\" id=\"TN4\" data-bind=\"click_sound:'default', rollover_sound:'default'\"><img class=\"icon_team_notes\" src=\"coui://ui/mods/sTeamNotes/scout_heavy.png\"></a></div>");
	$(".div_scout_menu").append("<div class=\"div_command_menu_item\" data-bind=\"visible: hoverOrderIndex()==4, event: {mousedown: function(){ScoutUnknown();}}\" title=\"SCOUT\"><a href=\"#\" id=\"TN5\" data-bind=\"click_sound:'default', rollover_sound:'default'\"><img class=\"icon_team_notes\" src=\"coui://ui/mods/sTeamNotes/scout_unknown.png\"></a></div>");

	$(".div_base_menu").append("<div class=\"div_command_menu_item\" data-bind=\"visible: hoverOrderIndex()==5, click: function(){ClaimCoreworld();}\" title=\"Base\"><a href=\"#\" id=\"TN21\" data-bind=\"click_sound:'default', rollover_sound:'default'\"><img class=\"icon_team_notes\" src=\"coui://ui/mods/sTeamNotes/ally_coreworld.png\"></a></div>");
	$(".div_base_menu").append("<div class=\"div_command_menu_item\" data-bind=\"visible: hoverOrderIndex()==5, click: function(){ClaimColony();}\" title=\"Base\"><a href=\"#\" id=\"TN22\" data-bind=\"click_sound:'default', rollover_sound:'default'\"><img class=\"icon_team_notes\" src=\"coui://ui/mods/sTeamNotes/ally_colony.png\"></a></div>");
	$(".div_base_menu").append("<div class=\"div_command_menu_item\" data-bind=\"visible: hoverOrderIndex()==5, click: function(){ClaimOutpost();}\" title=\"Base\"><a href=\"#\" id=\"TN23\" data-bind=\"click_sound:'default', rollover_sound:'default'\"><img class=\"icon_team_notes\" src=\"coui://ui/mods/sTeamNotes/ally_outpost.png\"></a></div>");
	$(".div_base_menu").append("<div class=\"div_command_menu_item\" data-bind=\"visible: hoverOrderIndex()==5, click: function(){TNClaimUnbuilt();}\" title=\"Base\"><a href=\"#\" id=\"TN24\" data-bind=\"click_sound:'default', rollover_sound:'default'\"><img class=\"icon_team_notes\" src=\"coui://ui/mods/sTeamNotes/ally_unbuilt.png\"></a></div>");


	$(".div_hostile_base_menu").append("<div class=\"div_command_menu_item\" data-bind=\"visible: hoverOrderIndex()==6, click: function(){LocateCoreworld();}\" title=\"Base\"><a href=\"#\" id=\"TN31\" data-bind=\"click_sound:'default', rollover_sound:'default'\"><img class=\"icon_team_notes\" src=\"coui://ui/mods/sTeamNotes/enemy_coreworld.png\"></a></div>");
	$(".div_hostile_base_menu").append("<div class=\"div_command_menu_item\" data-bind=\"visible: hoverOrderIndex()==6, click: function(){LocateColony();}\" title=\"Base\"><a href=\"#\" id=\"TN32\" data-bind=\"click_sound:'default', rollover_sound:'default'\"><img class=\"icon_team_notes\" src=\"coui://ui/mods/sTeamNotes/enemy_colony.png\"></a></div>");
	$(".div_hostile_base_menu").append("<div class=\"div_command_menu_item\" data-bind=\"visible: hoverOrderIndex()==6, click: function(){LocateOutpost();}\" title=\"Base\"><a href=\"#\" id=\"TN33\" data-bind=\"click_sound:'default', rollover_sound:'default'\"><img class=\"icon_team_notes\" src=\"coui://ui/mods/sTeamNotes/enemy_outpost.png\"></a></div>");
	$(".div_hostile_base_menu").append("<div class=\"div_command_menu_item\" data-bind=\"visible: hoverOrderIndex()==6, click: function(){LocateUnbuilt();}\" title=\"Base\"><a href=\"#\" id=\"TN34\" data-bind=\"click_sound:'default', rollover_sound:'default'\"><img class=\"icon_team_notes\" src=\"coui://ui/mods/sTeamNotes/enemy_unbuilt.png\"></a></div>");

	model.chatLog.subscribe(model.TeamNoteParsing);

})();
