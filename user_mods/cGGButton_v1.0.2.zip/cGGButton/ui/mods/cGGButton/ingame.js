$(document).on('ready', function(){

	//In-Game
	$(".div_chat_log_feed").bind("DOMSubtreeModified", function(){
		var message = $($(this).children()[$(this).children().length - 1]).text().trim().split(":")[1];

		//Make sure it doesn't get called twice
		if(message == undefined || message == "") return;
		if($('.chat_message_body:last').attr("ggchecked") == "ggchecked") return;
		$('.chat_message_body:last').attr("ggchecked", "ggchecked");

		message = message.trim()

		//Loop through all taunts
		$.each(gg, function(k, v){
			//Found a match
			if(message.match(v.word)){
				//Play it
				v.play();
				return;
			}
		});
	});
});