model.apd = (function () {
    var apd = {};

    function planetProperty(index, property) {
        var x;
        //if (index < 0) { return false; }
        if (typeof model.system().planets[index] === "object") {
            if (typeof model.system().planets[index].generator === "object") {
                x = model.system().planets[index].generator[property];
                return x;
            }
            if (typeof model.system().planets[index].planet === "object") { //Planet takes precedence over Generator.
                x = model.system().planets[index].planet[property];
                return x;
            }
        }
        else { return false; }
    }

    apd.currentPlanetIndex = ko.observable(0);
    apd.setCurrentPlanet = function(args, data, event) {
        var index = (typeof args === "function") ? args() : args;
        var pin = (typeof index === "number") ? index : Number(index);
        if (typeof model.system().planets[pin] === "object" && typeof event === "object" && event.type === "mouseover") {
            apd.currentPlanetIndex(pin);
            apd.bShowPlanetDetails(true);
        }
        else {
            apd.bShowPlanetDetails(false);
        }
    };

    apd.bShowPlanetDetails = ko.observable(false);
    apd.bShowDetailPanel = ko.observable(false);
    apd.toggleDetailPanel = function () {
        apd.bShowDetailPanel(!apd.bShowDetailPanel());
    };

    apd.planetNameString = function (value) {
        return value || "Unnamed Planet";
    };
    apd.sizeString = function (index) {
        var sizeVar = planetProperty(index, "radius") || "N/A";
        return model.planetSizeClass(sizeVar);
    };
    apd.areaString = function (index) {
        var radiusVar = planetProperty(index, "radius") || "N/A";
        if (typeof radiusVar === "string") { return radiusVar; }
        radiusVar = 4 * radiusVar * radiusVar * Math.PI;
        radiusVar = radiusVar / 1000000; //from m� to km�
        return radiusVar.toFixed(2);
    };

    apd.seedString = function (index) {
        var seedVar = planetProperty(index, "seed") || "N/A";
        return seedVar;
    };
    apd.radiusString = function (index) {
        var radiusVar = planetProperty(index, "radius") || "N/A";
        return radiusVar;
    };

    apd.dataString = function (index, data) {
        var dataVar = "N/A"; //Only one variable.
        if (model.systemIsEmpty()) { return "N/A"; } //Without this, I'll break Knockout when starting a lobby without a loaded system.  The rest survive without it, maybe because of the foreach data-bind.
        switch (data) {
            case "area":
                dataVar = planetProperty(index, "radius");
                if (!dataVar) { return "N/A"; }
                dataVar = 4 * dataVar * dataVar * Math.PI;
                dataVar = dataVar / 1000000; //from m� to km�
                return dataVar.toFixed(2);
            case "biomeimage":
                dataVar = planetProperty(index, "biome") || "unknown";
                dataVar = ((dataVar === "earth" || dataVar === "tropical") && false) ? "ice" : dataVar;
                return "/main/shared/img/planets/" + dataVar + ".png";
            case "biomesize":
                dataVar = planetProperty(index, "radius");
                if (!dataVar) { return "N/A"; }
                dataVar = Math.floor(Math.min(56, Math.max(8, (dataVar / 20))));
                return dataVar.toString() + "px";
            case "thrusters":
                dataVar = model.system().planets[index].required_thrust_to_move || 0;
                if (typeof dataVar !== "number") { return "N/A"; }
                else {
                    return dataVar.toString();
                }
            default:
                dataVar = planetProperty(index, data);
                return String(dataVar);
        }
    };

    apd.biomeImageSource = function (index) {
        var biomeVar = planetProperty(index, "biome") || "unknown",
        ice = biomeVar === 'earth' && planetProperty(index, "temperature") <= 10, //Temps of -0.5 are no longer possible.
        s = ice ? 'ice' : biomeVar || "unknown";

        return '/main/shared/img/planets/' + s + '.png';
    };
    apd.biomeImageSize = function (index) {
        var radiusVar = planetProperty(index, "radius") || 1200,
        pixels = Math.floor(Math.min(56, Math.max(8, (radiusVar / 20)))); //Fixed 14/02/25

        return pixels.toString() + "px";
    };

    return apd;
}());

$((function () { // BEGIN ====MODIFY DOM====
var newPlanetDetail = '<div class="starting-planet" data-bind="event: { mouseover: apd.setCurrentPlanet.bind($data, 0), mouseout: apd.setCurrentPlanet.bind($data, 0) }">\
<div class="system-loading"  data-bind="visible: model.serverLoading()"></div>\
<img src="coui://ui/main/shared/img/planets/ice-big.png" data-bind="attr: { src: \'/main/shared/img/planets/\' + primaryPlanet().biome + \'-big.png\' }" />\
</div>\
<div style="position:fixed;top:201px;left:190px;border-image: url(\'img/panel_secondary.png\') 8 32 36 12 fill;border-width: 8px 32px 36px 12px;z-index:1;display:none;padding: 5px 0 0 15px;" data-bind="visible: apd.bShowPlanetDetails">\
<div><img data-bind="attr: { src: apd.dataString(apd.currentPlanetIndex(), \'biomeimage\'), height: apd.dataString(apd.currentPlanetIndex(), \'biomesize\'), width: apd.dataString(apd.currentPlanetIndex(), \'biomesize\') }" /></div>\
<div>\
<div class="input_label" data-bind="visible: apd.currentPlanetIndex() === 0">STARTING PLANET</div>\
<div><span>Area: </span><span data-bind="text: apd.dataString(apd.currentPlanetIndex(), \'area\')">AREA</span><span>km&sup2</span></div>\
<div><span>Delta-V: </span><span data-bind="text: apd.dataString(apd.currentPlanetIndex(), \'thrusters\')">DELTA-V</span> <img data-bind="attr: { src: apd.dataString(apd.currentPlanetIndex(), \'thrusters\') != 0 ? \'../live_game/img/planet_list_panel/icon_engine_status_active.png\' : \'../live_game/img/planet_list_panel/icon_engine_status_empty.png\'}"></div>\
<div><span>Radius: </span><span data-bind="text: apd.dataString(apd.currentPlanetIndex(), \'radius\')">RADIUS</span><span>m</span></div>\
<div><span>Seed: </span><span data-bind="text: apd.dataString(apd.currentPlanetIndex(), \'seed\')">SEED</span></div>\
<div><span>Height: </span><span data-bind="text: apd.dataString(apd.currentPlanetIndex(), \'heightRange\')">HEIGHT RANGE</span></div>\
<div><span>Water: </span><span data-bind="text: apd.dataString(apd.currentPlanetIndex(), \'waterHeight\')">WATER HEIGHT</span></div>\
<div><span>Temperature: </span><span data-bind="text: apd.dataString(apd.currentPlanetIndex(), \'temperature\')">TEMPERATURE</span></div>\
<div><span>Metal Density: </span><span data-bind="text: apd.dataString(apd.currentPlanetIndex(), \'metal_density\')">METAL DENSITY</span></div>\
<div><span>Metal Clusters: </span><span data-bind="text: apd.dataString(apd.currentPlanetIndex(), \'metal_clusters\')">METAL CLUSTERS</span></div>\
<div><span>Biome: </span><span data-bind="text: apd.dataString(apd.currentPlanetIndex(), \'biome\')">BIOME</span></div>\
</div>\
</div>',
newOtherPlanets = '<div class="all-planets" data-bind="foreach: otherPlanets">\
<img style="height:20px; width:20px;" src="img/empty.png" data-bind="attr: { src: \'coui://ui/main/shared/img/planets/\' + $data + \'.png\' }, event: { mouseover: $root.apd.setCurrentPlanet.bind($data, $index() + 1), mouseout: $root.apd.setCurrentPlanet.bind($data, $index() + 1) }" />\
</div>',
newPlanetTable = '<div style="position:fixed;top:90px;left:355px;max-height:480px;width:240px;overflow:auto;display:none;padding: 5px 0 0 10px;border-image: url(\'img/panel_secondary.png\') 8 32 36 12 fill;border-width: 8px 32px 36px 12px;z-index:20;"\
data-bind="visible: apd.bShowDetailPanel">\
<table>\
<tbody data-bind="foreach: system().planets">\
<tr><td style="width:56px;text-align:center;vertical-align:middle;">\
<img data-bind="attr: { src: $parent.apd.biomeImageSource($index()), height: $parent.apd.biomeImageSize($index()), width: $parent.apd.biomeImageSize($index()) }" />\
</td><td>\
<div class="input_label" data-bind="visible: $index() === 0"><loc data-i18n="new_game:starting_planet.message" desc="">STARTING PLANET:</loc> </div>\
<div style="text-transform:uppercase;" data-bind="text: $parent.apd.planetNameString(name)"></div>\
<div data-bind="visible: $index() > 0">\
<a href="#" class="text_link_btn text_link_btn_small" data-bind="click: function () { $parent.setPrimaryPlanet($index()); },click_sound:\'default\',rollover_sound: \'default\'">\
<loc data-i18n="new_game:set_as_starting_planet.message" desc="">Set As Starting Planet</loc></a>\
</div>\
<div>\
<span>Size: </span><span style="text-transform:uppercase;" data-bind="text: $parent.apd.sizeString($index())"></span>\
<br><span>Surf. Area: </span><span style="text-transform:uppercase;" data-bind="text: $parent.apd.areaString($index())"></span><span>km&sup2</span>\
</div>\
<div style="margin-bottom:1.0em;" >\
    <span>Delta-Vee: </span><span style="text-transform:uppercase;" data-bind="text: $data.required_thrust_to_move"></span>\
<br><span>Base Radius: </span><span style="text-transform:uppercase;" data-bind="text: $data.planet.radius"></span><span>m</span>\
<br><span>Random Seed: </span><span style="text-transform:uppercase;" data-bind="text: $data.planet.seed"></span>\
<br><span>Height Range: </span><span style="text-transform:uppercase;" data-bind="text: $data.planet.heightRange"></span>\
<br><span>Water Height: </span><span style="text-transform:uppercase;" data-bind="text: $data.planet.waterHeight"></span>\
<br><span>Temperature: </span><span style="text-transform:uppercase;" data-bind="text: $data.planet.temperature"></span>\
<br><span>Metal Density: </span><span style="text-transform:uppercase;" data-bind="text: $data.planet.metal_density"></span>\
<br><span>Metal Clusters: </span><span style="text-transform:uppercase;" data-bind="text: $data.planet.metal_clusters"></span>\
<br></div></td></tr></tbody></table></div>',
showDetailsButton = '<div class="btn_std_gray btn_new_system" style="position:relative;top:0px;left:0px;float:right;width:120px;" data-bind="click: apd.toggleDetailPanel"><div class="btn_std_label">Details</div></div>';

$("#system").prepend(newPlanetTable);
$("#system .system-name").after(showDetailsButton);
$("#system div.starting-planet").replaceWith(newPlanetDetail);
$("#system div.all-planets").replaceWith(newOtherPlanets);
})()); //END ====MODIFY DOM====