(function() {
	model.TNNameToPlanet = function(words){
		var all=model.celestialViewModels();
		var name_length=0;
		var match=false;
		var target_planet=-1;
		for (i=0;i<all.length;i++){
			name_split=all[i].name().split(" ");
			name_length=name_split.length;
			match=true;
			for (j=0;j<name_length;j++){
				if (j<words.length){
					if (words[j]!=name_split[j]){
						match=false;
						break;
					}
				}else{
					match=false;
					break;
				}
			}
			if (match){
				break;
			}
		}
		if (match){
			target_planet=all[i];
		}
		var basket={};
		basket.planet=target_planet;
		basket.read_index=name_length;
		return basket;
	}

	model.TNCheckForNextWords = function(start,words,checks){
		var i=0;
		if (words.length>=start+checks.length){
			for (i=0;i<checks.length;i++){
				if (words[start+i]!=checks[i]){
					return -1;
				}
			}
			return start+i;
		}else{
			return -1;
		}
	}


	model.TeamNoteParsing = function (newchat){
		var last=newchat[newchat.length-1];
		if (!!last.team){
			var words=last.message.split(" ");
			var planetoid=model.TNNameToPlanet(words);
			if (planetoid.planet!=-1){
				index=model.TNCheckForNextWords(planetoid.read_index,words,["has"]);
				if (index!=-1){
					var index2=model.TNCheckForNextWords(index,words,["no","enemies"]);
					if (index2!=-1){
						planetoid.planet["TNShowScoutedEmpty"](true);
						planetoid.planet["TNShowScoutedLight"](false);
						planetoid.planet["TNShowScoutedMedium"](false);
						planetoid.planet["TNShowScoutedHeavy"](false);
						planetoid.planet["TNShowScoutedUnknown"](false);
						if (planetoid.planet==model.celestialViewModels()[model.selectedCelestialIndex()]){
							model.TNCurrentChanger(model.selectedCelestialIndex());
						}
					}
					index2=model.TNCheckForNextWords(index,words,["light","enemy","presence"]);
					if (index2!=-1){
						planetoid.planet["TNShowScoutedEmpty"](false);
						planetoid.planet["TNShowScoutedLight"](true);
						planetoid.planet["TNShowScoutedMedium"](false);
						planetoid.planet["TNShowScoutedHeavy"](false);
						planetoid.planet["TNShowScoutedUnknown"](false);
						if (planetoid.planet==model.celestialViewModels()[model.selectedCelestialIndex()]){
							model.TNCurrentChanger(model.selectedCelestialIndex());
						}
					}
					index2=model.TNCheckForNextWords(index,words,["moderate","enemy","presence"]);
					if (index2!=-1){
						planetoid.planet["TNShowScoutedEmpty"](false);
						planetoid.planet["TNShowScoutedLight"](false);
						planetoid.planet["TNShowScoutedMedium"](true);
						planetoid.planet["TNShowScoutedHeavy"](false);
						planetoid.planet["TNShowScoutedUnknown"](false);
						if (planetoid.planet==model.celestialViewModels()[model.selectedCelestialIndex()]){
							model.TNCurrentChanger(model.selectedCelestialIndex());
						}
					}
					index2=model.TNCheckForNextWords(index,words,["heavy","enemy","presence"]);
					if (index2!=-1){
						planetoid.planet["TNShowScoutedEmpty"](false);
						planetoid.planet["TNShowScoutedLight"](false);
						planetoid.planet["TNShowScoutedMedium"](false);
						planetoid.planet["TNShowScoutedHeavy"](true);
						planetoid.planet["TNShowScoutedUnknown"](false);
						if (planetoid.planet==model.celestialViewModels()[model.selectedCelestialIndex()]){
							model.TNCurrentChanger(model.selectedCelestialIndex());
						}
					}
				}
				index=model.TNCheckForNextWords(planetoid.read_index,words,["might","have","enemy"]);
				if (index!=-1){
					planetoid.planet["TNShowScoutedEmpty"](false);
					planetoid.planet["TNShowScoutedLight"](false);
					planetoid.planet["TNShowScoutedMedium"](false);
					planetoid.planet["TNShowScoutedHeavy"](false);
					planetoid.planet["TNShowScoutedUnknown"](true);
					if (planetoid.planet==model.celestialViewModels()[model.selectedCelestialIndex()]){
						model.TNCurrentChanger(model.selectedCelestialIndex());
					}
				}
			}			
		}		
	}


	model.TNcelestialViewModel = function (element) {
		if (element.length>0){
			element[element.length-1]["TNShowScoutedEmpty"]=ko.observable(false);
			element[element.length-1]["TNShowScoutedUnknown"]=ko.observable(true);
			element[element.length-1]["TNShowScoutedLight"]=ko.observable(false);
			element[element.length-1]["TNShowScoutedMedium"]=ko.observable(false);
			element[element.length-1]["TNShowScoutedHeavy"]=ko.observable(false);
		}
	}


	model.celestialViewModels.subscribe(model.TNcelestialViewModel);
	

	model.ScoutUnknown = function () {
		var msg={};
		msg.message=model.selectedPlanetName()+" might have enemy";
		model.send_message("team_chat_message",msg);
	};
	model.ScoutEmpty = function () {
		var msg={};
		msg.message=model.selectedPlanetName()+" has no enemies";
		model.send_message("team_chat_message",msg);
	};
	model.ScoutLight = function () {
		var msg={};
		msg.message=model.selectedPlanetName()+" has light enemy presence";
		model.send_message("team_chat_message",msg);
	};
	model.ScoutMedium = function () {
		var msg={};
		msg.message=model.selectedPlanetName()+" has moderate enemy presence";
		model.send_message("team_chat_message",msg);
	};
	model.ScoutHeavy = function() {
		var msg={};
		msg.message=model.selectedPlanetName()+" has heavy enemy presence";
		model.send_message("team_chat_message",msg);
	};

	model.TNShowCurrentEmpty = ko.observable(false);
	model.TNShowCurrentLight = ko.observable(true);
	model.TNShowCurrentMedium = ko.observable(false);
	model.TNShowCurrentHeavy = ko.observable(false);
	model.TNShowCurrentUnknown = ko.observable(false);

	model.TNCurrentChanger= function(element){
		var all=model.celestialViewModels();
		model.TNShowCurrentEmpty(all[element]["TNShowScoutedEmpty"]());
		model.TNShowCurrentLight(all[element]["TNShowScoutedLight"]());
		model.TNShowCurrentMedium(all[element]["TNShowScoutedMedium"]());
		model.TNShowCurrentHeavy(all[element]["TNShowScoutedHeavy"]());
		model.TNShowCurrentUnknown(all[element]["TNShowScoutedUnknown"]());
	};

	model.selectedCelestialIndex.subscribe(model.TNCurrentChanger);

	model.ShowCommunication=ko.computed(function () {return !model.isSunSelected()});

	$(".div_planet_list_item_left").prepend("<img class=\"celestial_menu_item\" data-bind= \"visible: $data.TNShowScoutedEmpty\" src=\"coui://ui/mods/sTeamNotes/scout_empty.png\" ></img>");
	$(".div_planet_list_item_left").prepend("<img class=\"celestial_menu_item\" data-bind= \"visible: $data.TNShowScoutedLight\" src=\"coui://ui/mods/sTeamNotes/scout_light.png\" ></img>");
	$(".div_planet_list_item_left").prepend("<img class=\"celestial_menu_item\" data-bind= \"visible: $data.TNShowScoutedMedium\" src=\"coui://ui/mods/sTeamNotes/scout_medium.png\" ></img>");
	$(".div_planet_list_item_left").prepend("<img class=\"celestial_menu_item\" data-bind= \"visible: $data.TNShowScoutedHeavy\" src=\"coui://ui/mods/sTeamNotes/scout_heavy.png\" ></img>");
	$(".div_planet_list_item_left").prepend("<img class=\"celestial_menu_item\" data-bind= \"visible: $data.TNShowScoutedUnknown\" src=\"coui://ui/mods/sTeamNotes/scout_unknown.png\" ></img>");
	$(".div_sidebar_right").append("<div class=\"div_team_notes_bar_top_cont\" ></div>");
	$(".div_team_notes_bar_top_cont").append("<div class=\"div_team_notes_bar receiveMouse\" , data-bind=\"visible:ShowCommunication\" ></div>");
	$(".div_team_notes_bar").append("<div class=\"div_team_notes_bar_cont\" data-bind=\"event:{mouseout: function(){maybeClearHoverIndex(4)}}\" ></div>");
	$(".div_team_notes_bar_cont").append("<div class=\"div_command_item\" data-bind=\"event:{mouseover: function() { setHoverIndex(4)}}\" title=\"SCOUT\" ><a href=\"#\" id=\"TN1a\"><img class=\"icon_team_notes\" data-bind=\"visible: TNShowCurrentEmpty,event:{mouseover: function() { setHoverIndex(4)}}\" src=\"coui://ui/mods/sTeamNotes/scout_empty.png\" ></img></a></div>");
	$(".div_team_notes_bar_cont").append("<a href=\"#\" id=\"TN1b\"><img class=\"icon_team_notes\" data-bind=\"visible: TNShowCurrentLight,event:{mouseover: function() { setHoverIndex(4)}}\" src=\"coui://ui/mods/sTeamNotes/scout_light.png\" ></img></a>");
	$(".div_team_notes_bar_cont").append("<a href=\"#\" id=\"TN1c\"><img class=\"icon_team_notes\" data-bind=\"visible: TNShowCurrentMedium,event:{mouseover: function() { setHoverIndex(4)}}\" src=\"coui://ui/mods/sTeamNotes/scout_medium.png\" ></img></a>");
	$(".div_team_notes_bar_cont").append("<a href=\"#\" id=\"TN1d\"><img class=\"icon_team_notes\" data-bind=\"visible: TNShowCurrentHeavy,event:{mouseover: function() { setHoverIndex(4)}}\" src=\"coui://ui/mods/sTeamNotes/scout_heavy.png\" ></img></a>");
	$(".div_team_notes_bar_cont").append("<a href=\"#\" id=\"TN1e\"><img class=\"icon_team_notes\" data-bind=\"visible: TNShowCurrentUnknown,event:{mouseover: function() { setHoverIndex(4)}}\" src=\"coui://ui/mods/sTeamNotes/scout_unknown.png\" ></img></a>");
	$(".div_team_notes_bar_cont").append("<div class=\"div_scout_menu\" data-bind=\"visible: hoverOrderIndex()==4,event: {mouseover: function(){setHoverIndex(4)}}\" ></div>");
	$(".div_scout_menu").append("<div class=\"div_command_menu_item\" data-bind=\"visible: hoverOrderIndex()==4, click: function(){ScoutEmpty();}\" title=\"SCOUT\"><a href=\"#\" id=\"TN1\" data-bind=\"click_sound:'default', rollover_sound:'default'\"><img class=\"icon_team_notes\" src=\"coui://ui/mods/sTeamNotes/scout_empty.png\"></a></div>");
	$(".div_scout_menu").append("<div class=\"div_command_menu_item\" data-bind=\"visible: hoverOrderIndex()==4, event: {mousedown: function(){ScoutLight();}}\" title=\"SCOUT\"><a href=\"#\" id=\"TN2\" data-bind=\"click_sound:'default', rollover_sound:'default'\"><img class=\"icon_team_notes\" src=\"coui://ui/mods/sTeamNotes/scout_light.png\"></a></div>");
	$(".div_scout_menu").append("<div class=\"div_command_menu_item\" data-bind=\"visible: hoverOrderIndex()==4, event: {mousedown: model.ScoutMedium}\" title=\"SCOUT\"><a href=\"#\" id=\"TN3\" data-bind=\"click_sound:'default', rollover_sound:'default'\"><img class=\"icon_team_notes\" src=\"coui://ui/mods/sTeamNotes/scout_medium.png\"></a></div>");
	$(".div_scout_menu").append("<div class=\"div_command_menu_item\" data-bind=\"visible: hoverOrderIndex()==4, event: {mousedown: function(){ScoutHeavy();}}\" title=\"SCOUT\"><a href=\"#\" id=\"TN4\" data-bind=\"click_sound:'default', rollover_sound:'default'\"><img class=\"icon_team_notes\" src=\"coui://ui/mods/sTeamNotes/scout_heavy.png\"></a></div>");
	$(".div_scout_menu").append("<div class=\"div_command_menu_item\" data-bind=\"visible: hoverOrderIndex()==4, event: {mousedown: function(){ScoutUnknown();}}\" title=\"SCOUT\"><a href=\"#\" id=\"TN4\" data-bind=\"click_sound:'default', rollover_sound:'default'\"><img class=\"icon_team_notes\" src=\"coui://ui/mods/sTeamNotes/scout_unknown.png\"></a></div>");

	model.chatLog.subscribe(model.TeamNoteParsing)

})();
