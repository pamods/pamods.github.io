var t_system_editor_fix = (function () {
    "use strict";

    var t_system_editor_fix = {};

    t_system_editor_fix.validate_generic = function(data) {
        "use strict";

        if (data === null || data === "") {
            return 0;
        }
        return 1;
    };

    t_system_editor_fix.validate_uint = function(data) {
        "use strict";

        if (t_system_editor_fix.validate_generic(data) === 0) {
            return 0;
        }

        var uint_regex = /^\d+$/;
        if(uint_regex.test(data)) {
            return 1;
        }
        return 0;
    };

    return t_system_editor_fix;
})();
