/*
 * Inject a ton of html
 */

// SHARED SYSTEMS tab
$(".div_body_cont div:last").before("<!-- share system viewer --><div id=\"cShareSystems_viewer\" class=\"div_body_centered_cont\" data-bind=\"visible: showSharedSystems\">    <div class=\"div_pre_game_cont\">        <div class=\"div_pre_game_header\">            <div class=\"div_pre_game_title primary_msg\" data-bind=\"html: cShareSystems.modName\">            </div>        </div>        <table class=\"tbl_planet_selector\">            <tbody>                <tr>                    <td style=\"width:690px;\">            <div class=\"cShareSystems_list_container\">            <div class=\"div_planet_list_cont\" data-bind=\"foreach: cShareSystems.systems\">                            <a data-bind=\"click_sound: 'default', rollover_sound: 'default'\">                                <div class=\"div_planet_tile_item\" data-bind=\"click: function () { model.selectedSystemIndex($index()); },                                                                             css: { selected_planet: model.selectedSystemIndex() === $index() }\">                                    <div class=\"div_planet_tile_thumbnail\">                                        <img class=\"img_planet_thumb\" data-bind=\"attr: { src: model.imageSourceForPlanet($data.planets[0]) }\"                                            src=\"../shared/img/icon_planet_sample.png\" />                                    </div>                                    <div class=\"div_planet_tile_title\" style=\"word-wrap: break-word;\">                                        <span data-bind=\"text: $data.name\"></span><span>- </span><span data-bind=\"text: $data.planets.length\"></span>                                        <!-- ko if: model.displayExperimentalSystem($data.planets) -->                                        <div class=\"msg_error account_form_error\"><loc data-i18n=\"load_planet:experimental.message\" desc=\"\">EXPERIMENTAL</loc></div>                                        <!-- /ko -->                                    </div>              <div class=\"div_planet_tile_creator div_planet_tile_title\" style=\"word-wrap: break-word;\">                                  <span data-bind=\"text: $data.creator\"></span></div>                  </div>                            </a>                        </div>          </div>          </td>                    <!----------- SYSTEM DETAIL PANE                     --------------------------------------------------------------------------->                    <td>                        <!-- ko if: !jQuery.isEmptyObject(selectedSystem()) -->                        <div class=\"div_planet_item_detail_cont\" data-bind=\"with: selectedSystem\">                            <div class=\"div_planet_item_detail_img\">                                <img src=\"../shared/img/icon_planet_sample.png\" style=\"width: 200px; height: 200px\"                                     data-bind=\"attr: { src: model.selectedSystemImageSource }\"/>                            </div>                            <div class=\"div_planet_item_detail_title\" data-bind=\"text: name\">                            </div>                            <div>                                <table style=\"width:100%;\">                                    <tbody>                                        <tr>                                            <td>                                                <div class=\"input_label\" style=\"margin-bottom:10px;\"><loc data-i18n=\"load_planet:biome.message\" desc=\"\">Biome</loc></div>                                            </td>                                            <td>                                                <div class=\"input_field_static\" style=\"text-transform:capitalize;\" data-bind=\"text: planets[0].planet.biome\"></div>                                            </td>                                            <td></td>                                        </tr>                                        <tr>                                            <td>                                                <div class=\"input_label\"><loc data-i18n=\"load_planet:radius.message\" desc=\"\">Radius</loc></div>                                            </td>                                            <td>                                                <div class=\"div_planet_property_bar\">                                                    <div class=\"planet_property_bar\" data-bind=\"style: { width: $root.selectedSystemRadiusWidthString() }\"></div>                                                </div>                                            </td>                                            <td>                                                <div class=\"input_field_static\" data-bind=\"text: planets[0].planet.radius\">                                                </div>                                            </td>                                        </tr>                                        <tr>                                            <td>                                                <div class=\"input_label\"><loc data-i18n=\"load_planet:height.message\" desc=\"\">Height</loc></div>                                            </td>                                            <td>                                                <div class=\"div_planet_property_bar\">                                                    <div class=\"planet_property_bar\" data-bind=\"style: { width: $root.selectedSystemHeightWidthString() }\"></div>                                                </div>                                            </td>                                            <td>                                                <div class=\"input_field_static\" data-bind=\"text: planets[0].planet.heightRange\">                                                </div>                                            </td>                                        </tr>                                        <tr>                                            <td>                                                <div class=\"input_label\"><loc data-i18n=\"load_planet:water.message\" desc=\"\">Water</loc></div>                                            </td>                                            <td>                                                <div class=\"div_planet_property_bar\">                                                    <div class=\"planet_property_bar\" data-bind=\"style: { width: $root.selectedSystemWaterWidthString() }\"></div>                                                </div>                                            </td>                                            <td>                                                <div class=\"input_field_static\" data-bind=\"text: planets[0].planet.waterHeight\">                                                </div>                                            </td>                                        </tr>                                        <tr>                                            <td>                                                <div class=\"input_label\"><loc data-i18n=\"load_planet:temp.message\" desc=\"\">Temp</loc></div>                                            </td>                                            <td>                                                <div class=\"div_planet_property_bar\">                                                    <div class=\"planet_property_bar\" data-bind=\"style: { width: $root.selectedSystemTemperatureWidthString() }\"></div>                                                </div>                                            </td>                                            <td>                                                <div class=\"input_field_static\" data-bind=\"text: planets[0].planet.temperature\">                                                </div>                                            </td>                                        </tr>                                        <tr>                                            <td colspan=\"3\">                                                <div>                                                                                                      <a data-bind=\"click_sound: 'default', rollover_sound: 'default'\">                                                        <input type=\"button\" locattr=\"value\" value=\"LOAD\" id=\"Button1\" class=\"btn_std\"                                                                style=\"width: 150px; margin: 10px 0px 0px 10px; float: right;\"                                                               data-bind=\"enable: $root.selectedSystemValid, click: $root.loadSystem\"  />                                                    </a>                                                </div>                                            </td>                                        </tr>                                    </tbody>                                </table>                            </div>                        </div>                        <!-- /ko -->                    </td>                </tr>            </tbody>        </table>    </div></div>");

// Filtering options
$(".div_pre_game_header").append("<div id=\"filter-controls\" data-bind=\"visible: showSharedSystems\">	<div id=\"filter-controls-inner\">		<div>			<table>				<tr>					<td>						<span class=\"input_label\">System Name</span>					</td>					<td>						<input type=\"text\" data-bind=\"value: cShareSystems.filterOptions().name, valueUpdate: 'afterkeydown'\">					</td>				</tr>					<td>						<span class=\"input_label\">Creator</span>					</td>					<td>						<input type=\"text\" data-bind=\"value: cShareSystems.filterOptions().creator, valueUpdate: 'afterkeydown'\">					</td>				</tr>			</table>		</div>		<div style=\"margin-left: 10px;\">			<table>				<tr>					<td>						<span class=\"input_label\">Planets</span>					</td>					<td style=\"padding-left: 10px;\">						<input type=\"number\" min=\"1\" max=\"16\" step=\"1\" data-bind=\"value: cShareSystems.filterOptions().minPlanets, valueUpdate: 'afterkeydown'\">						 - 						<input type=\"number\" min=\"1\" max=\"16\" step=\"1\" data-bind=\"value: cShareSystems.filterOptions().maxPlanets, valueUpdate: 'afterkeydown'\">					</td>				</tr>					<td style=\"padding-top: 1px;\">						<span class=\"input_label\">Sort By</span>					</td>					<td>						<select class=\"div_settings_control_select\" data-bind=\"value: cShareSystems.filterOptions().sort_field, valueUpdate: ['afterkeydown', 'propertychange', 'input']\">							<option value=\"system_id\">Most Recent</option>							<option value=\"num_planets\">Planets</option>						</select>					</td>				</tr>			</table>		</div>	</div></div>");

// SHARED SYSTEMS button
$(".div_body_cont div:last").append("<a data-bind=\"click_sound: 'default', rollover_sound: 'default'\"><input type=\"button\" id=\"btn_show_cShareSystems_systems\" class=\"btn_std\" style=\"width: 200px;  display:inline-block;\" data-bind=\"disable: cShareSystems.hasSaveServers, click: function(){model.show_shared_systems();}, value: cShareSystems.modName\"></a>");

// Pagination buttons
$(".cShareSystems_list_container").append("<div class=\"paginate\"><div class=\"paginate-inner\"><a data-bind=\"click_sound: 'default', rollover_sound: 'default'\"><input type=\"button\" value=\"&lt;\" id=\"Button3001\" class=\"btn_std paginate-button paginate-left\" locattr=\"value\" data-bind=\"enable: cShareSystems.hasPreviousPage, click: function(){cShareSystems.showPreviousPage();}\"></a><a data-bind=\"click_sound: 'default', rollover_sound: 'default'\"><input type=\"button\" value=\"&gt;\" id=\"Button3002\" class=\"btn_std paginate-button paginate-right\" locattr=\"value\" data-bind=\"enable: cShareSystems.hasNextPage, click: function(){cShareSystems.showNextPage();}\"></a></div></div>");

// Server selector
$("#cShareSystems_viewer .div_pre_game_header").append("<div id=\"cSystemSharing_serverselect\" data-bind=\"visible: cShareSystems.showServerOptions\"><div><span class=\"input_label\">Server</span><select class=\"div_settings_control_select\" data-bind=\"options: cShareSystems.serverOptions, optionsText: function(item) { return item.name; }, value: cShareSystems.server\"></div></div>");

// Add a div for the loading animation.
$(".cShareSystems_list_container").append("<div id=\"cSystemSharing_loading_div\" class=\"cSystemSharing_loading_div cSystemSharing_loading_div_load_planet\"></div>");

/*
 * Add some jquery handlers that will force a new search every time a filter is updated.
 */

$("#filter-controls input,select").on("keyup", function() {
	cShareSystems.searchSystems({}, 0);
}).on("click", function() {
	cShareSystems.searchSystems({}, 0);
});


/*
 * Extend the model with a handler for the new button
 */

model.showSharedSystems = ko.observable(false);

model.show_shared_systems = function() {
	model.selectedSystemIndex(-1);
	$(".selected_planet").removeClass("selected_planet");
	model.showSharedSystems(true);
	model.showSystems(false);
	cShareSystems.searchSystems({}, 0, true);
};


/*
 * Override model functions to allow for an extra tab.
 * I really wish the UI just used jquery tabs instead of this nonsense.
 */

// Override
model.showPlanets = ko.computed(function () { return !(model.showSystems() || model.showSharedSystems())});

// Override
model.toggleShowSystem = function() {
	if(model.showSharedSystems()) {
		model.showSystems(true);
		model.showSharedSystems(false);
		model.selectedSystemIndex(-1);
		$(".selected_planet").removeClass("selected_planet");
	} else {
		model.showSystems(!model.showSystems());
	}
};

// Override
model.selectedSystem = ko.computed(function () {
	var systems;
	if(!model.showSharedSystems())
		systems = model.systems;
	else if(model.showSharedSystems())
		systems = cShareSystems.systems;

	var selected_system = systems()[model.selectedSystemIndex()] ? systems()[model.selectedSystemIndex()] : {};

	return selected_system;
});

// Override
model.selectedSystemName = ko.computed(function () {
	if(!model.showSharedSystems())
		return (model.systems()[model.selectedSystemIndex()]) ? model.systems()[model.selectedSystemIndex()].name : '';
	else if(model.showSharedSystems())
		return (cShareSystems.systems()[model.selectedSystemIndex()]) ? cShareSystems.systems()[model.selectedSystemIndex()].name : '';
});

