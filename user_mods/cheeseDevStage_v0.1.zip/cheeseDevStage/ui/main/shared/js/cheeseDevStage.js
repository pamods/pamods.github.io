$('.div_version_info_cont span noloc').html("Cheese v.");
console.log("LOADED");
