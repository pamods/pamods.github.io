function injectInGameBrowser() {
 	loadScript("coui://ui/main/shared/js/cheeseDevStage.js");
}

if ( document.addEventListener ) {
	document.addEventListener( "DOMContentLoaded", function(){
		document.removeEventListener( "DOMContentLoaded", arguments.callee, false);
		injectInGameBrowser();
	}, false );
}
