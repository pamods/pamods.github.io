$('.slot-color-primary').each( function() {
  var databindstr = $(this).attr('data-bind');
  databindstr = databindstr.replace(
    "\'background\': slot.primaryColor",
    "\'background\': slot.primaryColor, \'border-color\': slot.secondaryColor, \'border-width\': \'3px\'"
  );
  $(this).attr('data-bind', databindstr);
});