$(function() {
	model.pips = [model.pips[nScreens.pipIndex*2+1]];
	model.showPips(true);
	
	nScreenFixUi();
});