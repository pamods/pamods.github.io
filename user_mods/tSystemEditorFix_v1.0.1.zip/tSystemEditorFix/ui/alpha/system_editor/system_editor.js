﻿/* includes mod rRandomPlanetName by raevn */

var model;
var handlers;

var PLANET_X_OFFSET = -190;
var PLANET_Y_OFFSET = 0;

$(document).ready(function () {

    ko.extenders.slider = function (target, option) {
        var v;

        // write changes to storage
        target.subscribe(function (newValue) {
            if (newValue !== $('#slider_' + option).slider("option", "value"))
                $('#slider_' + option).slider("option", "value", newValue);
        });

        return target;
    };

    //function clamp (val, min, max) {
    //    return Math.max(min, Math.min(max, val));
    //}

    //function validatePlanetBP(planet) {
    //    var p = {};
    //    p.seed = typeof planet.seed != "undefined" ? clamp (planet.seed, 0, 32767): 6543;
    //    p.radius = typeof planet.radius != "undefined" ? clamp (planet.radius, 0, 32767): 6543;
    //    p.heightRange = typeof planet.heightRange != "undefined" ? clamp (planet.heightRange, 0, 32767): 6543;
    //    p.waterHeight = typeof planet.waterHeight != "undefined" ? clamp (planet.waterHeight, 0, 32767): 6543;
    //    p.temperature = typeof planet.temperature != "undefined" ? clamp (planet.temperature, 0, 32767): 6543;
    //    p.metalDensity = typeof planet.metalDensity != "undefined" ? clamp (planet.metalDensity, 0, 32767): 6543;
    //    p.metalClusters = typeof planet.metalClusters != "undefined" ? clamp (planet.metalClusters, 0, 32767): 6543;
    //    p.biomeScale = typeof planet.biomeScale != "undefined" ? clamp (planet.biomeScale, 0, 32767): 6543;
    //    p.biome = typeof planet.biome != "undefined" && (planet.biome == "earth" || planet.biome == "lava" 
    //        || planet.biome == "metal" || planet.biome == "moon" || planet.biome == "tropical") ? planet.biome : 'earth';
    //    return p;
    //}

    //function validatePlanetSpec(spec) {
    //    var ps = {}
    //    ps.name = typeof ps.name != "undefined" ? ps.name : "Planet";
    //    ps.mass = typeof ps.name != "undefined" ? clamp (ps.mass, 1000, 10000): 1000;
    //    ps.position_x = typeof ps.position_x != "undefined" ? clamp (ps.position_x, -500000, 500000): 20000;
    //    ps.position_y = typeof ps.position_y != "undefined" ? clamp (ps.position_y, -500000, 500000): 0;
    //    ps.velocity_x = typeof ps.velocity_x != "undefined" ? clamp (ps.velocity_x, -300, 300): 0;
    //    ps.velocity_y = typeof ps.velocity_y != "undefined" ? clamp (ps.velocity_y, -300, 300): 0;
    //    ps.planet = validatePlanetBP(spec.planet);

    //    return ps;
    //}

    //function validateSystem(system) {
    //    var s = {};
    //    s.name = ;
    //    s.planets = [];
    //    for (var i in system.planets)
    //        s.planets.push(validatePlanetSpec(system.planets[i]))
    
    //    return s;
    //}

    //function validatePlanets(planets) {
    //    var array = [];
    //    for (var i in planets) {));
    //    }
    //    return array;
    //}

    //function validateSystems(systems) {
    //    var array = [];
    //    for (var i in planets) {
    //        array.push(validateSystem(systems[i]));
    //    }
    //    return array;
    //}

    function PlanetModel(planet) {
        var self = this;
        self.seed = planet.seed;
        self.radius = planet.radius;
        self.heightRange = planet.heightRange;
        self.waterHeight = planet.waterHeight;
        self.temperature = planet.temperature;
        self.metalDensity = planet.metalDensity;
        self.metalClusters = planet.metalClusters;
        self.biomeScale = planet.biomeScale;
        self.biome = planet.biome;
    }

    function PlanetSpec(spec) {
        var self = this;
        self.name = spec.name;
        self.mass = spec.mass;
        self.position_x = spec.position_x;
        self.position_y = spec.position_y;
        self.velocity_x = spec.velocity_x;
        self.velocity_y = spec.velocity_y;
        self.planet = new PlanetModel(spec.planet);
    }

    function SystemModel(system) {
        var self = this;
        self.name = system.name;
        self.planets = [];
        for (index in system.planet_specs)
            self.planets.push(new PlanetSpec(system.planet_specs[index]));
    }

    var defaultSystem = {
        name: 'systemTemplate',
        planets: [
            {
                mass : 2500,
                position_x : 0,
                position_y : 0,
                velocity_x : 0,
                velocity_y: 0,
                name: 'planet 0',
                planet: {
                    seed: 0,
                    radius: 700,
                    heightRange: 25,
                    waterHeight: 50,
                    temperature: 50,
                    metalDensity: 50,
                    metalClusters: 50,
                    biome: 'earth',
                    biomeScale: 50
                }
            }
        ]
    }

    function PlanetTemplates() {
        var self = this;
        self.templates = [
         {
             name: "earth template",
             mass: 3000,
             planet: {
                 seed: 31541,
                 radius: 800,
                 heightRange: 50,
                 waterHeight: 50,
                 temperature: 50,
                 metalDensity: 50,
                 metalClusters: 50,
                 biome: 'earth',
                 biomeScale: 50
             }
         },
         {
             name: "desert template",
             mass: 1800,
             planet: {
                 seed: 3348,
                 radius: 560,
                 heightRange: 50,
                 waterHeight: 38,
                 temperature: 100,
                 metalDensity: 50,
                 metalClusters: 50,
                 biome: 'earth',
                 biomeScale: 50
             }
         },
         {
             name: "ice template",
             mass: 2000,
             planet: {
                 seed: 14451,
                 radius: 600,
                 heightRange: 50,
                 waterHeight: 55,
                 temperature: 0,
                 metalDensity: 50,
                 metalClusters: 50,
                 biome: 'earth',
                 biomeScale: 50
             }
         },
         {
             name: "tropical template",
             mass: 2100,
             planet: {
                 seed: 21542,
                 radius: 620,
                 heightRange: 65,
                 waterHeight: 55,
                 temperature: 80,
                 metalDensity: 50,
                 metalClusters: 50,
                 biome: 'tropical',
                 biomeScale: 50
             }
         },
         {
             name: "metal template",
             mass: 2800,
             planet: {
                 seed: 6846,
                 radius: 760,
                 heightRange: 0,
                 waterHeight: 0,
                 temperature: 50,
                 metalDensity: 50,
                 metalClusters: 50,
                 biome: 'metal',
                 biomeScale: 50
             }
         },
         {
             name: "lava template",
             mass: 2500,
             planet: {
                 seed: 7846,
                 radius: 700,
                 heightRange: 60,
                 waterHeight: 40,
                 temperature: 100,
                 metalDensity: 50,
                 metalClusters: 50,
                 biome: 'lava',
                 biomeScale: 50
             }
         },
         {
             name: "moon template",
             mass: 1000,
             planet: {
                 seed: 78462,
                 radius: 400,
                 heightRange: 75,
                 waterHeight: 0,
                 temperature: 0,
                 metalDensity: 50,
                 metalClusters: 50,
                 biome: 'moon',
                 biomeScale: 50
             }
         }
        ]
    }

    function SystemEditorViewModel() {
        var self = this;

        self.system = ko.observable(new SystemModel(defaultSystem));
        self.selectedPlanetIndex = ko.observable(-1);

        self.buildVersion = ko.observable().extend({ session: 'build_version' });

        self.showPopUP = ko.observable(false);
        self.popUpPrimaryMsg = ko.observable("test primary msg");
        self.popUpSecondaryMsg = ko.observable("secondary msg");
        self.popUpPrimaryButtonAction = function () { };
        self.popUpSecondaryButtonAction = function () { };
        self.popUpTertiaryButtonAction = function () { };
        self.popUpPrimaryButtonTag = ko.observable(loc('!LOC(system_editor:accept.message):Accept'));
        self.popUpSecondaryButtonTag = ko.observable(loc('!LOC(system_editor:cancel.message):Cancel'));
        self.popUpTertiaryButtonTag = ko.observable(false);

        self.planets = ko.observableArray([]).extend({ local: 'planets' });
        self.systems = ko.observableArray([]).extend({ local: 'systems' });

        self.buildBarHoverPlanet = ko.observable({});
        self.showBuildBarHover = ko.observable(false);
        self.buildBarHoverRadiusWidthString = ko.computed(function () { if ( !jQuery.isEmptyObject(self.buildBarHoverPlanet())) return String(self.buildBarHoverPlanet().planet.radius / 20) + 'px'; });
        self.buildBarHoverHeightWidthString = ko.computed(function () { if (!jQuery.isEmptyObject(self.buildBarHoverPlanet())) return String(self.buildBarHoverPlanet().planet.heightRange) + 'px'; });
        self.buildBarHoverWaterWidthString = ko.computed(function () { if (!jQuery.isEmptyObject(self.buildBarHoverPlanet())) return String(self.buildBarHoverPlanet().planet.waterHeight) + 'px'; });
        self.buildBarHoverTemperatureWidthString = ko.computed(function () { if (!jQuery.isEmptyObject(self.buildBarHoverPlanet())) return String(self.buildBarHoverPlanet().planet.temperature) + 'px'; });
        self.defaultTemplates = ko.observableArray(new PlanetTemplates().templates);
        self.recentTemplates = ko.observableArray([]).extend({ local: 'recentPlanets' });
        self.buildbarPageSize = ko.computed(function () { return Math.floor(($('#page').width() - 140) / 65); })
        self.buildBarPage = ko.observable(0);
        self.buildBarPageOffset = ko.observable(0);
        self.buildBarDisplayList = ko.observableArray(self.defaultTemplates);
        self.buildBarDisplayItems = ko.computed(function () {
            var start = self.buildBarPage() * self.buildbarPageSize() + self.buildBarPageOffset();
            var end = start + self.buildbarPageSize();
            return self.buildBarDisplayList.slice(start, end);
        });
        self.shiftBuildListLeft = function () {
            if(self.buildBarPage() === 0) {
                self.buildBarPageOffset(0)
                return;
            }
            self.buildBarPage(self.buildBarPage() - 1)
        };
        self.shiftBuildListRight = function () { 
            var end = (self.buildBarPage() + 1) * self.buildbarPageSize() + self.buildbarPageSize()
            if ( end > self.buildBarDisplayList()().length) {
                self.buildBarPageOffset(self.buildBarDisplayList()().length - (self.buildBarPage() * self.buildbarPageSize() + self.buildbarPageSize()));
                return
            }
            self.buildBarPage(self.buildBarPage() + 1 )
        };
        self.buildBarModes = ko.observableArray(['templates', 'recent', 'my_planets']);
        self.buildBarSelectedMode = ko.observable(self.buildBarModes()[0]);
        self.setBuildBarMode = function (mode) {
            if (mode != self.buildBarSelectedMode()) {
                if (mode === self.buildBarModes()[0]) {
                    self.buildBarSelectedMode(self.buildBarModes()[0]);
                    self.buildBarDisplayList(self.defaultTemplates);
                }
                if (mode === self.buildBarModes()[1] && self.recentTemplates().length > 0) {
                    self.buildBarSelectedMode(self.buildBarModes()[1]);
                    self.buildBarDisplayList(self.recentTemplates);
                }
                if (mode === self.buildBarModes()[2] && self.planets().length > 0) {
                    self.buildBarSelectedMode(self.buildBarModes()[2]);
                    self.buildBarDisplayList(self.planets);
                }
            }
            self.buildBarPageOffset(0);
            self.buildBarPage(0);
        };
        self.showBuildIndexOffsetLeftArrow = ko.computed(function () { if (self.buildBarPage() > 0 || self.buildBarPageOffset() > 0) return true; return false; });
        self.showBuildIndexOffsetRightArrow = ko.computed(function () {
            //console.log("next page start " + (self.buildBarPage() * self.buildbarPageSize() + self.buildbarPageSize() + self.buildBarPageOffset()) + " list size " + self.buildBarDisplayList().length);
            if (self.buildBarPage()* self.buildbarPageSize() + self.buildbarPageSize() + self.buildBarPageOffset() < self.buildBarDisplayList()().length) 
                return true;
            return false;
        });
        self.useRandomPlanetName = ko.computed(function () {
            return self.buildBarSelectedMode() === 'templates';
        });
        self.imageSourceForPlanet = function (planetSpec) {
            if (typeof planetSpec != "undefined" && typeof planetSpec.planet != "undefined") {
                var s =  planetSpec.planet.biome;
                var ice = planetSpec.planet.biome === 'earth' && planetSpec.planet.temperature <= 33;
                var desert = planetSpec.planet.biome === 'earth' && planetSpec.planet.temperature >= 75;
                if (ice)
                    s = 'ice' ;
                else if (desert)
                    s = 'desert';

                return '../shared/img/' + s + '.png';
            }
        }
        self.UpdateRecentTemplates = function (planet) {
            var p = new PlanetSpec(planet)
            delete p.position_x;
            delete p.position_y;
            delete p.velocity_x;
            delete p.velocity_y;
            for (var i in self.recentTemplates()) {
                if (self.recentTemplates()[i].name === p.name) {
                    if (i != 0) {
                        self.recentTemplates.splice(i, 1, self.recentTemplates()[i - 1]);
                        self.recentTemplates.splice(i-1, 1, p)
                    }
                    return;
                }
            }
            if (self.recentTemplates().length < 10) {
                self.recentTemplates.push(p);
                return;
            }
            self.recentTemplates.pop();
            self.recentTemplates.push(p);
        }

        self.validSelectedPlanet = ko.computed(function () { return self.selectedPlanetIndex() >= 0;})

        self.showControls = ko.observable(true);
        self.hideControls = ko.computed(function () { return !self.showControls(); });

        self.modes = ko.observableArray(['planet', 'system']);
        self.selectedMode = ko.observable(self.modes()[0]);
        self.showPlanetEditor = ko.computed(function () { return self.selectedMode() === self.modes()[0] && self.showControls() });
        self.showSystemEditor = ko.computed(function () { return self.selectedMode() === self.modes()[1] && self.showControls() });
        self.showBuildBar = ko.computed(function () { return self.selectedMode() === self.modes()[1] });
        
        self.loadedPlanet = ko.observable().extend({ session: 'loaded_planet' });
        self.loadedSystem = ko.observable().extend({ session: 'loaded_system' });
        //self.showNewPlanet = ko.computed(function () { return jQuery.isEmptyObject(self.loadedPlanet())});
        //self.showEditPlanet = ko.computed(function () { return !self.showNewPlanet() });

        self.systemName = ko.observable('Beta System');
        self.systemLoaded = ko.observable(false);

        self.lastSavedSystemName = ko.observable("");
        self.saveDirty = ko.observable(false);

        self.planetName = ko.observable('');
        self.seed = ko.observable(0).extend({ slider: 'seed'});
        self.radius = ko.observable(700).extend({ slider: 'radius' });
        self.heightRange = ko.observable(50).extend({ slider: 'height_range' });
        self.biomeScale = ko.observable(50).extend({ slider: 'biome_scale' });
        self.waterHeight = ko.observable(50).extend({ slider: 'water_height' });
        self.temperature = ko.observable(50).extend({ slider: 'temperature' });
        self.metalDensity = ko.observable(50).extend({ slider: 'metal_density' });
        self.metalClusters = ko.observable(50).extend({ slider: 'metal_clusters' });

        self.biomes = ko.observableArray(['earth', 'lava', 'metal', 'moon', 'tropical']);
        self.selectedBiome = ko.observable(self.biomes()[0]);

        self.mass = ko.observable(2500).extend({ slider: 'mass' });
        self.position_x = ko.observable(15000).extend({ slider: 'positon_x' });
        self.position_y = ko.observable(0).extend({ slider: 'positon_y' });
        self.velocity_x = ko.observable(0).extend({ slider: 'velocity_x' });
        self.velocity_y = ko.observable(0).extend({ slider: 'velocity_y' });
        self.displayOrbit = ko.observable();
        self.sandboxPhysics = ko.observable();

        self.biomeError = ko.computed(function () { return '' });
        self.radiusError = ko.computed(function () { return self.radius() > 1200 ? 'experimental' : '' });
        self.waterHeightError = ko.computed(function () { return self.waterHeight() > 60 ? 'experimental' : '' });
        self.planetUnderConstruction = ko.observable(false);
        self.planetUnderConstruction.subscribe(function (mode) {
            if (mode) {
                $("#slider_seed").slider('disable');
                $("#slider_radius").slider('disable');
                $("#slider_height_range").slider('disable');
                $("#slider_biome_scale").slider('disable');
                $("#slider_water_height").slider('disable');
                $("#slider_temperature").slider('disable');
            }
            else {
                $("#slider_seed").slider('enable');
                $("#slider_radius").slider('enable');
                $("#slider_height_range").slider('enable');
                $("#slider_biome_scale").slider('enable');
                $("#slider_water_height").slider('enable');
                $("#slider_temperature").slider('enable');
            }
        });

        self.initSlidersFromLoadedPlanet = function () {
            self.planetName(self.loadedPlanet().name);
            self.seed(self.loadedPlanet().seed);
            self.radius(self.loadedPlanet().radius);
            self.heightRange(self.loadedPlanet().heightRange);
            self.biomeScale(self.loadedPlanet().biomeScale);
            self.waterHeight(self.loadedPlanet().waterHeight);
            self.temperature(self.loadedPlanet().temperature);
            self.metalDensity(self.loadedPlanet().metalDensity);
            self.metalClusters(self.loadedPlanet().metalClusters);
            self.selectedBiome(self.loadedPlanet().biome);
        }

        self.addPlanet = function (planetSpec, attachToMouse, randomName) {
            if (planetSpec) {
                if (attachToMouse)
                    planetSpec.attachToMouse = true;
                engine.call('execute', 'add_planet', JSON.stringify(planetSpec));
                self.UpdateRecentTemplates(planetSpec);
                if (randomName)
                    self.new_planet_name();
            }
        };
        self.removePlanet = function () {
            engine.call('execute', 'remove_planet', JSON.stringify({}));
        };
        self.removeAllPlanets = function () {
            engine.call('execute', 'remove_all_planets', JSON.stringify({}));
        };
        self.pause = function () {
            engine.call('execute', 'pause', JSON.stringify({}));
        };
        self.toggleOrbitDisplay = function () {
            engine.call('execute', 'toggle_orbit_display', JSON.stringify({}));
        };
        //self.togglePhysicsMode = function () {
        //    engine.call('execute', 'toggle_physics_mode', JSON.stringify({}));
        //};
        self.buildAllPlanets = function () {
            self.planetUnderConstruction(true);

            function fn() {
                engine.call('execute', 'build_all_planets', JSON.stringify({}));
            }
            setTimeout(fn, 250);
        };

        /// Camera API
        self.cameraMode = ko.observable('planet');
        self.cameraMode.subscribe(function(mode) {
            api.camera.track(false);
            api.camera.setMode(mode);
            if (mode === 'space')
                api.camera.track(true);
        });
        self.focusPlanet = ko.observable(0);
        self.focusPlanet.subscribe(function(index) {
            if (self.cameraMode !== 'space')
                api.camera.track(false);
            api.camera.focusPlanet(index);
        });
        self.alignCameraToPole = function() {
            api.camera.alignToPole();
        };
        /// End Camera API

        self.transitionInToPlanetEditor = function () {
            api.camera.focusPlanet(self.selectedPlanetIndex());
            api.camera.setMode('planet');
        };

        self.transitionOutOfPlanetEditor = function () {
            //api.camera.setZoom('celestial');
            function fn() {
                api.camera.setMode('space');
            }
            setTimeout(fn, 350);
        };

        self.lastSceneUrl = ko.observable('../live_game/live_game.html').extend({ session: 'last_scene_url' });

        self.navBack = function () {
            //if (self.planetUnderConstruction())
            //    return;

            if (self.saveDirty() && self.systemValid() && self.lastSavedSystemName() === self.systemName()) {
                self.showPopUP(true);
                self.popUpPrimaryMsg(loc("!LOC(system_editor:do_you_want_to_save_this_system.message):Do you want to save this system?"));
                self.popUpSecondaryMsg(loc("!LOC(system_editor:the_system_has_been_changed_since_it_was_last_saved.message):The system has been changed since it was last saved."));
                self.popUpPrimaryButtonAction = function () { self.showPopUP(false); self.saveSystem(); self.navBack(); };
                self.popUpSecondaryButtonAction = function () { self.showPopUP(false); self.saveDirty(false); self.navBack(); };
                self.popUpTertiaryButtonAction = function () { self.showPopUP(false); };
                self.popUpPrimaryButtonTag(loc('!LOC(system_editor:save_mixed_case.message):Save'));
                self.popUpSecondaryButtonTag(loc('!LOC(system_editor:discard.message):Discard'));
                self.popUpTertiaryButtonTag(loc('!LOC(system_editor:cancel.message):Cancel'));
            }
            else if (self.saveDirty() && self.systemValid()) {
                self.showPopUP(true);
                self.popUpPrimaryMsg(loc("!LOC(system_editor:do_you_want_to_save_this_system.message):Do you want to save this system?"));
                self.popUpSecondaryMsg(loc("!LOC(system_editor:the_system_has_not_been_saved.message):The system has not been saved."));
                self.popUpPrimaryButtonAction = function () { self.showPopUP(false); self.saveSystem(); self.navBack(); };
                self.popUpSecondaryButtonAction = function () { self.showPopUP(false); self.saveDirty(false); self.navBack(); };
                self.popUpTertiaryButtonAction = function () { self.showPopUP(false); };
                self.popUpPrimaryButtonTag(loc('!LOC(system_editor:save_mixed_case.message):Save'));
                self.popUpSecondaryButtonTag(loc('!LOC(system_editor:discard.message):Discard'));
                self.popUpTertiaryButtonTag(loc('!LOC(system_editor:cancel.message):Cancel'));
            }
            else {
                engine.call("reset_game_state");

                self.loadedPlanet({});
                self.loadedSystem({});

                if (self.lastSceneUrl()) {
                    engine.call('pop_mouse_constraint_flag');
                    window.location.href = self.lastSceneUrl();
                }
                else {
                    console.log('lastSceneUrl invalid');
                }
            }
        };

        self.blueprint = function () {
            //tSystemEditorFix
            //check user input for errors. If found, replace with systemTemplate defaults
            if (t_system_editor_fix.validate_uint(self.seed()) === 0) {
                self.seed(0);
            }
            if (t_system_editor_fix.validate_uint(self.radius()) === 0) {
                self.radius(700);
            }
            if (t_system_editor_fix.validate_uint(self.heightRange()) === 0) {
                self.heightRange(25);
            }
            if (t_system_editor_fix.validate_uint(self.waterHeight()) === 0) {
                self.waterHeight(50);
            }
            if (t_system_editor_fix.validate_uint(self.temperature()) === 0) {
                self.temperature(50);
            }
            if (t_system_editor_fix.validate_uint(self.metalDensity()) === 0) {
                self.metalDensity(50);
            }
            if (t_system_editor_fix.validate_uint(self.metalClusters()) === 0) {
                self.metalClusters(50);
            }
            //biome TODO
            if (t_system_editor_fix.validate_uint(self.biomeScale()) === 0) {
                self.biomeScale(50);
            }

            var bp = {};
            bp.seed = self.seed();
            bp.radius = self.radius();
            bp.heightRange = self.heightRange();
            bp.biomeScale = self.biomeScale();
            bp.waterHeight = self.waterHeight();
            bp.temperature = self.temperature();
            bp.metalDensity = self.metalDensity();
            bp.metalClusters = self.metalClusters();
            bp.biome = self.selectedBiome();
            return bp;
        }

        self.planetSpec = function () {
            var spec = {};
            spec.name = self.planetName();
            spec.mass = Number(self.mass());
            spec.velocity_x = Number(self.velocity_x());
            spec.velocity_y = Number(self.velocity_y());
            spec.position_x = Number(self.position_x());
            spec.position_y = Number(self.position_y());
            spec.planet = self.blueprint();
            return spec;
        }

        self.update_planet = function () {
            self.planetUnderConstruction(true);

            function fn() {
                engine.call('execute', 'set_planet_offset', JSON.stringify({ x_offset: PLANET_X_OFFSET, y_offset: PLANET_Y_OFFSET }));
                engine.call('execute', 'update_planet', JSON.stringify(self.planetSpec()));
            }
            
            setTimeout(fn, 250);
        }

        self.update_planet_spec = function () {
            engine.call('execute', 'update_planet_spec', JSON.stringify(self.planetSpec()));
        }

        self.update_planet_bp = function () {
            engine.call('execute', 'update_planet_bp', JSON.stringify(self.planetBP()));
        }

        self.savePlanet = function () {
            var a = self.planets();
            var b = self.planetSpec();

            //if (b.index) { // if the blueprint has been saved before
            //    a.forEach(function (element, index, array) {
            //        console.log(element.index);
            //        console.log(b.index);
            //        if (b.index === element.index) // overwrite save
            //            array[index] = b;
            //    });
            //}
            //else
            //    a.push(b);

            //a.forEach(function (data, index, array) {
            //    data.index = index + 1;
            //});

            var saved = false;
            for (var index in a) {
                if (a[index].name === b.name) {
                    a[index] = b;
                    saved = true;
                    break;
                }
            }
            if (!saved)
                a.push(b)

            self.loadedPlanet(b);
            self.planets(a);
        }

        self.systemValid = ko.computed(function ()
        {
            if (!jQuery.isEmptyObject(self.system()))
                return self.system().planets.length > 0;
            return false;
        });

        self.saveSystem = function () {
            var a = self.systems();
            var b = self.system();

            b.name = self.systemName();

            var saved = false;
            for (var index in a) {
                if (a[index].name === b.name) {
                    a[index] = b;
                    saved = true;
                    break;
                }
            }
            if (!saved)
                a.push(b)

            self.systems(a);
            self.saveDirty(false);
            self.lastSavedSystemName(b.name);
        }

        self.setSliders = function () {
            if (self.selectedPlanetIndex() == -1)
                return;
            var p = self.system().planets[self.selectedPlanetIndex()];

            self.planetName(p.name);
            self.seed(p.planet.seed);
            self.radius(p.planet.radius);
            self.heightRange(p.planet.heightRange);
            self.biomeScale(p.planet.biomeScale);
            self.waterHeight(p.planet.waterHeight);
            self.temperature(p.planet.temperature);
            self.metalDensity(p.planet.metalDensity);
            self.metalClusters(p.planet.metalClusters);
            self.selectedBiome(p.planet.biome);

            self.mass(p.mass);
            self.position_x(p.position_x);
            self.position_y(p.position_y);
            self.velocity_x(p.velocity_x);
            self.velocity_y(p.velocity_y);
        }
        self.changeSelectedPlanet = function (index) {
            self.selectedPlanetIndex(index);
            if (typeof self.system().planets != "undefined" && self.system().planets.length > -1)
                self.setSliders();
        }
        self.handleHideControls = function () {
            model.showControls(false);
            engine.call('execute', 'set_planet_offset', JSON.stringify({ x_offset: 0, y_offset: 0 }));
        }
        self.handleShowControls = function () {
            model.showControls(true);
            engine.call('execute', 'set_planet_offset', JSON.stringify({ x_offset: PLANET_X_OFFSET, y_offset: PLANET_Y_OFFSET }));
        }
        self.toggleStellarGrid = function () {
            if (self.selectedMode() === self.modes()[1])
                engine.call('execute', 'toggle_stellar_grid', JSON.stringify({}));
        }

        self.new_planet_name = function () {
            engine.call('request_random_planet_name');
        }

        self.setStartingPlanet = function (index) {
            engine.call('execute', 'set_start_planet', JSON.stringify({index: index}));
        }

        self.issueCancel = function () {
            engine.call('execute', 'cancel', JSON.stringify({}));
        }

        self.handleLoad = function () {
            if (!jQuery.isEmptyObject(self.loadedSystem())) {
                self.systemName(self.loadedSystem().name)
                for (var i in self.loadedSystem().planets) {
                    self.addPlanet(self.loadedSystem().planets[i]);
                }
                self.saveDirty(false);
                self.lastSavedSystemName(self.systemName());
            }
            else if (!jQuery.isEmptyObject(self.loadedPlanet())) {
                var planetSpec = self.loadedPlanet();
                planetSpec.position_x = 20000;
                planetSpec.position_y = 0;
                planetSpec.velocity_x = 0;
                planetSpec.velocity_y = 0;
                
                self.addPlanet(planetSpec);
            }
        }
        
        // Temporary handler for camera mouse button control binding
        // TODO: Update for holodeck use
        $('body').mousedown(function(mdevent) {
            if (mdevent.button === 1)
            {
                engine.call('systemEditor.beginControlCamera');
                input.capture(function (event) {
                    var mouseDone = ((event.type === 'mouseup') && (mdevent.button === 1));
                    var escKey = ((event.type === 'keypress') && (event.keyCode === keyboard.esc));
                    if (mouseDone || escKey)
                    {
                        input.release();
                        engine.call('systemEditor.endControlCamera');
                    }
                });
                mdevent.preventDefault();
                mdevent.stopPropagation();
                return;
            }
        });
    }
    model = new SystemEditorViewModel();

    handlers = {};
    handlers.planets_are_ready =  function (payload) {
        model.planetUnderConstruction(false);
    }
    handlers.camera_type = function (payload) {
        if (payload.camera_type === "planet")
            model.selectedMode(model.modes()[0]);
        else if (payload.camera_type === "space")
            model.selectedMode(model.modes()[1]);
    }
    handlers.system_blueprint = function (payload) {
        model.system(new SystemModel(payload.system));
        model.setSliders();
        model.saveDirty(true);
    }
    handlers.selected_planet_index = function (payload) {
        model.changeSelectedPlanet(payload.index);
    }
    handlers.random_planet_name = function (payload) {
        console.log(payload);
        model.planetName(payload.name);
        model.update_planet_spec();
    }

    // inject per scene mods
    if (scene_mod_list['system_editor'])
        loadMods(scene_mod_list['system_editor']);

    // setup send/recv messages and signals
    app.registerWithCoherent(model, handlers);

    // Activates knockout.js
    ko.applyBindings(model);

    engine.call("start_system_editor");
    engine.call('execute', 'set_planet_offset', JSON.stringify({ x_offset: PLANET_X_OFFSET, y_offset: PLANET_Y_OFFSET }));

    //if (model.showNewPlanet())
    //    engine.call('request_random_planet_name');

    model.handleLoad();

    $("#slider_seed").slider({
        range: "max",
        min: 0,
        max: 32767,
        value: model.seed(),
        slide: function (event, ui) { model.seed(ui.value); model.update_planet_spec(); }
    });
    $("#slider_radius").slider({
        range: "max",
        min: 200,
        max: 2000,
        value: model.radius(),
        slide: function (event, ui) { model.radius(ui.value); model.update_planet_spec(); }
    });
    $("#slider_height_range").slider({
        range: "max",
        min: 0,
        max: 100,
        value: model.heightRange(),
        slide: function (event, ui) { model.heightRange(ui.value); model.update_planet_spec(); }
    });
    $("#slider_biome_scale").slider({
        range: "max",
        min: 0,
        max: 100,
        value: model.biomeScale(),
        slide: function (event, ui) { model.biomeScale(ui.value); model.update_planet_spec(); }
    });
    $("#slider_water_height").slider({
        range: "max",
        min: 0,
        max: 100,
        value: model.waterHeight(),
        slide: function (event, ui) { model.waterHeight(ui.value); model.update_planet_spec(); }
    });
    $("#slider_temperature").slider({
        range: "max",
        min: 0,
        max: 100,
        value: model.temperature(),
        slide: function (event, ui) { model.temperature(ui.value); model.update_planet_spec(); }
    });
    $("#slider_metal_density").slider({
        range: "max",
        min: 0,
        max: 100,
        value: model.metalDensity(),
        slide: function (event, ui) { model.metalDensity(ui.value); model.update_planet_spec(); }
    });
    $("#slider_metal_clusters").slider({
        range: "max",
        min: 0,
        max: 100,
        value: model.metalClusters(),
        slide: function (event, ui) { model.metalClusters(ui.value); model.update_planet_spec(); }
    });  
    $("#slider_mass").slider({
        range: "max",
        min: 1000,
        max: 10000,
        value: model.mass(),
        slide: function (event, ui) { model.mass(ui.value); model.update_planet_spec(); }
    });
    
    //Disabled until ready
    $("#slider_metal_clusters").slider('disable');
    $("#slider_metal_density").slider('disable');

    Mousetrap.bind('g', model.toggleStellarGrid);
    Mousetrap.bind('esc', model.issueCancel);

    apply_keybinds('camera');

    engine.call("game.allowKeyboard", true);
    engine.call('audio.setMusic', '/Music/Music_Planet_Editor');
});
