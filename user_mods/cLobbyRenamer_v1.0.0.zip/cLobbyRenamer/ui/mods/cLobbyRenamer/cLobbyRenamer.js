(function() {
	$("#main .header").html("<div id=\"lobby_name_container\" data-bind=\"visible: isGameCreator\"><label for=\"lobby_name\">Lobby Name</label><input id=\"lobby_name\" data-bind=\"value: model.writeGameDesc().system.name, valueUpdate: 'afterkeydown'\" type=\"text\" /></div>");
})();

$("#lobby_name").on("keyup", function() {
	model.updateGameConfig();
});