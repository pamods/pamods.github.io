model.showCheatServers(true);
console.log('SHOW_CHEAT_SERVERS: Mod enabled display of cheat servers in server browser');
