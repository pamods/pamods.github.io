#ifdef GL_ES
precision mediump float;
#endif

uniform sampler2D Texture;
uniform vec4 TeamColor_Primary;
uniform vec4 TeamColor_Secondary;
varying vec2 v_TexCoord;
varying vec3 f_Color;

vec3 combo(in vec3 col, in vec3 col0, in vec3 colr, in vec3 colg, in vec3 colb)
    {
    return ((1-(col.r+col.g+col.b))*col0 + col.r*colr + col.g*colg + col.b*colb);
    }

float norm(in vec3 vect)
    {
    return ( sqrt ( pow(vect.x,2) + pow(vect.y,2) + pow(vect.z,2) ) );
    }

bool isClose(in vec3 vect, in vec3 col)
    {
    return ( (norm (vect - col)) < 0.2);
    }

void main() {
    vec3 Black = vec3(0.0,0.0,0.0);
    vec3 White = vec3(1.0,1.0,1.0);
    vec3 Yellow = vec3(1.0,1.0,0.0);
    vec3 DarkRed = vec3(0.8,0.0,0.0);
    vec3 DarkGrey = vec3(0.25,0.25,0.25);

    vec4 texel = texture2D(Texture, v_TexCoord);

    // NOTE: it seems that texel.r and texel.b are switched?!
    // this is why I'm using texel.bgr instead of texel.rgb
    if (isClose (TeamColor_Primary, Black))
    {
       //not selected: 
       f_Color = combo(texel.bgr, White, TeamColor_Primary, Yellow, Black);
    }
    else if (isClose (TeamColor_Primary, White))
    {   
        f_Color = combo(texel.bgr, Black, TeamColor_Primary, Yellow, DarkGrey);
    }
    else if (isClose (TeamColor_Primary, Yellow))
    {
        f_Color = combo(texel.bgr, Black, TeamColor_Primary, DarkRed, White);
    }
    else 
    {   
        f_Color = combo(texel.bgr, Black, TeamColor_Primary, Yellow, White);
    }
    
    gl_FragColor = TeamColor_Primary.a * texel.a * (vec4(f_Color.r, f_Color.g, f_Color.b, 1));
}
