(function() {
  model.moddedGameFilters(['modded_no','modded_yes']);
})();