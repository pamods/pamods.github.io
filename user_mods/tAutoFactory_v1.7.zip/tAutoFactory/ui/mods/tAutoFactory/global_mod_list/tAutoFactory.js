/* hotkey TODO
(function () {
    //hotkey define
    action_sets.tAutoFactory = {};
    action_sets.tAutoFactory["Manually Execute"] = function(event) {};
    action_sets.tAutoFactory["Toggle Auto-Build"] = function(event) {};

    default_keybinds.tAutoFactory = {};
    default_keybinds.tAutoFactory["Manually Execute"] = "\\";
    default_keybinds.tAutoFactory["Toggle Auto-Build"] = "q";
    
})();*/
