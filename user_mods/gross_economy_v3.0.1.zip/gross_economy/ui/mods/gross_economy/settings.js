(function() {
  model.addSetting_DropDown(
    'Resource Net', 'gross_economy_resource_net', 'UI',
    ['BASIC FABBER SECONDS', 'PERCENT', 'SIMPLE'], 0,
    'Gross Economy')

  model.addSetting_DropDown(
    'Theme', 'gross_economy_theme', 'UI',
    ['INVERSE', 'CLASSIC BLACK'], 0,
    'Gross Economy')
})()
