(function () {
    model.addSetting_DropDown("Transparency: ", "cBBB_Trans", "UI", ["Transparency On", "Transparency Off", "Icons Only", "No Borders"], 0, "Better Build Bar");
})();