﻿var model;
var handlers;

$(document).ready(function () {

    function IconAtlasViewModel() {
        var self = this;

        self.strategicIconSource = function (string) { return 'img/strategic_icons/' + 'icon_si_' + string + '.png' }
        self.strategicIcons = ko.observableArray([
            'blip',
            'metal_splat_02',
            'celestial_object',
            'commander',
            'nuke_launcher_ammo',
            'anti_nuke_launcher_ammo',
            'land_mine',
            'sea_mine',
            'land_barrier',
            'vehicle_factory',
            'vehicle_factory_adv',
            'bot_factory',
            'bot_factory_adv',
            'air_factory',
            'air_factory_adv',
            'orbital_launcher',
            'naval_factory',
            'naval_factory_adv',
            'orbital_factory',
            'energy_plant',
            'energy_plant_adv',
            'energy_storage',
            'energy_storage_adv',
            'metal_extractor',
            'metal_extractor_adv',
            'metal_storage',
            'metal_storage_adv',
            'metal_fabricator',
            'metal_fabricator_adv',
            'fusion_plant',
            'teleporter',
            'delta_v_engine',
            'sea_fusion_plant',
            'mining_platform',
            'orbital_gas_mine',
            'solar_array',
            'radar',
            'radar_adv',
            'deep_space_radar',
            'point_defense',
            'point_defense_adv',
            'air_defense',
            'air_defense_adv',
            'artillery_short',
            'artillery_long',
            'ion_defense',
            'tactical_missile_launcher',
            'laser_defense',
            'laser_defense_adv',
            'tactical_missile_defense',
            'unit_cannon',
            'nuke_launcher',
            'anti_nuke_launcher',
            'sonar',
            'sonar_adv',
            'torpedo_launcher',
            'torpedo_launcher_adv',
            'floating_laser',
            'floating_laser_adv',
            'fabrication_vehicle',
            'fabrication_vehicle_adv',
            'land_scout',
            'land_scout_adv',
            'tank_light_laser',
            'tank_laser_adv',
            'aa_missile_vehicle',
            'aa_missile_vehicle_adv',
            'tank_heavy_mortar',
            'tank_armor',
            'tank_heavy_armor',
            'transport',
            'tank_hover',
            'tank_amphibious_adv',
            'fabrication_bot',
            'fabrication_bot_adv',
            'fabrication_bot_combat',
            'fabrication_bot_combat_adv',
            'bot_aa',
            'bot_aa_adv',
            'bot_grenadier',
            'bot_artillery_long',
            'assault_bot',
            'assault_bot_adv',
            'bot_sniper',
            'bot_bomb',
            'bot_spider',
            'bot_spider_adv',
            'amphibious_bot',
            'fabrication_aircraft',
            'fabrication_aircraft_adv',
            'air_scout',
            'air_scout_adv',
            'fighter',
            'fighter_adv',
            'flying_transport',
            'flying_transport_adv',
            'bomber',
            'bomber_adv',
            'bomber_torpedo',
            'nuke_bomber',
            'gunship',
            'aa_gunship',
            'fabrication_ship',
            'fabrication_ship_adv',
            'sea_scout',
            'destroyer',
            'battleship',
            'frigate',
            'sub_hunter',
            'missile_ship',
            'transport_ship',
            'transport_ship_adv',
            'fabrication_sub',
            'fabrication_sub_adv',
            'scout_sub',
            'scout_sub_adv',
            'attack_sub',
            'nuclear_sub',
            'orbital_fabrication_bot',
            'radar_satellite',
            'radar_satellite_adv',
            'attack_satellite',
            'orbital_fighter',
            'defense_satellite',
            'orbital_laser',
            'orbital_egg',
            'orbital_lander',
            'laser_defense_single'
        ]);

        self.sendIconList = function () {
            var list = model.strategicIcons();
            engine.call('handle_icon_list', list, 32);
        }
    }
    model = new IconAtlasViewModel();
    handlers = {};

    // inject per scene mods
    if (scene_mod_list['icon_atlas'])
        loadMods(scene_mod_list['icon_atlas']);

    // setup send/recv messages and signals
    app.registerWithCoherent(model, handlers);

    // Activates knockout.js
    ko.applyBindings(model);

    model.sendIconList();

});
