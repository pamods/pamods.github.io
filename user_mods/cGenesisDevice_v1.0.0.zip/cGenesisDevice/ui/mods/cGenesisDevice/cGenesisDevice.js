var cGenesisDevice = (function () {

	var cGenesisDevice = {};


	return cGenesisDevice;
})();