/**
 * ORBITAL VOODOO MACHINE
 *
 * [RLM]Total Annihilation
 * Captain Conundrum
 *
 * Adds a new tab on planets in the system designer that allows
 * orbits to be designated using an orbital coordinate system.
 *
 * Reference:
 *  A Review in Physics: Elliptical orbits and you.
 *  By [RLM]Total Annihilation
 *  https://docs.google.com/file/d/0B4e6iZ-yBm9FUEdWSFNRTGExZ1E
 **/

cGenesisDevice.orbital_voodoo = (function () {

	var orbital_voodoo = {};

	//INITIALIZE VARIABLES
	var constants				= {};
	var ui						= {};
	var inputs					= {};
	var intermediate			= {};
	var output					= {};
	var utilityMath				= {};

	orbital_voodoo.constants	= constants;
	orbital_voodoo.ui			= ui;
	orbital_voodoo.inputs		= inputs;
	orbital_voodoo.intermediate	= intermediate;
	orbital_voodoo.output		= output;
	orbital_voodoo.utilityMath	= utilityMath;


	// CONSTANTS
	constants.gravity			= ko.observable(5000);
	constants.sunMass			= ko.observable(100000);


	// UI
	ui.orbitingBody 			= ko.observable({});// Either {} for sun or a planetSpec
	ui.perihelion 				= ko.observable(0);	// Minimum distance from orbiting body
	ui.aphelion 				= ko.observable(0);	// Maximum distance from orbiting body
	ui.offset_angle 			= ko.observable(0);	// Degrees
	ui.position_angle 			= ko.observable(0);	// Degrees
	ui.orbitalDirection	 		= ko.observable(1);	// { 1, -1 }


	// INPUTS
	inputs.orbitingBody 		= ko.computed(function() { return ui.orbitingBody(); });
	inputs.perihelion 			= ko.computed(function() { return parseFloat(ui.perihelion()); });
	inputs.aphelion 			= ko.computed(function() { return parseFloat(ui.aphelion()); });
	inputs.offset_angle 		= ko.computed(function() { return parseFloat(ui.offset_angle()); });
	inputs.position_angle 		= ko.computed(function() { return parseFloat(ui.position_angle()); });
	inputs.orbitalDirection	 	= ko.computed(function() { return ui.orbitalDirection(); });


	// UTILITY MATH
	utilityMath.degreesToRadians = function(degrees) {
		return degrees * (Math.PI / 180);
	};


	// INTERMEDIATE VALUES

	//Convert to radians, noob
	intermediate.offset_radians = ko.computed(function() {
		return utilityMath.degreesToRadians(inputs.offset_angle());
	});

	intermediate.position_radians = ko.computed(function() {
		return utilityMath.degreesToRadians(inputs.position_angle());
	});

	// Chosen by a drop-down selection in the UI
	intermediate.orbitingBodyMass = ko.computed(function() {
		if(inputs.orbitingBody().mass == undefined)
			return constants.sunMass();
		else return inputs.orbitingBody().mass;
	});

	// Chosen by a drop-down selection in the UI
		intermediate.orbitingBodyPosition_x = ko.computed(function() {
			if(inputs.orbitingBody().position_x == undefined)
				return 0;
			else return inputs.orbitingBody().position_x;
	});

	// Chosen by a drop-down selection in the UI
		intermediate.orbitingBodyPosition_y = ko.computed(function() {
			if(inputs.orbitingBody().position_y == undefined)
				return 0;
			else return inputs.orbitingBody().position_y;
	});

	// Chosen by a drop-down selection in the UI
		intermediate.orbitingBodyVelocity_x = ko.computed(function() {
			if(inputs.orbitingBody().velocity_x == undefined)
				return 0;
			else return inputs.orbitingBody().velocity_x;
	});

	// Chosen by a drop-down selection in the UI
		intermediate.orbitingBodyVelocity_y = ko.computed(function() {
			if(inputs.orbitingBody().velocity_y == undefined)
				return 0;
			else return inputs.orbitingBody().velocity_y;
	});

	// (4)
	intermediate.majorSemiAxis = ko.computed(function() {
		return (inputs.aphelion() + inputs.perihelion()) / 2;
	});

	// (4)
	intermediate.semiFocalDistance = ko.computed(function() {
		return (inputs.aphelion() - inputs.perihelion()) / 2;
	});

	// (5)
	intermediate.eccentricity = ko.computed(function() {
		return intermediate.semiFocalDistance() / intermediate.majorSemiAxis();
	});

	// (9)
	intermediate.latusRectum = ko.computed(function() {
		return intermediate.majorSemiAxis() * ( 1 - Math.pow(intermediate.eccentricity(), 2));
	});

	// (8)
	intermediate.radius = ko.computed(function() {
		return intermediate.latusRectum() / (1 - (intermediate.eccentricity() * Math.cos(intermediate.position_radians())));
	});

	// (12)
	intermediate.angularVelocity = ko.computed(function() {
		var a = constants.gravity() * intermediate.orbitingBodyMass() * Math.pow(1 - intermediate.eccentricity() * Math.cos(intermediate.position_radians()), 4);
		var b = Math.pow(intermediate.majorSemiAxis(), 3) * Math.pow(1 - Math.pow(intermediate.eccentricity(), 2), 3);

		return Math.sqrt(a/b) * inputs.orbitalDirection();
	});

	// (10)
	intermediate.velocity_radius = ko.computed(function() {
		var a = intermediate.angularVelocity() * intermediate.latusRectum() * intermediate.eccentricity() * Math.sin(intermediate.position_radians());
		var b = Math.pow(1 - intermediate.eccentricity() * Math.cos(intermediate.position_radians()), 2);

		return -1 * (a / b);
	});

	// (10)
	intermediate.velocity_position = ko.computed(function() {
		var a = intermediate.angularVelocity() * intermediate.latusRectum();
		var b = 1 - intermediate.eccentricity() * Math.cos(intermediate.position_radians());

		return a/b;
	});

	intermediate.polar_x = ko.computed(function() {
		return intermediate.radius() * Math.cos(intermediate.position_radians());
	});

	intermediate.polar_y = ko.computed(function() {
		return intermediate.radius() * Math.sin(intermediate.position_radians());
	});

	// (1)
	intermediate.velocity_x = ko.computed(function() {
		return intermediate.velocity_radius() * Math.cos(intermediate.position_radians()) - intermediate.velocity_position() * Math.sin(intermediate.position_radians());
	});

	// (1)
	intermediate.velocity_y = ko.computed(function() {
		return intermediate.velocity_radius() * Math.sin(intermediate.position_radians()) + intermediate.velocity_position() * Math.cos(intermediate.position_radians());
	});


	// OUTPUT

	// (1)
	output.position_x = ko.computed(function() {
		return intermediate.polar_x() * Math.cos(intermediate.offset_radians()) - intermediate.polar_y() * Math.sin(intermediate.offset_radians()) + intermediate.orbitingBodyPosition_x();
	});

	// (1)
	output.position_y = ko.computed(function() {
		return intermediate.polar_x() * Math.sin(intermediate.offset_radians()) + intermediate.polar_y() * Math.cos(intermediate.offset_radians()) + intermediate.orbitingBodyPosition_y();
	});

	// (1)
	output.velocity_x = ko.computed(function() {
		return intermediate.velocity_x() * Math.cos(intermediate.offset_radians()) - intermediate.velocity_y() * Math.sin(intermediate.offset_radians()) + intermediate.orbitingBodyVelocity_x();
	});

	// (1)
	output.velocity_y = ko.computed(function() {
		return intermediate.velocity_x() * Math.sin(intermediate.offset_radians()) + intermediate.velocity_y() * Math.cos(intermediate.offset_radians()) + intermediate.orbitingBodyVelocity_y();
	});


	return orbital_voodoo;
})();