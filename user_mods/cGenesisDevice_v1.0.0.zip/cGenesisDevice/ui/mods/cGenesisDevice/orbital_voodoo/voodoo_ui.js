//load html dynamically
function loadHtmlTemplate(element, url) {
    element.load(url, function () {
        console.log("Loading html " + url);
        element.children().each(function() {
			ko.applyBindings(model, this);
		});
    });
}


model.orbitingBodyList = ko.computed(function() {
	var orbitingBodyList = Array({});
	var planets = model.system().planets.slice();
	planets.splice(model.selectedPlanetIndex(), 1);

	orbitingBodyList = orbitingBodyList.concat(planets);

	return orbitingBodyList;
});

$(".div_editor_panel").wrap("<div id='cGenesisDevice_tabs'></div>");
$(".div_editor_panel").attr("id", "div_editor_panel");
$("#cGenesisDevice_tabs").append("<div id='cGenesisDevice_orbitalVoodoo'></div>");
$("#cGenesisDevice_tabs").prepend("<ul><li><a href='#div_editor_panel'>Editor</a></li><li><a href='#cGenesisDevice_orbitalVoodoo'>Ellipse Generator</a></li></ul>");

loadHtmlTemplate($("#cGenesisDevice_orbitalVoodoo"), "coui://ui/mods/cGenesisDevice/orbital_voodoo/voodoo_tab.html");

$("#cGenesisDevice_tabs").tabs();

var cGenesisDevice_orbitingBody_name;

function cGenesisDevice_orbitalVoodoo_calculate() {
	if(cGenesisDevice.orbital_voodoo.ui.orbitingBody()==undefined || cGenesisDevice.orbital_voodoo.ui.orbitingBody()=={})
		cGenesisDevice_orbitingBody_name = undefined;
	else
		cGenesisDevice_orbitingBody_name = cGenesisDevice.orbital_voodoo.ui.orbitingBody().name;

	var planet = model.system().planets[model.selectedPlanetIndex()];

	model.position_x(cGenesisDevice.orbital_voodoo.output.position_x());
	model.position_y(cGenesisDevice.orbital_voodoo.output.position_y());
	model.velocity_x(cGenesisDevice.orbital_voodoo.output.velocity_x());
	model.velocity_y(cGenesisDevice.orbital_voodoo.output.velocity_y());

	model.update_planet_spec();
}

// Hack to make the orbiting body persistent even after clicking the calculate button
cGenesisDevice.orbital_voodoo.ui.orbitingBody.subscribe(function(newValue) {
	if(cGenesisDevice_orbitingBody_name != undefined) {

		for(planet in model.orbitingBodyList()) {
			if(model.orbitingBodyList()[planet].name == cGenesisDevice_orbitingBody_name) {
				// Have to clear it now or KO will go into an infinite loop
				cGenesisDevice_orbitingBody_name = undefined;
				// Fix the value
				cGenesisDevice.orbital_voodoo.ui.orbitingBody(model.orbitingBodyList()[planet]);
			}
		}

		cGenesisDevice_orbitingBody_name = undefined;
	}
});