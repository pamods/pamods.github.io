(function() {
$( 'div.div_bottom_bar' ).append( "<div class='div_opacityCheck receiveMouse' id='div_opacityCheck'>Transparency <input type='Checkbox' id='opacityCheck'></input></div>" );
})()


function opacityOff() {
    $(".div_build_bar_midspan > div").css('margin', '0px 0px 0px 0px').css('opacity', '1');
}


function opacityOn() {
    $(".div_build_bar_midspan > div").css('margin', '0px 0px 0px 0px').css('opacity', '.8');
}

document.getElementById('opacityCheck').onchange = function status() {
    if ( document.getElementById('opacityCheck').checked === false ) {
        opacityOff();
    }
    else
    {
        opacityOn();
    };
}