$(function() {
	
	
$('body').append('<div id="locate_commander"><p>Locate Commander</p></div>');

	var element = $('#locate_commander');
	element.click(selectCommander);
	
	function selectCommander() {
	//api.engine.call("holodeck.setCommanderId", msg.data.client.commander.id);
	api.select.commander();
        api.camera.track(true);
	}
});