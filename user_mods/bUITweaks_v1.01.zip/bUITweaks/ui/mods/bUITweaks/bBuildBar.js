// Removes empty build bar squares
$('.div_build_item').not('#bld1').remove();

$('.div_build_bar_cont').css({
  'max-width': '313px',
//'min-width': '189px',     // Set at 3 items wide, so the build-tab doesn't fuck up so much when there's 1 or 2 build options.
  'width': 'auto',
  'vertical-align': 'bottom',
});

$('.div_build_bar_menu_cont > div').css({
  'padding': '0px 0px 1px 0px',
});

// Removes the little build tabs (e.g."FACTORY") when there's only one set of items.
$('.tab_grp_body').attr('data-bind', 'visible: $root.orderedBuildTabs().length > 1');

// Makes the little build tabs smaller so they don't overlap when few items in build catagory
$('.span_build_bar_tab').css({
  'width': 'auto',
  'max-width': '180px'
});