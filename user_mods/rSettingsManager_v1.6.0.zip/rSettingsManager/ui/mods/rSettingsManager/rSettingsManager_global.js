//====================================
// rSettingsManager - Settings Manager
//------------------------------------
// rSettingsManager_global.js
// Created by Raevn
// Version 1.6.0 (2014/06/16)
//------------------------------------

function initialSettingValue(id, value) {
	console.log("rSettingsManager: initialSettingValue is Deprecated");
}