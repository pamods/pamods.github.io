﻿// Put twitch into start menu
$('#navigation_items').append('<div id="twitch-display-name" data-bind="visible: showingTwitchReady, text: twitchName">    </div><div id="twitch-settings" data-bind="visible: showingTwitchReady">    <form data-bind="visible: !twitchStreamingDesired(), submit: twitchStartStreaming">    <span class="nav_item_text">        Stream Video        <button id="twitchButtonOff" type="submit">OFF</button>    </span>    </form>    <form data-bind="visible: twitchStreamingDesired, submit: twitchStopStreaming">    <span class="nav_item_text">        Stream Video        <button id="twitchButtonOn" type="submit">ON</button>    </span>    </form>    <form data-bind="visible: !twitchSpeech(), submit: twitchStartSpeech">    <span class="nav_item_text">        - With Speech        <button id="twitchButtonOff" type="submit">OFF</button>    </span>    </form>    <form data-bind="visible: twitchSpeech, submit: twitchStopSpeech">    <span class="nav_item_text">        - With Speech        <button id="twitchButtonOn" type="submit">ON</button>    </span>    </form>    <form data-bind="visible: !twitchSound(), submit: twitchStartSound">    <span class="nav_item_text">        - With Sounds        <button id="twitchButtonOff" type="submit">OFF</button>    </span>    </form>    <form data-bind="visible: twitchSound, submit: twitchStopSound">    <span class="nav_item_text">        - With Sounds        <button id="twitchButtonOn" type="submit">ON</button>    </span>    </form></div><div id="loginTwitch" data-bind="visible: showingTwitchSignIn">    <form data-bind="submit: twitchLogIn" style="padding-top:10px;">        <div style="margin: 0px 0px 8px 0px;">            Sign in with your Twitch ID        </div>        <div class="input_label">            Username        </div>        <div>            <input type="text" class="input_text" data-bind="value: twitchName" />        </div>        <div class="input_label">            <loc data-i18n="start:password.message" desc="">Password</loc>        </div>        <div>            <input class="input_text" type="password" data-bind="value: twitchPassword" />        </div>        <div>            <button id="signin" type="submit" data-bind="click_sound: \'default\', rollover_sound: \'default\'"><loc data-i18n="start:sign_in.message" desc="">Sign in</loc>            </button>        </div>    </form></div>');

(function() {
        model.showingTwitchSignIn = ko.observable(true);
        model.showingTwitchReady = ko.observable(false);

        model.twitchName = ko.observable('').extend({ session: 'twitchname' });
        model.twitchPassword = ko.observable('');

        model.twitchLogIn = function () {
            api.twitch.logIn(String(model.twitchName()), String(model.twitchPassword()));
        }
        model.twitchLogOut = function () {
            api.twitch.logOut();
        }

        model.twitchStreamingDesired = ko.observable(false).extend({ session: 'twitchStreamingDesired' });
        model.twitchSpeech = ko.observable(false).extend({ session: 'twitchSpeech' });
        model.twitchSound = ko.observable(false).extend({ session: 'twitchSound' });

        model.twitchStartStreaming = function () {
            api.twitch.enableStreaming();
        }
        model.twitchStopStreaming = function () {
            api.twitch.disableStreaming();
            api.twitch.requestState();
        }
        model.twitchStartSpeech = function () {
            api.twitch.enableMicCapture();
        }
        model.twitchStopSpeech = function () {
            api.twitch.disableMicCapture();
            api.twitch.requestState();
        }
        model.twitchStartSound = function () {
            api.twitch.enablePlaybackCapture();
        }
        model.twitchStopSound = function () {
            api.twitch.disablePlaybackCapture();
            api.twitch.requestState();
        }

    handlers.twitchtv_authFailed = function (payload) {
        model.showingTwitchSignIn(true);
        model.showingTwitchReady(false);
    }

    handlers.twitchtv_statechange = function (payload) {
        if (payload.twitchName)
            model.twitchName(payload.user);
            model.twitchStreamingDesired(payload.streamingDesired);
        if (payload.authenticated) {
            model.showingTwitchSignIn(false);
            model.showingTwitchReady(true);
            model.twitchStreamingDesired(payload.streamingDesired);
            model.twitchSpeech(payload.enableMicCapture);
            model.twitchSound(payload.enablePlaybackCapture);
        } else {
            model.showingTwitchSignIn(true);
            model.showingTwitchReady(false);
        }
    }

    api.twitch.requestState();

})();