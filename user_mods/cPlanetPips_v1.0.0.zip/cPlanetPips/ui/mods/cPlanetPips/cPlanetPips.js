(function() {

	// I really hate the way I am adding a function to the object, but it works.
	model.celestialViewModels.subscribe(function(newModel) {
		if(newModel.length == 0 || newModel.planetPipClick)
			return;

		Object.getPrototypeOf(newModel[0]).planetPipClick = function() {
			model.showPips(true);
			model.pips[0].focus();
			api.camera.focusPlanet(this.index());
			api.camera.setZoom("air");
			model.holodeck.focus();

		};
	});

	// Toggle the pip once to initialize it.
	// I have no idea why this hack is required or why I have to close it from a pseudo-thread.
	model.showPips(true);
	setTimeout("model.showPips(false)");

	$(".div_planet_list_item_cont>div:last").children().append("<div class=\"planetPipButton\" data-bind=\"click: $data.planetPipClick\"><div></div></div>");
}());
