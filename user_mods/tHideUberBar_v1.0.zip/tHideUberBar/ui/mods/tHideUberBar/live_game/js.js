//hide uberbar toggle button
$(".div_uberbar_toggle_cont").hide();
