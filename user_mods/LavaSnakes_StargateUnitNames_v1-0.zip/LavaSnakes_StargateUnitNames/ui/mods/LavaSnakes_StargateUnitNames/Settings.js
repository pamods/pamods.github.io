(function () {
	//Add settings GUI item
	model.addSetting_Button("Stargate unit names will be added to the above list automaticly.", "bye bye button", "UI", "null", "Unit renaming rules");
	$("input[data-bind='click: null']").css("visibility", "hidden");
})();