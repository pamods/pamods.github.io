(function() {

    //console.log("af roll call live game settings");

	_.extend(api.settings.definitions.ui.settings, {

	bShowSecondaryColourStyle: {
		title: 'Show Secondary Colour style',
		type: 'select',
		options: ['CORNER','UBERS','STRIPES','DOGE','CHEVRON','BORDER'],
		default: 'CORNER'
	}
	});

	//fix for settings not shown
	//model.settingGroups.notifySubscribers(); }));
	model.settingDefinitions(api.settings.definitions)
})()