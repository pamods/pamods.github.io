//var settings = decode(localStorage.settings);

//model.bShowSecondaryColourStyle = ko.observable(settings.bShowSecondaryColourStyle);

var bShowSecondaryColourStyle = api.settings.isSet('ui', 'bShowSecondaryColourStyle', true)==undefined?'CORNER':api.settings.isSet('ui', 'bShowSecondaryColourStyle', true);

$('.slot-color-primary').each( function() {
  var databindstr = $(this).attr('data-bind');
  databindstr = databindstr + ", event: { contextmenu: function () { if (slot.containsThisPlayer()) army.nextSecondaryColor(); } }";
  $(this).attr('data-bind', databindstr);
});

switch(bShowSecondaryColourStyle)
{
case 'BORDER':  
	$('.slot-color-primary').append(
		'<div class="secondaryColour" data-bind="style: { height: \'100%\', \'border-style\': \'solid\', \'border-color\': slot.secondaryColor, \'border-width\': \'3px\' }",></div>'
	);
  break;
case 'UBERS':
	$('.slot-color-primary').append(
		'<div class="secondaryColour" data-bind="style: { height: \'100%\', \'margin-left\': \'10px\', \'border-style\': \'solid\', \'border-color\': slot.secondaryColor, \'border-width\': \'0px 0px 0px 10px\' }"></div>'
	);
  break;
case 'STRIPES':
	$('.slot-color-primary').append(
		'<div class="secondaryColour" data-bind="style: { height: \'100%\', margin: \'0px 36px 0px 10px\', \'border-style\': \'solid\', \'border-color\': slot.secondaryColor, \'border-width\': \'0px 5px 0px 5px\' }"></div>'
	);
  break;
// Probably best NOT to try to figure out how this one works...
case 'DOGE':
	$('.slot-color-primary').append(
		'<div class="secondaryColour" data-bind="style: { \'white-space\': \'nowrap\', height: \'100%\', margin: \'2px\', color: slot.secondaryColor, \'font-size\': \'9px\', \'font-weight\': \'bold\', \'font-family\': \'Comic Sans MS\', \'line-height\': \'140%\' }">so secondary<br>&nbsp;much color<br>&nbsp;&nbsp;&nbsp;WOW</div>' //+		
	);
  break;
case 'CHEVRON':
	$('.slot-color-primary').append(
		'<div class="secondaryColour" data-bind="style: { height: \'0px\', width: \'8px\', margin: \'14px 0px 0px 27px\', \'border-left\': \'2px solid transparent\', \'border-right\': \'2px solid transparent\', \'border-top\':\'4px solid\', \'border-top-color\': slot.secondaryColor }"></div>' +
		'<div class="secondaryColour" data-bind="style: { height: \'14px\', width: \'20px\', margin: \'-8px 0px 0px 20px\', \'border-style\': \'solid\', \'border-color\': slot.secondaryColor, \'border-width\': \'0px 5.5px 4px 0px\', \'webkitTransform\': \'rotate(24deg) skewX(-40deg)\' }"></div>' +
		'<div class="secondaryColour" data-bind="style: { height: \'14px\', width: \'20px\', margin: \'-6px 0px 0px 20px\', \'border-style\': \'solid\', \'border-color\': slot.secondaryColor, \'border-width\': \'0px 5.5px 4px 0px\', \'webkitTransform\': \'rotate(24deg) skewX(-40deg)\' }"></div>'
	);
  break;
case 'CORNER':
	$('.slot-color-primary').append(
		'<div class="secondaryColour" data-bind="style: { height: \'100%\', width: \'20px\', margin: \'-25px 0px 0px -16px\', \'border-left\': \'10px solid transparent\', \'border-right\': \'10px solid transparent\', \'border-bottom\': \'10px solid\', \'border-bottom-color\': slot.secondaryColor, \'webkitTransform\': \'rotate(-45deg)\' }"></div>'
	);
  break;
default:
}
