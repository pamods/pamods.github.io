var original_loadRandomSystem = model.loadRandomSystem;

model.loadRandomSystem = function () {
	original_loadRandomSystem();

	var system = model.loadedSystem();

	for(var i=0; i<system.planets.length; i++) {
		var planet = system.planets[i].planet;
		var planetName = cPlanetNameThemes.getPlanetName(planet);
     	system.planets[i].name = planetName;
	}

	model.loadedSystem(system);
}

