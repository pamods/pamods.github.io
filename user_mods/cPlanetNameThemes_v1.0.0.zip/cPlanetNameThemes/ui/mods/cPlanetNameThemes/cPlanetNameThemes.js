var cPlanetNameThemes = (function () {

	var cPlanetNameThemes = {};

	cPlanetNameThemes.themes = {};

	cPlanetNameThemes.getPlanetName = function(planet) {
		var planetNames = this.getPlanetNames(planet);
		var rand = Math.random()*planetNames.length|0;
     	return planetNames[rand];
	};

	cPlanetNameThemes.getPlanetNames = function(planet) {
		var theme = this.getTheme();
		var biome = this.getBiome(planet);

		switch(biome) {
			case "earth":
				return theme.earth;
			case "moon":
				return theme.moon;
			case "tropical":
				return theme.tropical;
			case "lava":
				return theme.lava;
			case "metal":
				return theme.metal;
			case "ice":
				if(theme.ice)
					return theme.ice;
				else return theme.earth;
			case "desert":
				if(theme.desert)
					return theme.desert;
				else return theme.earth;
		}
	};

	cPlanetNameThemes.getBiome = function(planet) {
		var biome = planet.biome;
		if(biome !== "earth")
			return biome;

		var temperature = planet.temperature;
		var waterHeight = planet.waterHeight;

		if(temperature <= 20)
			return "ice";

		if(temperature >= 80 && waterHeight <= 45)
			return "desert";

		return "earth";
	};

	cPlanetNameThemes.getTheme = function() {
		var settings = decode(localStorage.settings);
		var theme = settings.cPlanetNameThemes_theme;
		initialSettingValue("cPlanetNameThemes_theme", "Star Wars");
		return this.themes[theme];
	}

	cPlanetNameThemes.getThemeNames = function() {
		var themeNames = new Array();

		for (var theme in this.themes) {
		    themeNames.push(theme);
		}

		return themeNames;
	}

	return cPlanetNameThemes;
})();