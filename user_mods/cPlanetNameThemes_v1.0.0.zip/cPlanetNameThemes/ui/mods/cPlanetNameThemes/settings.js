initialSettingValue("cPlanetNameThemes_theme", "Star Wars");
var themeNames = cPlanetNameThemes.getThemeNames()
model.addSetting_DropDown('Planet Naming Theme','cPlanetNameThemes_theme','UI',themeNames,1);
