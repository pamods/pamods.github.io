(function() {

var oldProcessGameBeacon = model.processGameBeacon;
model.processGameBeacon = function(beacon, host_id) {
	var game = oldProcessGameBeacon(beacon, host_id);
	game.player_names = beacon.player_names;
	
	return game;
};

model.dPlayersInServerBrowser_showplayers = ko.observable(false);

var olddatabind = $('.one-game').attr('data-bind');
$('.one-game').after(
	'<!-- ko if: host_id === model.currentSelectedGameHost() || model.dPlayersInServerBrowser_showplayers -->' +
	'                    <div class="row one-game" data-bind="' +
	'                            css: { \'ui-selected\': (host_id == model.currentSelectedGameHost()) },' +
	'                            click: $parent.setSelected,' +
	'                            event: { dblclick: $parent.joinSelectedGame }">' +
	'                        <div class="col-md-12 game"><span style="margin-left:1.2em; margin-right: 1em;">PLAYERS:</span><span data-bind="foreach: $data.player_names"><span data-bind="text: $data" class="dPlayersInServerBrowser_player-name"></span></span></div>' +
	'                    </div>' +
	'<!-- /ko -->'
);

$('#create').after(
	'            <div style="height:85px; border-bottom:1px solid #808080; margin-bottom:20px; ">' +
	'                <div class="btn_std" id="showplayers" style="margin-left:-6px;">' +
	'                    <div class="btn_label" id="showplayerslabel" style="width: 270px; margin:8px 0px;">' +
	'                        Show players' +
	'                    </div>' +
	'                </div>' +
	'            </div>'
);

// Click handler for showplayers button
$('#showplayers').click(function() {
	model.dPlayersInServerBrowser_showplayers(!model.dPlayersInServerBrowser_showplayers());

	if(model.dPlayersInServerBrowser_showplayers())
		$('#showplayerslabel').text("Hide players");
	else
		$('#showplayerslabel').text("Show players");
});

})();
