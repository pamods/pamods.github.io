/**
 * All cameras must have the following:
 *	function startCameraMode()
 *	function endCameraMode()
 *	var inCameraMode
 **/

cCameraHotkeys.cameras.actionCamera = (function () {
	var actionCamera = {};

	actionCamera.inCameraMode = false;
	actionCamera.cameraModeTimer;
	actionCamera.rollDirection = 1;

	actionCamera.startCameraMode = function() {
		actionCamera.inCameraMode = true;
		actionCamera.rollDirection *= -1;

		cCameraHotkeys.handleDisablePoleLock();

		api.game.toggleUI();
		api.arch.toggleAR();
		api.camera.changeKeyPanSpeed(-.97);

		actionCamera.smoothMoveCamera();
	};

	actionCamera.endCameraMode = function() {
		actionCamera.inCameraMode = false;
		clearTimeout(actionCamera.cameraModeTimer);
	};

	actionCamera.smoothMoveCamera = function() {
		if(!actionCamera.inCameraMode) {
			api.game.toggleUI();
			api.arch.toggleAR();

			cCameraHotkeys.handleEnablePoleLock();

			api.camera.changeKeyPanSpeed(.97);
		} else {
			api.camera.zoom(.02);
			engine.call("camera.roll", .1*actionCamera.rollDirection).then(function() {
				actionCamera.smoothMoveCamera();
			});
		}
	};

	// Register with the mod
	var keyBind = default_keybinds["eXodus eSports Camera Modes"]["Action Camera"];
	cCameraHotkeys.keyMapping.cameras[keyBind] = "actionCamera";

	return actionCamera;
})();