/**
 * All cameras must have the following:
 *	function startCameraMode()
 *	function endCameraMode()
 *	var inCameraMode
 **/

cCameraHotkeys.cameras.slowMotionReplay = (function () {
	var slowMotionReplay = {};

	slowMotionReplay.inCameraMode = false;
	slowMotionReplay.cameraModeTimer;
	slowMotionReplay.rollDirection = 1;

	slowMotionReplay.promise = {};
	slowMotionReplay.interval = {};

	slowMotionReplay.checkPromise = function(promise) {
		if(promise != undefined && promise.state!="pending") {
			console.log(promise.state);
			console.log(promise);

			clearInterval(cCameraHotkeys.cameras.slowMotionReplay.interval);

			$(".primary").effect( "highlight", { "color": "rgba(255,255,255,1)" }, "slow", function() {
				engine.call("time.play", .5);
				api.game.toggleUI();
				api.arch.toggleAR();
			});

			api.camera.changeKeyPanSpeed(-.97);

			cCameraHotkeys.cameras.slowMotionReplay.smoothMoveCamera();
		}
	};

	slowMotionReplay.startCameraMode = function() {
		slowMotionReplay.inCameraMode = true;
		slowMotionReplay.rollDirection *= -1;

		cCameraHotkeys.handleDisablePoleLock();

		slowMotionReplay.promise = engine.call("time.skip", -10);

		slowMotionReplay.interval = setInterval("cCameraHotkeys.cameras.slowMotionReplay.checkPromise(cCameraHotkeys.cameras.slowMotionReplay.promise)", 100);

	};

	slowMotionReplay.endCameraMode = function() {
		slowMotionReplay.inCameraMode = false;
		clearTimeout(slowMotionReplay.cameraModeTimer);
	};

	slowMotionReplay.smoothMoveCamera = function() {
		if(!slowMotionReplay.inCameraMode) {
			api.time.resume();
			api.game.toggleUI();
			api.arch.toggleAR();
			cCameraHotkeys.handleEnablePoleLock();
			$(".primary").effect( "highlight", { "color": "rgba(255,255,255,1)" }, "slow");
			api.camera.changeKeyPanSpeed(.97);
		} else {
			api.camera.zoom(.01);
			engine.call("camera.roll", .1*slowMotionReplay.rollDirection).then(function() {
				slowMotionReplay.smoothMoveCamera();
			});
		}
	};

	// Register with the mod
	var keyBind = default_keybinds["eXodus eSports Camera Modes"]["Slow Motion Replay"];
	cCameraHotkeys.keyMapping.cameras[keyBind] = "slowMotionReplay";

	return slowMotionReplay;
})();