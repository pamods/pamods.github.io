/**
 * All cameras must have the following:
 *	function startCameraMode()
 *	function endCameraMode()
 *	var inCameraMode
 **/

cCameraHotkeys.cameras.smoothZoomIn = (function () {
	var smoothZoomIn = {};

	smoothZoomIn.inCameraMode = false;
	smoothZoomIn.cameraModeTimer;

	smoothZoomIn.startCameraMode = function() {
		smoothZoomIn.inCameraMode = true;
		smoothZoomIn.smoothMoveCamera();
	};

	smoothZoomIn.endCameraMode = function() {
		smoothZoomIn.inCameraMode = false;
		clearTimeout(smoothZoomIn.cameraModeTimer);
	};

	smoothZoomIn.smoothMoveCamera = function() {
		if(!smoothZoomIn.inCameraMode) {
			smoothZoomIn.smoothMoveCameraMomentum(.225, -.025, 0);
		} else {
			engine.call("camera.zoom", .25).then(function() {
				smoothZoomIn.smoothMoveCamera();
			});
		}
	};

	smoothZoomIn.smoothMoveCameraMomentum = function(cameraSpeed, increment, stopAtSpeed) {
		if(cameraSpeed <= stopAtSpeed) {
			return;
		} else {
			engine.call("camera.zoom", cameraSpeed).then(function() {
				smoothZoomIn.smoothMoveCameraMomentum(cameraSpeed+increment, increment, stopAtSpeed);
			});
		}
	};

	// Register with the mod
	var keyBind = default_keybinds["eXodus eSports Camera Modes"]["Smooth Zoom In"];
	cCameraHotkeys.keyMapping.cameraControls[keyBind] = "smoothZoomIn";

	return smoothZoomIn;
})();