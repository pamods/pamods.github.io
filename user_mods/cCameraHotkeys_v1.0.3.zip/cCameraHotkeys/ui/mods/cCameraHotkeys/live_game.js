(function() {
	cCameraHotkeys.setupKeybinds();

	// HACK
	// Quickly toggle the pip so that we will be able to control the location for it later.
	setTimeout("model.showPips(true)", 100);
	setTimeout("model.showPips(false)", 200);
})();