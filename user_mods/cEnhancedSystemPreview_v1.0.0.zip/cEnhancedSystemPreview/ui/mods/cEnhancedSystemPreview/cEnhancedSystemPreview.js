// Enhanced System Preview
// By Captain Conundrum
// Improves the system selection screen so that you can see every planet in a system.

var cEnhancedSystemPreview = (function () {

	var cEnhancedSystemPreview = {};

	cEnhancedSystemPreview.showingPlanet = ko.observable(0);

	cEnhancedSystemPreview.showPlanet = ko.computed(function(i, showing) {
		if(arguments.length>1 && showing)
			cEnhancedSystemPreview.showingPlanet(i);
		else if(arguments.length>1 && !showing)
			cEnhancedSystemPreview.showingPlanet(0);
		else
			return (cEnhancedSystemPreview.showingPlanet() == i);
	});

	cEnhancedSystemPreview.chosenPlanet = ko.computed(function() {
		if(cEnhancedSystemPreview.showingPlanet() > 0)
			return model.selectedSystem().planets[cEnhancedSystemPreview.showingPlanet()];
	});

	cEnhancedSystemPreview.showPlanetPreviewThumbnails = ko.computed(function () {
		if(!model.selectedSystem() || !model.selectedSystem().planets || model.selectedSystem().planets.length == 0)
			return "";

		var html = "";
		var totalHeight = 0;
		var planets = model.selectedSystem().planets;

		for(var i=1; i<planets.length; i++) {
			var planetSpec=planets[i];

			var imageSource = model.imageSourceForPlanet(planetSpec);
			var radius = planetSpec.planet.radius;
			var imageSize = cEnhancedSystemPreview.imageSizeForPlanetPreviews(radius);

			// Unfortunately I can't just show every planet in a system with a lot of big planets.
			// The list would get too big.
			// Eventually I might have it overflow into the right side of the main planet image.
			totalHeight += imageSize;
			if(totalHeight > 194)
				return html;

			html += "<div id=\"" + i + "\" class=\"systempreview_planet\"><img src=\"" + imageSource + "\" width=\"" + imageSize + "\"/></div>";
		}

		return html;
	});

	cEnhancedSystemPreview.imageSizeForPlanetPreviews = function(radius) {
		radius = radius<=1200 ? radius : 1200;  // Bigger than this is just stupid anyway.
		var imageSize = radius / 1200 * 56; // Maximum size is 56px
		return imageSize;
	}

	return cEnhancedSystemPreview;
})();

//BUGFIX: FS#3011
model.selectedSystemImageSource = ko.computed(function () { if (!model.selectedSystemEmpty()) return model.imageSourceForPlanet(model.selectedSystem().planets[0]); });

$(".div_planet_item_detail_img").append("<div id=\"div_system_preview_thumbnails\" data-bind=\"html: cEnhancedSystemPreview.showPlanetPreviewThumbnails\"></div>");

// So hacky...
// Apparently knockout's data-bind isn't actually updating the DOM.
// So I have to constantly re-bind my event handlers
$("body").click(function() {
	$(".systempreview_planet").hover(function() {
			cEnhancedSystemPreview.showingPlanet($(this).attr("id"));

			var html = "";
			html = "<div class=\"systempreview_planetinfo\"><div class=\"systempreview_planetinfo_inner\">						<div class=\"div_planet_item_detail_title\">" + cEnhancedSystemPreview.chosenPlanet().name + "</div>			<div>";
			html += "<table style=\"width:100%;\">				<tbody>					<tr>						<td>							<div class=\"input_label\" style=\"margin-bottom:10px;\"><loc data-i18n=\"load_planet:biome.message\" desc=\"\">Biome</loc></div>						</td>						<td style=\"text-align: left;\">							<div class=\"input_field_static\" style=\"text-transform:capitalize;\">" + cEnhancedSystemPreview.chosenPlanet().planet.biome + "</div>						</td>						<td></td>					</tr>								<tr>						<td>							<div class=\"input_label\"><loc data-i18n=\"load_planet:radius.message\" desc=\"\">Radius</loc></div>						</td>						<td>							<div class=\"div_planet_property_bar\">								<div class=\"planet_property_bar\" style=\"width: " + cEnhancedSystemPreview.chosenPlanet().planet.radius / 10 + "px;\"></div>							</div>						</td>						<td>							<div class=\"input_field_static\">" + cEnhancedSystemPreview.chosenPlanet().planet.radius + "</div>						</td>					</tr>								<tr>						<td>							<div class=\"input_label\"><loc data-i18n=\"load_planet:height.message\" desc=\"\">Height</loc></div>						</td>						<td>							<div class=\"div_planet_property_bar\">								<div class=\"planet_property_bar\" style=\"width: " + cEnhancedSystemPreview.chosenPlanet().planet.heightRange * 2 + "px;\"></div>							</div>						</td>						<td>							<div class=\"input_field_static\">" + cEnhancedSystemPreview.chosenPlanet().planet.heightRange + "</div>						</td>					</tr>								<tr>						<td>							<div class=\"input_label\"><loc data-i18n=\"load_planet:water.message\" desc=\"\">Water</loc></div>						</td>						<td>							<div class=\"div_planet_property_bar\">								<div class=\"planet_property_bar\" style=\"width: " + cEnhancedSystemPreview.chosenPlanet().planet.waterHeight * 2 + "px;\"></div>							</div>						</td>						<td>							<div class=\"input_field_static\">" + cEnhancedSystemPreview.chosenPlanet().planet.waterHeight + "</div>						</td>					</tr>								<tr>						<td>							<div class=\"input_label\"><loc data-i18n=\"load_planet:temp.message\" desc=\"\">Temp</loc></div>						</td>						<td>							<div class=\"div_planet_property_bar\">								<div class=\"planet_property_bar\" style=\"width: " + cEnhancedSystemPreview.chosenPlanet().planet.temperature * 2 + "px;\"></div>							</div>						</td>						<td>							<div class=\"input_field_static\">" + cEnhancedSystemPreview.chosenPlanet().planet.temperature + "</div>						</td>					</tr>				</tbody></table>";
			html += "</div></div></div>";

			$(this).append(html);
		}, function() {
			$(this).find(".systempreview_planetinfo").remove();
			cEnhancedSystemPreview.showingPlanet(0);
		});
});