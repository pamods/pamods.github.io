(function() {
        model.fail = function(desc) {
            model.transitPrimaryMessage(desc);
            model.transitSecondaryMessage('Returning to Server Browser');
            model.transitDestination('coui://ui/main/game/server_browser/server_browser.html');
            model.transitDelay(0);
            window.location.href = 'coui://ui/main/game/transit/transit.html';
        };
})();