(function() {
$(".div_build_bar_midspan > div").css('margin', '0px 0px 0px 0px').css('opacity', '.8');
})()