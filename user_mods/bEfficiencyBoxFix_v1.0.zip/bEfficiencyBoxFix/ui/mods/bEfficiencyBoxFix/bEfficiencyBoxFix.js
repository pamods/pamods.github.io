$('.div_status_bar_mid').each( function() {
  $(this).css({
    'margin': '0px -3px',
    'min-width': '80px',
    'border-image': 'url(coui://ui/mods/bEfficiencyBoxFix/img/img_status_bar_mid.png) 7 7 7 7',
    'border-width': '7px 7px 7px 7px'
  });
});
$('.build_eff_text').each( function() {
  $(this).css({
    'padding-top': '0px',
	'margin': '0px 0px 1px 0px'
  });
});