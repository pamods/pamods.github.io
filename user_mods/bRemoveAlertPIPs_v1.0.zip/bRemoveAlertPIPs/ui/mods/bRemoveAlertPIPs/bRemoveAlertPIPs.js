$('.div_unit_alert').attr('data-bind', 'click: function () { $parent.acknowledge($data.id) },         css: {          div_unit_alert_commander: $data.watch_type === constants.watch_type.damage,                                                        div_animated_flash_red: $data.watch_type === constants.watch_type.damage,                                                        div_unit_alert_ready: $data.watch_type === constants.watch_type.ready,                                                        div_animated_flash_green: $data.watch_type === constants.watch_type.ready,                                                        div_unit_alert_death: $data.watch_type === constants.watch_type.death,                                                        div_animated_flash_black: $data.watch_type === constants.watch_type.death,                                                        div_unit_alert_misc: ($parent.isMisc($data.watch_type)),                                                        div_animated_flash_white: ($parent.isMisc($data.watch_type))   }')

/* I wanted to do this but it didn't work >:( If someone can get it working instead of the above
   code, then future updates are less likely to break the mod.

var dataBindStr = $(.div_unit_alert).attr('data-bind');
dataBindStr = dataBindStr.replace('mouseenter: function () { $parent.showPreview($data.id); }', '');
dataBindStr = dataBindStr.replace('mouseleave: function () { $parent.hidePreview(); }'        , '');
$(.div_unit_alert).attr('data-bind',dataBindStr);
*/