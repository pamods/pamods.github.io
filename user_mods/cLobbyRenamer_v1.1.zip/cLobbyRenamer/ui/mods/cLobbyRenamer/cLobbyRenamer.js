(function() {
	$("#main .header").html("<div id=\"lobby_name_container\"><label for=\"lobby_name\">Lobby Name</label><input id=\"lobby_name\" data-bind=\"value: model.writeGameDesc().system.name, valueUpdate: 'afterkeydown', enable: isGameCreator\" type=\"text\" /></div>");
})();

$("#lobby_name").on("keyup", function() {
	model.updateGameConfig();
});