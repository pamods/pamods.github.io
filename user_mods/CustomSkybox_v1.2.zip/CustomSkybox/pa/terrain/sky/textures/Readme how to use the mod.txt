Place the .papa skybox files in this folder.

Visit http://superouman.net/planetary-annihilation-skyboxes.html for a large collection of skyboxes made with Space Engine.

The mod contains by default the Milky Way Eagle nebula skybox.