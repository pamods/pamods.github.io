﻿(function() {
	var notEnoughEnergyBorder = 0.9;
	var notEnoughMetalBorder = 0.6;	
	var blinkSpeed = 500; //ms
	
	// MODIF - Satan Petit Cul 
	//-------------------------------------------------------------------------
	
	
	//--------------- Calcul - Efficiency ----------------
	model.energyEff = ko.computed(function() {
		return model.energyGain() / model.energyLoss() ;
	});	
	model.metalEff = ko.computed(function() {
		return model.metalGain() / model.metalLoss();
	});
	
	model.overallEff = ko.computed(function() {
	
		var mTemp = model.metalEff()
		var eTemp = model.energyEff()
		
		if (model.currentMetal()>2) {
			mTemp = 1;
		}
		if (model.currentEnergy() > 2) {
			eTemp = 1;
		}
		if (Math.min(eTemp, mTemp)>1){
			return 1;
		} else {
			return Math.min(eTemp, mTemp);
		}		
	});
	//-----------------------------------------------------


	//--------------- Definition - Conditions -------------
	// ___Storage State____________________________________
	// ______full______
	model.metalStorageFull = ko.computed(function() {
		return model.currentMetal() >= model.maxMetal();
	});
	model.energyStorageFull = ko.computed(function() {
		return model.currentEnergy() >= model.maxEnergy();
	});
	// ______empty_____
	model.metalStorageEmpty = ko.computed(function() {
		return model.currentMetal() === 0;
	});
	model.energyStorageEmpty = ko.computed(function() {
		return model.currentEnergy() === 0;
	});
	// ______mid_______
	model.metalStorageMid = ko.computed(function() {
		return !model.metalStorageFull() && !model.metalStorageEmpty();
	});
	model.energyStorageMid = ko.computed(function() {
		return !model.energyStorageFull() && !model.energyStorageEmpty();
	});
	// ___Metal efficiency_________________________________
	model.metalEff_75plus = ko.computed(function() {
		return model.metalEff() > 0.75;
	});
	model.metalEff_75_50 = ko.computed(function() {
		return (model.metalEff() > 0.5 && model.metalEff() <= 0.75) ;
	});
	model.metalEff_50_33 = ko.computed(function() {
		return (model.metalEff() > 0.33 && model.metalEff() <= 0.5) ;
	});
	model.metalEff_33 = ko.computed(function() {
		return model.metalEff() <= 0.33;
	});
	// ___Energy efficiency________________________________
	model.energyEff_150plus = ko.computed(function() {
		return model.energyEff() > 1.50;
	});
	model.energyEff_150_120 = ko.computed(function() {
		return (model.energyEff() > 1.20 && model.energyEff() <= 1.50);
	});
	model.energyEff_120_100 = ko.computed(function() {
		return (model.energyEff() > 1 && model.energyEff() <= 1.20);
	});
	model.energyEff_100_90 = ko.computed(function() {
		return (model.energyEff() > 0.9 && model.energyEff() <= 1);
	});
	model.energyEff_90 = ko.computed(function() {
		return (model.energyEff() > 0 && model.energyEff() <= 0.9);
	});

	// ___Overall efficiency________________________________
	model.overallEff_75plus = ko.computed(function() {
		return model.overallEff() > 0.75;
	});
	model.overallEff_75_50 = ko.computed(function() {
		return (model.overallEff() > 0.5 && model.overallEff() <= 0.75);
	});
	model.overallEff_50_33 = ko.computed(function() {
		return (model.overallEff() > 0.33 && model.overallEff() <= 0.5);
	});
	model.overallEff_33 = ko.computed(function() {
		return model.overallEff() <= 0.33;
	});

	//-----------------------------------------------------
	
	
	
	
	
	//-------------------------------------------------------------------------
	
	model.isBlink = ko.observable(false);
	var toggleBlink = function() {
		window.setTimeout(function() {
			model.isBlink(!model.isBlink());
			toggleBlink();
		}, blinkSpeed);
	};
	toggleBlink();

	
	// bindings for the display stuff
	
	model.energyNetK = ko.computed(function() {
		return model.energyNet() / 1000;
	});
	model.energyGainK = ko.computed(function() {
		return model.energyGain() / 1000;
	});
	model.energyLossK = ko.computed(function() {
		return model.energyLoss() / 1000;
	});
	model.energyNetKStr = ko.computed(function() {
		var positive = model.energyNetK() > 0;
		var a = positive ? "+" : "";
		return a+model.energyNetK().toFixed(1)+" k";
	});
	model.energyGainKStr = ko.computed(function() {
		return "+ " + model.energyGainK().toFixed(1)+" k";
	});
	model.energyLossKStr = ko.computed(function() {
		return model.energyLossK().toFixed(1)+" k";
	});
	model.metalGainStr = ko.computed(function() {
		return "+ " + model.metalGain();
	});
	
	var possibleInf = function(n) {
		if (!isFinite(n)) {
			return "∞   ";
		} else {
			return n;
		}
	}
	
	
	model.energyMaxK = ko.computed(function() {
		return model.maxEnergy()/1000 ;
	});
	model.energyMaxKStr = ko.computed(function() {
		return model.energyMaxK() + ' k';
	});
	
	model.metalMaxK = ko.computed(function() {
		return model.maxMetal() / 1000;
	});
	model.metalMaxKStr = ko.computed(function() {
		return model.metalMaxK() + ' k';
	});
	
	model.roundOverallEff = ko.computed(function() {		
		return '' + possibleInf(Math.floor(model.overallEff() * 100)); 
	});
	model.roundMetalEff = ko.computed(function() {		
		return '' + possibleInf(Math.floor(100 * model.metalEff())) ;		
	});
	model.roundEnergyEff = ko.computed(function() {		
			return '' + possibleInf(Math.floor(100 * model.energyEff())) ;		
	});
	
	$('.div_status_bar').empty().load("coui://ui/mods/EcoEffv2/live_game_econ.html", function() {
		ko.applyBindings(model, $('#ecoeff2container').get(0));
	});
}());
