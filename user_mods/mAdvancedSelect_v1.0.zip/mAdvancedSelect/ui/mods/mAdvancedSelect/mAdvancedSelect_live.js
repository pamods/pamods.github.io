if(mAdvancedSelect){
	mAdvancedSelect.hook_keys();
	mAdvancedSelect.apply_keybinds();
}