dShowOffline
======

Mod for Planetary Annihilation to show if your fellow players are still connected to the game.

WARNING: This does not work for shared armies.
