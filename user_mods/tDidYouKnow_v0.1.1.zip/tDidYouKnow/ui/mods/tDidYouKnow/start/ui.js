//add below version
$("#version_info").append("<div><a id=\"tdidyouknow_button\" onclick=\"tDidYouKnow_reload()\"><span class=\"nav_item_text\">Did you know?</span></a></div><div id=\"tdidyouknow\" style=\"width:340px;margin-left:auto;margin-right:auto;\"></div>");

//define reload
var tDidYouKnow_previous = 0;
function tDidYouKnow_reload() {
console.log("reload");
	var num = Math.floor(Math.random()*tDidYouKnowData.length);
        while( (num === tDidYouKnow_previous) || (tDidYouKnowData[num].ingame === 'no') ) {
console.log("reloadd");
		num = Math.floor(Math.random()*tDidYouKnowData.length);		
	}
	var out="";
	if(tDidYouKnowData[num].type === 'glossary') {
		out = "<p><b>Term '"+tDidYouKnowData[num].id+"'</b>: "+tDidYouKnowData[num].desc+"</p>";
	} else if(tDidYouKnowData[num].type === 'fact') {
		out = "<p><b>Fact</b>: "+tDidYouKnowData[num].desc+"</p>";
	} else if(tDidYouKnowData[num].type === 'tip') {
		out = "<p><b>Tip</b>: "+tDidYouKnowData[num].desc+"</p>";
	}
	$("#tdidyouknow").html(out);
	tDidYouKnow_previous = num;
};

//load for the first time
tDidYouKnow_reload();
