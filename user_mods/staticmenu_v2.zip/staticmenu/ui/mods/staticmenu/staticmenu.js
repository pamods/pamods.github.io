if (model.mode() === 0) {
	model.mode(1);
}

// this crashes starfield.js, CPU load goes down
// I can't find any hooks to gracefully shut it down :(
$('canvas').each( function(i,c) {
	c.remove();
});
