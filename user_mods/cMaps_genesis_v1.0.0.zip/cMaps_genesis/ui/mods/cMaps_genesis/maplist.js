cShareSystems.load_pas("Genesis", [
	"coui://ui/mods/cMaps_genesis/systems/caledonia.pas",
	"coui://ui/mods/cMaps_genesis/systems/capital_n.pas",
	"coui://ui/mods/cMaps_genesis/systems/clarke.pas",
	"coui://ui/mods/cMaps_genesis/systems/cross_back.pas",
	"coui://ui/mods/cMaps_genesis/systems/dust_of_doom.pas",
	"coui://ui/mods/cMaps_genesis/systems/dustbowl.pas",
	"coui://ui/mods/cMaps_genesis/systems/faceoff.pas",
	"coui://ui/mods/cMaps_genesis/systems/honeypot.pas",
	"coui://ui/mods/cMaps_genesis/systems/station_3.pas",
	"coui://ui/mods/cMaps_genesis/systems/systeem_x.pas",
	"coui://ui/mods/cMaps_genesis/systems/taxman.pas",
	"coui://ui/mods/cMaps_genesis/systems/tug_of_war.pas",
	"coui://ui/mods/cMaps_genesis/systems/water_world.pas"
]);