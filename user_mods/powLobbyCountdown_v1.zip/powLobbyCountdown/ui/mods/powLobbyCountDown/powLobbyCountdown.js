(function() {
// ### START CONFIG ###

// how many seconds to count down
self.seconds_to_wait = 15

// ### END CONFIG ###

    // remember how to actually start the game
    self.really_start_game = model.startGame
    // did the user request to abort the start?
    self.abort = false;
    // is the countdown running?
    self.running = false;

    // helper to check if game can start and reset UI
    self.checkStartability = function() {
        if (model.gameIsNotOk()) {
            model.showStartGameError(true);
            $(".btn_hero").find(".btn_label").text("Start Game");
            return false;
        }
        return true;
    }

    // helper to send chat messages
    self.sendChat = function (seconds) {
        var msg = {};
        if (seconds == -1) {
            self.running = false;
            msg.message = 'Game start aborted!';
        } else {
            msg.message = 'Game starts in ' + seconds + ' seconds';
        }
        model.send_message("chat_message", msg);
    }

    // helper to do countdown loop
    self.countdown = function (seconds) {
        if (self.abort || !self.checkStartability()) {
            self.sendChat(-1);
            return;
        }
        if (seconds >= 1) {
            if (seconds > 0 && seconds % 5 == 0 || seconds < 5) {
                self.sendChat(seconds);
            }
            seconds--;
            setTimeout(function() {self.countdown(seconds); }, 1000);
        } else {
            if (self.checkStartability()) {
                self.really_start_game();
            }
        }
    }

    // change ui button
    self.myStartButton = function() {
        if (self.running) {
            self.abort = true;
            $(".btn_hero").find(".btn_label").text("Start Game");
        } else {
            if (!self.checkStartability()) {
                return;
            }
            self.abort = false;
            self.running = true;
            $(".btn_hero").find(".btn_label").text("Abort Start");
            self.countdown(self.seconds_to_wait);
        }
    }

    model.startGame = self.myStartButton
})();