cPlanetNameThemes.themes["Legacy"] = {
	earth: new Array(
		"Aqueous Minor",
		"Capella",
		"Copernicus",
		"Earth",
		"Minerva",
		"Seton",
		"Thalassean"
	),

	ice: new Array(
		"Blue Sky",
		"Gelidus",
		"Hydross",
		"Luthien",
		"Rigel",
		"Seraphim II"
	),

	desert: new Array(
		"Pollux",
		"Tergiverse IV",
		"Theban II",
		"Zeta Canis"
	),

	moon: new Array(
		"Dump",
		"Eridani",
		"Griffin IV",
		"Rougpelt",
		"Temblor"
	),

	tropical: new Array(
		"Empyrrean",
		"Hydross",
		"Lusch",
		"Matar",
		"Nigh Pilago",
		"Pearl II"
	),

	lava: new Array(
		"Barathrum",
		"Orionis",
		"Pisces IV",
		"Procyon"
	),

	metal: new Array(
		"Central Consciousness",
		"Core Prime"
	)
}