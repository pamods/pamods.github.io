// Planet Name Themes
// By Captain Conundrum
// Replaces Uber's random names with planet names from Star Wars, Stargate, Star Trek or Legacy (Names from TA and SupCom).
// Pick the theme from the settings menu.

// Create a new object and make it available in the global namespace.
var cPlanetNameThemes = (function () {

	var cPlanetNameThemes = {};

	cPlanetNameThemes.themes = {};

	// Publicly available random name generator!
	cPlanetNameThemes.getPlanetName = function(planet) {
		// Get all the names this planet could use
		var planetNames = getPlanetNames(planet);
		// Pick one
		var rand = Math.random()*planetNames.length|0;
     	return planetNames[rand];
	};

	// Public function to get the current naming theme from the game's settings.
	cPlanetNameThemes.getTheme = function() {
		// Set a default in case the user hasn't picked one
		initialSettingValue("cPlanetNameThemes_theme", "Star Wars");
		// Get it from settings
		var settings = decode(localStorage.settings);
		var theme = settings.cPlanetNameThemes_theme;
		return this.themes[theme];
	};

	// Public function to get all of the theme objects that have registered themselves with this mod.
	cPlanetNameThemes.getThemeNames = function() {
		var themeNames = new Array();

		for(var theme in this.themes) {
		    themeNames.push(theme);
		}

		return themeNames;
	};

	// Private function. Gets the list of all names that could be used for a given planet.
	function getPlanetNames(planet) {
		var theme = cPlanetNameThemes.getTheme();
		var biome = getBiome(planet);

		// Get the right name list.
		// If a theme is missing a biome, it will default to earth.
		switch(biome) {
			case "earth":
				return theme.earth;
			case "moon":
				if(theme.moon)
					return theme.moon;
				else return theme.earth;
			case "tropical":
				if(theme.tropical)
					return theme.tropical;
				else return theme.earth;
			case "lava":
				if(theme.lava)
					return theme.lava;
				else return theme.earth;
			case "metal":
				if(theme.metal)
					return theme.metal;
				else return theme.earth;
			case "ice":
				if(theme.ice)
					return theme.ice;
				else return theme.earth;
			case "desert":
				if(theme.desert)
					return theme.desert;
				else return theme.earth;
		}
	}

	// Private function to get a planet's biome.
	function getBiome(planet) {
		// Unless the biome is earth, this is really easy and we're already done.
		// Ice and desert aren't explicit biomes though.
		// We have to figure them out from temperature and water height.
		var biome = planet.biome;
		if(biome !== "earth")
			return biome;

		var temperature = planet.temperature;
		var waterHeight = planet.waterHeight;

		// I'm just using some arbitrary numbers here to define ice and desert.
		if(temperature <= 20)
			return "ice";

		if(temperature >= 80 && waterHeight <= 45)
			return "desert";

		return "earth";
	}

	return cPlanetNameThemes;
})();