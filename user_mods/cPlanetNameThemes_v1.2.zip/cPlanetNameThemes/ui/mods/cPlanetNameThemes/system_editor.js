// Override Uber's random name function with this.
// Uber's function makes an engine call to get the name, but this one uses cPlanetNameThemes.
model.new_planet_name = function() {
	// Get the current planet.
	var planet = model.planetSpec().planet;
	// Ask for a new name. cPlanetNameThemes needs to be given the planet so that it can see the biome.
	var planetName = cPlanetNameThemes.getPlanetName(planet);

	// Update the UI with the new name. (What the player sees)
	model.planetName(planetName);
	// Update the system model with the new name. (What the game sees)
	model.system().planets[model.selectedPlanetIndex()].name = planetName;
}

