//load html dynamically
function loadHtmlTemplate(element, url) {
    element.load(url, function () {
        console.log("Loading html " + url);
        element.children().each(function() {
			ko.applyBindings(model, this);
		});
    });
}

/*
 * Inject a ton of html
 */

// SHARED SYSTEMS tab
$(".content .tab-content").append("<div id='cShareSystems' class='tab-pane active' data-bind='visible: showSharedSystems'>");
loadHtmlTemplate($(".content .tab-content div:last"), "coui://ui/mods/cShareSystems/load_planet/tab_content.html");

// Filtering options
//$(".div_pre_game_header").append("<div id=\"filter-controls\" data-bind=\"visible: showSharedSystems\">	<div id=\"filter-controls-inner\">		<div>			<table>				<tr>					<td>						<span class=\"input_label\">System Name</span>					</td>					<td>						<input type=\"text\" data-bind=\"value: cShareSystems.filterOptions().name, valueUpdate: 'afterkeydown'\">					</td>				</tr>					<td>						<span class=\"input_label\">Creator</span>					</td>					<td>						<input type=\"text\" data-bind=\"value: cShareSystems.filterOptions().creator, valueUpdate: 'afterkeydown'\">					</td>				</tr>			</table>		</div>		<div style=\"margin-left: 10px;\">			<table>				<tr>					<td>						<span class=\"input_label\">Planets</span>					</td>					<td style=\"padding-left: 10px;\">						<input type=\"number\" min=\"1\" max=\"16\" step=\"1\" data-bind=\"value: cShareSystems.filterOptions().minPlanets, valueUpdate: 'afterkeydown'\">						 - 						<input type=\"number\" min=\"1\" max=\"16\" step=\"1\" data-bind=\"value: cShareSystems.filterOptions().maxPlanets, valueUpdate: 'afterkeydown'\">					</td>				</tr>					<td style=\"padding-top: 1px;\">						<span class=\"input_label\">Sort By</span>					</td>					<td>						<select class=\"div_settings_control_select\" data-bind=\"value: cShareSystems.filterOptions().sort_field, valueUpdate: ['afterkeydown', 'propertychange', 'input']\">							<option value=\"system_id\">Most Recent</option>							<option value=\"num_planets\">Planets</option>						</select>					</td>				</tr>			</table>		</div>	</div></div>");

// SHARED SYSTEMS button
$(".container.panel_std #main .header #content-tabs").append("<li></li>");
loadHtmlTemplate($(".container.panel_std #main .header #content-tabs li:last"), "coui://ui/mods/cShareSystems/load_planet/tab_button.html");

// LOAD SYSTEM button
$("#button-bar").append("<div></div>");
loadHtmlTemplate($("#button-bar div:last"), "coui://ui/mods/cShareSystems/load_planet/button_bar.html");

// Add a div for the loading animation.
//$(".wrapper tab-content").append("<div id=\"cSystemSharing_loading_div\" class=\"cSystemSharing_loading_div cSystemSharing_loading_div_load_planet\"></div>");

/*
 * Add some jquery handlers that will force a new search every time a filter is updated.
 */

$("#filter-controls input,select").on("keyup", function() {
	cShareSystems.searchSystems({}, 0);
}).on("click", function() {
	cShareSystems.searchSystems({}, 0);
});


/*
 * Extend the model with a handler for the new button
 */

model.showSharedSystems = ko.computed(function() { return model.showValue() == 'cShareSystems'});

model.show_shared_systems = function() {
	model.selectedSystemIndex(-1);
	$(".selected_planet").removeClass("selected_planet");
	model.showValue("cShareSystems");

	cShareSystems.searchSystems({}, 0, true);
};

// Override
model.selectedSystem = ko.computed(function () {
	var systems;
	if(!model.showSharedSystems())
		systems = model.systems;
	else if(model.showSharedSystems())
		systems = cShareSystems.systems;

	var selected_system = systems()[model.selectedSystemIndex()] ? systems()[model.selectedSystemIndex()] : {};

	return selected_system;
});

// Override
model.selectedSystemName = ko.computed(function () {
	if(!model.showSharedSystems())
		return (model.systems()[model.selectedSystemIndex()]) ? model.systems()[model.selectedSystemIndex()].name : '';
	else if(model.showSharedSystems())
		return (cShareSystems.systems()[model.selectedSystemIndex()]) ? cShareSystems.systems()[model.selectedSystemIndex()].name : '';
});

