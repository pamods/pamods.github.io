initialSettingValue("cBBB_Trans", 0);
initialSettingValue("cBBB_Size", 65);

//$('head').append( "<link id='cBBCSS' href='' rel='stylesheet' type='text/css'>" );

var CBB = decode(localStorage.settings).cBBB_Trans;
console.log("cBBB: Loaded, cBBB_Trans = " + CBB);

var CBB_Size = decode(localStorage.settings).cBBB_Size;
console.log("CBB_Size= " + CBB_Size + "%");

var c_Size_w = CBB_Size * 0.01 * 62;
var c_Size_h = CBB_Size * 0.01 * 56;

(function () {
$('.div_build_item').css('height', c_Size_h).css('width', c_Size_w);
})();

if (CBB === "Transparency On")
    {
    $(".div_build_bar_midspan > div").css('margin', '0px 0px 0px 0px').css('background-color', 'rgba(13, 13, 13, .7)');
    loadCSS('coui://ui/alpha/live_game/corBetterBuildBar.css')
    }
else if (CBB === "Transparency Off")
    {
    $(".div_build_bar_midspan > div").css('margin', '0px 0px 0px 0px').css('background-color', 'rgba(13, 13, 13, 1)');
    loadCSS('coui://ui/alpha/live_game/corBetterBuildBar.css')
    }
else if (CBB === "Icons Only")
    {
    $(".div_build_bar_midspan > div").css('margin', '0px 0px 0px 0px').css('background', 'none');
    loadCSS('coui://ui/alpha/live_game/corBetterBuildBarMini.css');
    }
else if (CBB === "No Borders")
    {
    $(".div_build_bar_midspan > div").css('margin', '0px 0px 0px 0px').css('background-color', 'rgba(13, 13, 13, .7)');
    loadCSS('coui://ui/alpha/live_game/corBetterBuildBarMiniWithBG.css');
    }
else if (CBB === "Trans Borders")
    {
    $(".div_build_bar_midspan > div").css('margin', '0px 0px 0px 0px').css('background-color', 'rgba(13, 13, 13, .7)');
    loadCSS('coui://ui/alpha/live_game/corBetterBuildBarWithTransBorder.css');
    }