window.AudioContext = window.AudioContext || window.webkitAudioContext;
context = new AudioContext();

initialSettingValue("tauntVolume", 10);
initialSettingValue("tauntsMax", 1);

var gg = {

	"1"  : new GG(/^gg\s*$/i, "GG", "coui://ui/mods/cGGButton/taunts/GG.wav"),
	"2"  : new GG(/^\+sing$/, "+sing", "coui://ui/mods/cGGButton/taunts/sing.wav"),
	"4"  : new GG(/^.*\s+op[\.\,\!\)]*$/i, "zOMG t2 air is op!", "coui://ui/mods/cGGButton/taunts/aww.wav")

};

function GG(word, name, path){

	this.word 	= word;
	this.name 	= name;
	this.path 	= path;
	this.buffer = undefined;

	this.load = function(callback){

		var self = this,
			request = new XMLHttpRequest();

		request.open("GET", this.path, true);
		request.responseType = "arraybuffer";

		request.onload = function(){

			context.decodeAudioData(request.response, function(buffer){

				self.buffer = buffer;

			}, function(error){
				console.error("Error while loading sound: " + self.path);
			});

		}

		request.send();
	}

	this.play = function(){

		var settings = decode(localStorage.settings);

		//Maximum of five taunts at the same time to prevent spamming
		if(context.activeSourceCount >= parseInt(settings.tauntsMax)) return;

		//Create Gain
		var volume = context.createGainNode();
		volume.gain.value = settings.tauntVolume / 10;

		//Create audio source
		var source = context.createBufferSource();
		source.buffer = this.buffer;

		//Connect source to volume
		source.connect(volume);
		//Connect volume
		volume.connect(context.destination);

		//Play
		source.start(0);

		//Added a cleaning method, which may or may not work
		setTimeout(function(){

			source = undefined;
			volume = undefined;

			return;

		}, source.buffer.duration * 1000 + 1000)
	}
}

//Load all the taunts
for(i in gg){
	gg[i].load();
}

