var linger = {};
linger['text'] = {
    load: function (id) {
        throw new Error('Dynamic load not allowed: ' + id);
    }
};
linger['text_linger_exit_buttonhtml'] = '<h3>Lingering</h3>\n<a data-bind="click_sound: \'default\', rollover_sound: \'default\'">\n  <input type="button" class="btn_commit"  data-bind="click: navToGameOver" value="FINISHED"/>\n</a>\n';
linger['linger_linger'] = function (html) {
    
    var linger = {
            liveGameServerState: handlers.server_state,
            gameOverUrl: '../game_over/game_over.html',
            visible: false,
            lingerServerState: function (msg) {
                if (msg.state == 'game_over') {
                    linger.gameOverUrl = msg.url;
                    linger.showButton();
                    msg.url = null;
                }
                linger.liveGameServerState(msg);
            },
            viewModel: {
                navToGameOver: function () {
                    model.gameOverReviewMode(false);
                    window.location.href = linger.gameOverUrl;
                }
            },
            showButton: function () {
                if (linger.visible)
                    return;
                linger.visible = true;
                createFloatingFrame('linger_exit_button_frame', 200, 40, {
                    'offset': 'leftCenter',
                    'left': 0
                });
                var $container = $('#linger_exit_button_frame_content');
                $(html).appendTo($container);
                ko.applyBindings(linger.viewModel, $container[0]);
            }
        };
    handlers.server_state = linger.lingerServerState;
    return linger;
}(linger['text_linger_exit_buttonhtml']);
