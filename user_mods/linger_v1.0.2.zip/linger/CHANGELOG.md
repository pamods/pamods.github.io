## 1.0.2

- Only show the button once if there are multiple game_over state events

## 1.0.1

- Typo correction in description
