model.addSetting_DropDown('ANNOY ON METAL STALL', 'tAnnoyMe_metal_stall', 'UI', ['YES', 'NO'], 0, 'Annoy Me');
model.addSetting_DropDown('ANNOY ON METAL SURPLUS', 'tAnnoyMe_metal_surplus', 'UI', ['YES', 'NO'], 0, 'Annoy Me');
model.addSetting_DropDown('ANNOY ON ENERGY STALL', 'tAnnoyMe_energy_stall', 'UI', ['YES', 'NO'], 0, 'Annoy Me');
model.addSetting_DropDown('ANNOY ON ENERGY SURPLUS', 'tAnnoyMe_energy_surplus', 'UI', ['YES', 'NO'], 0, 'Annoy Me');
model.addSetting_DropDown('ANNOY INTERVAL', 'tAnnoyMe_interval', 'UI', ['1', '2', '3', '5', '10', '15', '20', '30', '40', '50', '60'], 4, 'Annoy Me');
