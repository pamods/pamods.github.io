model.addSetting_Slider('T1 BOT Metal % threshold', 'tAutoFactory_t1_bot_metal', 'UI', 1, 99, 80, 'Auto Factory');
model.addSetting_Slider('T1 BOT Energy % threshold', 'tAutoFactory_t1_bot_energy', 'UI', 1, 99, 80, 'Auto Factory');
model.addSetting_DropDown('T1 BOT Unit Choice', 'tAutoFactory_dd_t1_bot', 'UI', ['FABBER', 'COMBAT FABBER', 'STINGER', 'DOX', 'BOOM', 'NONE'], 3, 'Auto Factory');

model.addSetting_Slider('T2 BOT Metal % threshold', 'tAutoFactory_t2_bot_metal', 'UI', 1, 99, 80, 'Auto Factory');
model.addSetting_Slider('T2 BOT Energy % threshold', 'tAutoFactory_t2_bot_energy', 'UI', 1, 99, 80, 'Auto Factory');
model.addSetting_DropDown('T2 BOT Unit Choice', 'tAutoFactory_dd_t2_bot', 'UI', ['ADV FABBER', 'ADV COMBAT FABBER', 'GIL-E', 'SLAMMER', 'NONE'], 3, 'Auto Factory');

model.addSetting_Slider('T1 VEHICLE Metal % threshold', 'tAutoFactory_t1_veh_metal', 'UI', 1, 99, 80, 'Auto Factory');
model.addSetting_Slider('T1 VEHICLE Energy % threshold', 'tAutoFactory_t1_veh_energy', 'UI', 1, 99, 80, 'Auto Factory');
model.addSetting_DropDown('T1 VEHICLE Unit Choice', 'tAutoFactory_dd_t1_veh', 'UI', ['FABBER', 'SKITTER', 'INFERNO', 'SPINNER', 'HISTERICLESE', 'NONE'], 4, 'Auto Factory');

model.addSetting_Slider('T2 VEHICLE Metal % threshold', 'tAutoFactory_t2_veh_metal', 'UI', 1, 99, 80, 'Auto Factory');
model.addSetting_Slider('T2 VEHICLE Energy % threshold', 'tAutoFactory_t2_veh_energy', 'UI', 1, 99, 80, 'Auto Factory');
model.addSetting_DropDown('T2 VEHICLE Unit Choice', 'tAutoFactory_dd_t2_veh', 'UI', ['ADV FABBER', 'VANGUARD', 'SHELLER', 'LEVELER', 'NONE'], 3, 'Auto Factory');

model.addSetting_Slider('T1 AIR Metal % threshold', 'tAutoFactory_t1_air_metal', 'UI', 1, 99, 80, 'Auto Factory');
model.addSetting_Slider('T1 AIR Energy % threshold', 'tAutoFactory_t1_air_energy', 'UI', 1, 99, 80, 'Auto Factory');
model.addSetting_DropDown('T1 AIR Unit Choice', 'tAutoFactory_dd_t1_air', 'UI', ['FABBER', 'FIREFLY', 'HUMMINGBIRD', 'BUMBLEBEE', 'NONE'], 3, 'Auto Factory');

model.addSetting_Slider('T2 AIR Metal % threshold', 'tAutoFactory_t2_air_metal', 'UI', 1, 99, 80, 'Auto Factory');
model.addSetting_Slider('T2 AIR Energy % threshold', 'tAutoFactory_t2_air_energy', 'UI', 1, 99, 80, 'Auto Factory');
model.addSetting_DropDown('T2 AIR Unit Choice', 'tAutoFactory_dd_t2_air', 'UI', ['ADV FABBER', 'PELICAN', 'KESTREL', 'PEREGRINE', 'HORNET', 'NONE'], 3, 'Auto Factory');

model.addSetting_Slider('T1 NAVAL Metal % threshold', 'tAutoFactory_t1_nav_metal', 'UI', 1, 99, 80, 'Auto Factory');
model.addSetting_Slider('T1 NAVAL Energy % threshold', 'tAutoFactory_t1_nav_energy', 'UI', 1, 99, 80, 'Auto Factory');
model.addSetting_DropDown('T1 NAVAL Unit Choice', 'tAutoFactory_dd_t1_nav', 'UI', ['FABBER', 'SUN FISH', 'NARWHAL', 'ORCA', 'NONE'], 3, 'Auto Factory');

model.addSetting_Slider('T2 NAVAL Metal % threshold', 'tAutoFactory_t2_nav_metal', 'UI', 1, 99, 80, 'Auto Factory');
model.addSetting_Slider('T2 NAVAL Energy % threshold', 'tAutoFactory_t2_nav_energy', 'UI', 1, 99, 80, 'Auto Factory');
model.addSetting_DropDown('T2 NAVAL Unit Choice', 'tAutoFactory_dd_t2_nav', 'UI', ['ADV FABBER', 'LEVIATHAN', 'STINGRAY', 'NONE'], 1, 'Auto Factory');

model.addSetting_Slider('ORBITAL Metal % threshold', 'tAutoFactory_t1_orb_metal', 'UI', 1, 99, 80, 'Auto Factory');
model.addSetting_Slider('ORBITAL Energy % threshold', 'tAutoFactory_t1_orb_energy', 'UI', 1, 99, 80, 'Auto Factory');
model.addSetting_DropDown('ORBITAL Unit Choice', 'tAutoFactory_dd_t1_orb', 'UI', ['FABBER', 'ASTRAEUS', 'AVENGER', 'RADAR SATELLITE', 'NONE'], 0, 'Auto Factory');

model.addSetting_Slider('NUKE LAUNCHER Metal % threshold', 'tAutoFactory_t1_nuk_metal', 'UI', 1, 99, 80, 'Auto Factory');
model.addSetting_Slider('NUKE LAUNCHER Energy % threshold', 'tAutoFactory_t1_nuk_energy', 'UI', 1, 99, 80, 'Auto Factory');
model.addSetting_DropDown('NUKE LAUNCHER Unit Choice', 'tAutoFactory_dd_t1_nuk', 'UI', ['NUKE', 'NONE'], 0, 'Auto Factory');

model.addSetting_Slider('ANTI-NUKE LAUNCHER Metal % threshold', 'tAutoFactory_t1_ank_metal', 'UI', 1, 99, 80, 'Auto Factory');
model.addSetting_Slider('ANTI-NUKE LAUNCHER Energy % threshold', 'tAutoFactory_t1_ank_energy', 'UI', 1, 99, 80, 'Auto Factory');
model.addSetting_DropDown('ANTI-NUKE LAUNCHER Unit Choice', 'tAutoFactory_dd_t1_ank', 'UI', ['ANTI-NUKE', 'NONE'], 0, 'Auto Factory');


