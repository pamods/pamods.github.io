(function () {
    "use strict";

    function loadTemplate(element, url) {
        element.load(url, function () {
            ko.applyBindings(model, element.get(0));
        });
    }

    //visible to knockout
    model.tAutoFactory = tAutoFactory;

    //update every second
    setInterval(tAutoFactory.update, 1000);
    //instead of polling, try hijacking api.select.empty TODO

    createFloatingFrame('tAutoFactory_frame', 200, 40, {'offset': 'leftCenter', 'left': 0});
    loadTemplate($('#tAutoFactory_frame_content'), 'coui://ui/mods/tAutoFactory/live_game/tAutoFactory.html');

})();
