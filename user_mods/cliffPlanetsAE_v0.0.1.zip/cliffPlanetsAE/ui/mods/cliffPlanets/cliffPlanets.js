(function() {
  model.biomes.push('sandbox')
})()