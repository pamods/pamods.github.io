var tBuildingWriter = (function () {
    "use strict";

    var tBuildingWriter = {},
        holod = api.Holodeck.get($('.holodeck')),

    /*drawn on a 100x100 grid, scale as necessary*/
        tBuildingWriter_a = [ 21, 80, 48, 18, 48, 18, 74, 80, 30, 60, 67, 60 ],
        tBuildingWriter_b = [ 36, 79, 36, 19, 36, 19, 56, 19, 56, 19, 62, 20, 62, 20, 68, 23, 68, 23, 72, 28, 72, 28, 72, 33, 72, 33, 70, 37, 70, 37, 67, 41, 67, 41, 62, 44, 62, 44, 56, 47, 56, 47, 36, 47, 56, 47, 62, 49, 62, 49, 67, 52, 67, 52, 71, 56, 71, 56, 74, 61, 74, 61, 75, 67, 75, 67, 73, 72, 73, 72, 69, 76, 69, 76, 65, 78, 65, 78, 59, 79, 59, 79, 36, 79 ],
        tBuildingWriter_c = [ 70, 21, 66, 19, 66, 19, 59, 17, 59, 17, 51, 17, 51, 17, 43, 18, 43, 18, 38, 20, 38, 20, 33, 24, 33, 24, 29, 29, 29, 29, 25, 37, 25, 37, 23, 45, 23, 45, 23, 53, 23, 53, 25, 61, 25, 61, 29, 68, 29, 68, 33, 73, 33, 73, 38, 77, 38, 77, 44, 80, 44, 80, 50, 81, 50, 81, 57, 81, 57, 81, 63, 80, 63, 80, 71, 77 ],
        tBuildingWriter_d = [ 29, 79, 29, 19, 29, 19, 46, 19, 46, 19, 59, 22, 59, 22, 64, 25, 64, 25, 68, 29, 68, 29, 71, 32, 71, 32, 73, 37, 73, 37, 74, 42, 74, 42, 74, 50, 74, 50, 73, 56, 73, 56, 72, 60, 72, 60, 70, 64, 70, 64, 68, 68, 68, 68, 64, 72, 64, 72, 59, 75, 59, 75, 53, 78, 53, 78, 47, 79, 47, 79, 29, 79 ],
        tBuildingWriter_e = [ 65, 19, 28, 19, 28, 19, 28, 79, 28, 79, 65, 79, 28, 48, 60, 48 ],
        tBuildingWriter_f = [ 73, 19, 33, 19, 33, 19, 33, 79, 33, 51, 65, 51 ],
        tBuildingWriter_g = [ 72, 20, 67, 18, 67, 18, 60, 17, 60, 17, 51, 17, 51, 17, 43, 19, 43, 19, 37, 23, 37, 23, 33, 28, 33, 28, 29, 34, 29, 34, 27, 40, 27, 40, 26, 46, 26, 46, 26, 54, 26, 54, 28, 61, 28, 61, 32, 68, 32, 68, 36, 73, 36, 73, 42, 77, 42, 77, 47, 79, 47, 79, 53, 80, 53, 80, 64, 80, 64, 80, 68, 79, 68, 79, 71, 76, 71, 76, 71, 54, 71, 54, 57, 54 ],
        tBuildingWriter_h = [ 30, 18, 30, 80, 30, 49, 69, 49, 69, 18, 69, 80 ],
        tBuildingWriter_i = [ 27, 17, 72, 17, 49, 17, 49, 77, 27, 77, 72, 77 ],
        tBuildingWriter_j = [ 25, 21, 78, 21, 53, 21, 53, 70, 53, 70, 52, 74, 52, 74, 49, 78, 49, 78, 44, 82, 44, 82, 39, 83, 39, 83, 33, 83, 33, 83, 28, 82, 28, 82, 24, 80, 24, 80, 21, 77 ],
        tBuildingWriter_k = [ 29, 17, 29, 83, 29, 49, 67, 17, 29, 49, 71, 83 ],
        tBuildingWriter_l = [ 32, 14, 32, 76, 32, 76, 73, 76 ],
        tBuildingWriter_m = [ 26, 83, 26, 17, 26, 17, 49, 69, 49, 69, 72, 17, 72, 17, 72, 83 ],
        tBuildingWriter_n = [ 31, 83, 31, 17, 31, 17, 72, 83, 72, 83, 72, 17 ],
        tBuildingWriter_o = [ 52, 18, 45, 19, 45, 19, 39, 22, 39, 22, 35, 25, 35, 25, 32, 30, 32, 30, 30, 35, 30, 35, 29, 40, 29, 40, 28, 47, 28, 47, 28, 54, 28, 54, 29, 61, 29, 61, 31, 68, 31, 68, 34, 72, 34, 72, 37, 76, 37, 76, 40, 79, 40, 79, 45, 81, 45, 81, 50, 82, 50, 82, 56, 82, 56, 82, 61, 80, 61, 80, 65, 77, 65, 77, 68, 74, 68, 74, 71, 70, 71, 70, 73, 66, 73, 66, 75, 61, 75, 61, 76, 55, 76, 55, 76, 47, 76, 47, 75, 40, 75, 40, 74, 35, 74, 35, 72, 30, 72, 30, 69, 26, 69, 26, 65, 22, 65, 22, 59, 19, 59, 19, 52, 18 ],
        tBuildingWriter_p = [ 32, 83, 32, 20, 32, 20, 54, 20, 54, 20, 61, 21, 61, 21, 66, 24, 66, 24, 69, 29, 69, 29, 70, 34, 70, 34, 70, 41, 70, 41, 67, 46, 67, 46, 63, 50, 63, 50, 58, 53, 58, 53, 50, 54, 50, 54, 32, 54 ],
        tBuildingWriter_q = [ 47, 14, 40, 17, 40, 17, 33, 22, 33, 22, 28, 32, 28, 32, 26, 42, 26, 42, 26, 54, 26, 54, 28, 63, 28, 63, 31, 69, 31, 69, 35, 74, 35, 74, 40, 77, 40, 77, 47, 79, 47, 79, 53, 79, 53, 79, 61, 76, 61, 76, 65, 72, 65, 72, 69, 67, 69, 67, 71, 62, 71, 62, 73, 54, 73, 54, 73, 45, 73, 45, 73, 37, 73, 37, 71, 31, 71, 31, 68, 25, 68, 25, 63, 19, 63, 19, 56, 15, 56, 15, 47, 14, 56, 79, 59, 83, 59, 83, 63, 86, 63, 86, 69, 90, 69, 90, 77, 93 ],
        tBuildingWriter_r = [ 29, 18, 29, 80, 29, 18, 53, 18, 53, 18, 59, 20, 59, 20, 62, 24, 62, 24, 64, 29, 64, 29, 64, 37, 64, 37, 59, 42, 59, 42, 53, 47, 53, 47, 46, 48, 46, 48, 30, 48, 46, 48, 71, 80 ],
        tBuildingWriter_s = [ 27, 77, 35, 79, 35, 79, 42, 81, 42, 81, 49, 82, 49, 82, 56, 81, 56, 81, 62, 79, 62, 79, 67, 75, 67, 75, 70, 70, 70, 70, 70, 63, 70, 63, 66, 57, 66, 57, 59, 53, 59, 53, 52, 50, 52, 50, 43, 47, 43, 47, 36, 43, 36, 43, 32, 37, 32, 37, 32, 29, 32, 29, 35, 23, 35, 23, 42, 19, 42, 19, 53, 18, 53, 18, 62, 20, 62, 20, 69, 23 ],
        tBuildingWriter_t = [ 16, 17, 77, 17, 47, 17, 47, 80 ],
        tBuildingWriter_u = [ 29, 17, 29, 64, 29, 64, 31, 70, 31, 70, 34, 75, 34, 75, 37, 78, 37, 78, 41, 80, 41, 80, 46, 81, 46, 81, 52, 81, 52, 81, 57, 80, 57, 80, 61, 78, 61, 78, 65, 75, 65, 75, 67, 70, 67, 70, 68, 64, 68, 64, 68, 17 ],
        tBuildingWriter_v = [ 22, 17, 48, 83, 48, 83, 74, 17 ],
        tBuildingWriter_w = [ 20, 18, 32, 84, 32, 84, 47, 32, 47, 32, 63, 84, 63, 84, 74, 18],
        tBuildingWriter_x = [ 26, 18, 74, 84, 26, 84, 74, 18 ],
        tBuildingWriter_y = [ 24, 18, 50, 54, 50, 54, 76, 18, 50, 54, 50, 84 ],
        tBuildingWriter_z = [ 26, 21, 73, 21, 73, 21, 26, 81, 26, 81, 76, 81 ],
        tBuildingWriter_0 = [ 49, 50, 49, 50, 48, 12, 57, 15, 57, 15, 62, 20, 62, 20, 66, 27, 66, 27, 68, 34, 68, 34, 69, 42, 69, 42, 70, 50, 70, 50, 69, 59, 69, 59, 67, 68, 67, 68, 64, 75, 64, 75, 60, 81, 60, 81, 54, 85, 54, 85, 47, 86, 47, 86, 40, 84, 40, 84, 35, 80, 35, 80, 32, 75, 32, 75, 29, 69, 29, 69, 27, 61, 27, 61, 26, 51, 26, 51, 26, 42, 26, 42, 27, 33, 27, 33, 29, 26, 29, 26, 33, 20, 33, 20, 39, 15, 39, 15, 48, 12 ],
        tBuildingWriter_1 = [ 26, 21, 50, 14, 50, 14, 50, 84, 26, 84, 72, 84 ],
        tBuildingWriter_2 = [ 29, 17, 36, 14, 36, 14, 44, 13, 44, 13, 52, 13, 52, 13, 58, 16, 58, 16, 62, 21, 62, 21, 64, 28, 64, 28, 64, 33, 64, 33, 62, 40, 62, 40, 57, 46, 57, 46, 52, 51, 52, 51, 45, 58, 45, 58, 37, 67, 37, 67, 33, 75, 33, 75, 30, 83, 30, 83, 66, 83 ],
        tBuildingWriter_3 = [ 30, 15, 35, 13, 35, 13, 42, 12, 42, 12, 49, 12, 49, 12, 54, 13, 54, 13, 59, 16, 59, 16, 62, 21, 62, 21, 62, 28, 62, 28, 60, 34, 60, 34, 56, 39, 56, 39, 51, 43, 51, 43, 46, 45, 46, 45, 37, 45, 46, 45, 51, 47, 51, 47, 56, 50, 56, 50, 60, 54, 60, 54, 63, 60, 63, 60, 64, 66, 64, 66, 64, 72, 64, 72, 61, 77, 61, 77, 56, 82, 56, 82, 49, 85, 49, 85, 41, 85, 41, 85, 34, 84, 34, 84, 29, 82 ],
        tBuildingWriter_4 = [ 60, 13, 24, 62, 24, 62, 72, 62, 60, 13, 60, 86 ],
        tBuildingWriter_5 = [ 65, 14, 34, 14, 34, 14, 34, 44, 34, 44, 43, 44, 43, 44, 50, 45, 50, 45, 55, 47, 55, 47, 59, 50, 59, 50, 62, 54, 62, 54, 64, 59, 64, 59, 65, 65, 65, 65, 64, 71, 64, 71, 62, 76, 62, 76, 58, 80, 58, 80, 53, 83, 53, 83, 48, 85, 48, 85, 43, 85, 43, 85, 37, 84, 37, 84, 32, 82  ],
        tBuildingWriter_6 = [ 66, 15, 60, 13, 60, 13, 53, 12, 53, 12, 45, 14, 45, 14, 38, 19, 38, 19, 33, 25, 33, 25, 30, 31, 30, 31, 28, 39, 28, 39, 27, 47, 27, 47, 28, 57, 28, 57, 29, 65, 29, 65, 32, 74, 32, 74, 36, 80, 36, 80, 40, 83, 40, 83, 44, 85, 44, 85, 48, 86, 48, 86, 52, 86, 52, 86, 57, 85, 57, 85, 61, 81, 61, 81, 64, 77, 64, 77, 66, 73, 66, 73, 67, 67, 67, 67, 68, 61, 68, 61, 68, 56, 68, 56, 66, 52, 66, 52, 62, 48, 62, 48, 58, 45, 58, 45, 53, 43, 53, 43, 47, 43, 47, 43, 41, 45, 41, 45, 36, 49, 36, 49, 32, 53 ],
        tBuildingWriter_7 = [ 30, 15, 70, 15, 70, 15, 70, 20, 70, 20, 63, 31, 63, 31, 54, 46, 54, 46, 48, 58, 48, 58, 42, 70, 42, 70, 38, 84 ],
        tBuildingWriter_8 = [ 50, 13, 42, 15, 42, 15, 35, 20, 35, 20, 33, 28, 33, 28, 35, 35, 35, 35, 40, 42, 40, 42, 50, 48, 50, 48, 57, 52, 57, 52, 62, 56, 62, 56, 67, 63, 67, 63, 69, 69, 69, 69, 68, 75, 68, 75, 64, 81, 64, 81, 55, 86, 55, 86, 47, 87, 47, 87, 39, 85, 39, 85, 34, 82, 34, 82, 31, 78, 31, 78, 29, 72, 29, 72, 29, 67, 29, 67, 30, 60, 30, 60, 34, 55, 34, 55, 40, 50, 40, 50, 52, 45, 52, 45, 61, 3, 61, 39, 64, 35, 64, 35, 65, 30, 65, 30, 65, 25, 65, 25, 64, 21, 64, 21, 61, 17, 61, 17, 57, 14, 57, 14, 50, 13 ],
        tBuildingWriter_9 = [ 64, 45, 60, 51, 60, 51, 53, 56, 53, 56, 43, 56, 43, 56, 34, 52, 34, 52, 30, 45, 30, 45, 28, 39, 28, 39, 28, 32, 28, 32, 30, 25, 30, 25, 36, 18, 36, 18, 43, 14, 43, 14, 52, 14, 52, 14, 59, 17, 59, 17, 64, 23, 64, 23, 67, 34, 67, 34, 68, 48, 68, 48, 68, 59, 68, 59, 66, 67, 66, 67, 64, 75, 64, 75, 60, 80, 60, 80, 155, 84, 155, 84, 48, 86, 48, 86, 40, 87, 40, 87, 32, 85 ],
        tBuildingWriter_backslash = [ 28, 5, 72, 94 ],
        tBuildingWriter_forwardslash = [ 26, 94, 70, 5 ],
        tBuildingWriter_lessthan = [ 69, 29, 24, 51, 24, 51, 69, 73 ],
        tBuildingWriter_greaterthan = [ 25, 29, 70, 51, 70, 51, 25, 73 ],
        tBuildingWriter_caret = [ 26, 60, 48, 10, 48, 10, 71, 60 ],
        tBuildingWriter_hash = [ 46, 13, 28, 84, 49, 84, 66, 13, 73, 37, 26, 37, 21, 61, 68, 61 ],
        tBuildingWriter_opensquarebrackets = [ 62, 5, 36, 5, 36, 5, 37, 96, 37, 96, 62, 96 ],
        tBuildingWriter_closesquarebrackets = [ 34, 4, 58, 4, 58, 4, 58, 96, 58, 96, 34, 96 ],
        tBuildingWriter_colon = [ 50, 34, 50, 34, 50, 77, 50, 77 ],
        tBuildingWriter_exclamation = [ 50, 9, 50, 59, 50, 79, 50, 79 ];
        //tBuildingWriter_ = [  ],

    tBuildingWriter.draw = function (arr, loc_x, loc_y) {
        var len = arr.length,
            i;
        if ((len % 4)) {
            console.log("tBuildingWriter.draw, invalid array length: " + len);
        }
        for (i = 0; i < len; i = i + 4) {//draw as 100x100, centered
            holod.unitBeginFab(loc_x + ((arr[i] - 50)), loc_y + ((arr[i + 1] - 50)), true);
            holod.unitEndFab(loc_x + ((arr[i + 2] - 50)), loc_y + ((arr[i + 3] - 50)), true, true);
        }
    };

    tBuildingWriter.write_text = function () {
        //center of screen
        var x = window.innerWidth / 2,
            y = window.innerHeight / 2,
            i,
        //get what user entered
            text = document.getElementById('tBuildingWriter_input').value.toLowerCase(),
        //number of characters to write
            chars_to_write = Math.min(text.length, Math.floor(x / 50)),
        //location in x, working variable
            loc_x_var =  x - (100 * Math.floor(chars_to_write / 2));
        //account for different offsets with odd and even character counts
        if ((chars_to_write % 2) === 0) {
            loc_x_var = loc_x_var + 50;
        }

        for (i = 0; i < chars_to_write; i = i + 1) {
            switch (text.charAt(i).toString()) {
            case "q":
                tBuildingWriter.draw(tBuildingWriter_q, loc_x_var, y);
                break;
            case "w":
                tBuildingWriter.draw(tBuildingWriter_w, loc_x_var, y);
                break;
            case "e":
                tBuildingWriter.draw(tBuildingWriter_e, loc_x_var, y);
                break;
            case "r":
                tBuildingWriter.draw(tBuildingWriter_r, loc_x_var, y);
                break;
            case "t":
                tBuildingWriter.draw(tBuildingWriter_t, loc_x_var, y);
                break;
            case "y":
                tBuildingWriter.draw(tBuildingWriter_y, loc_x_var, y);
                break;
            case "u":
                tBuildingWriter.draw(tBuildingWriter_u, loc_x_var, y);
                break;
            case "i":
                tBuildingWriter.draw(tBuildingWriter_i, loc_x_var, y);
                break;
            case "o":
                tBuildingWriter.draw(tBuildingWriter_o, loc_x_var, y);
                break;
            case "p":
                tBuildingWriter.draw(tBuildingWriter_p, loc_x_var, y);
                break;
            case "a":
                tBuildingWriter.draw(tBuildingWriter_a, loc_x_var, y);
                break;
            case "s":
                tBuildingWriter.draw(tBuildingWriter_s, loc_x_var, y);
                break;
            case "d":
                tBuildingWriter.draw(tBuildingWriter_d, loc_x_var, y);
                break;
            case "f":
                tBuildingWriter.draw(tBuildingWriter_f, loc_x_var, y);
                break;
            case "g":
                tBuildingWriter.draw(tBuildingWriter_g, loc_x_var, y);
                break;
            case "h":
                tBuildingWriter.draw(tBuildingWriter_h, loc_x_var, y);
                break;
            case "j":
                tBuildingWriter.draw(tBuildingWriter_j, loc_x_var, y);
                break;
            case "k":
                tBuildingWriter.draw(tBuildingWriter_k, loc_x_var, y);
                break;
            case "l":
                tBuildingWriter.draw(tBuildingWriter_l, loc_x_var, y);
                break;
            case "z":
                tBuildingWriter.draw(tBuildingWriter_z, loc_x_var, y);
                break;
            case "x":
                tBuildingWriter.draw(tBuildingWriter_x, loc_x_var, y);
                break;
            case "c":
                tBuildingWriter.draw(tBuildingWriter_c, loc_x_var, y);
                break;
            case "v":
                tBuildingWriter.draw(tBuildingWriter_v, loc_x_var, y);
                break;
            case "b":
                tBuildingWriter.draw(tBuildingWriter_b, loc_x_var, y);
                break;
            case "n":
                tBuildingWriter.draw(tBuildingWriter_n, loc_x_var, y);
                break;
            case "m":
                tBuildingWriter.draw(tBuildingWriter_m, loc_x_var, y);
                break;
            case "1":
                tBuildingWriter.draw(tBuildingWriter_1, loc_x_var, y);
                break;
            case "2":
                tBuildingWriter.draw(tBuildingWriter_2, loc_x_var, y);
                break;
            case "3":
                tBuildingWriter.draw(tBuildingWriter_3, loc_x_var, y);
                break;
            case "4":
                tBuildingWriter.draw(tBuildingWriter_4, loc_x_var, y);
                break;
            case "5":
                tBuildingWriter.draw(tBuildingWriter_5, loc_x_var, y);
                break;
            case "6":
                tBuildingWriter.draw(tBuildingWriter_6, loc_x_var, y);
                break;
            case "7":
                tBuildingWriter.draw(tBuildingWriter_7, loc_x_var, y);
                break;
            case "8":
                tBuildingWriter.draw(tBuildingWriter_8, loc_x_var, y);
                break;
            case "9":
                tBuildingWriter.draw(tBuildingWriter_9, loc_x_var, y);
                break;
            case "0":
                tBuildingWriter.draw(tBuildingWriter_0, loc_x_var, y);
                break;
            case "\\":
                tBuildingWriter.draw(tBuildingWriter_backslash, loc_x_var, y);
                break;
            case "/":
                tBuildingWriter.draw(tBuildingWriter_forwardslash, loc_x_var, y);
                break;
            case "<":
                tBuildingWriter.draw(tBuildingWriter_lessthan, loc_x_var, y);
                break;
            case ">":
                tBuildingWriter.draw(tBuildingWriter_greaterthan, loc_x_var, y);
                break;
            case "^":
                tBuildingWriter.draw(tBuildingWriter_caret, loc_x_var, y);
                break;
            case "#":
                tBuildingWriter.draw(tBuildingWriter_hash, loc_x_var, y);
                break;
            case "[":
                tBuildingWriter.draw(tBuildingWriter_opensquarebrackets, loc_x_var, y);
                break;
            case "]":
                tBuildingWriter.draw(tBuildingWriter_closesquarebrackets, loc_x_var, y);
                break;
            case ":":
                tBuildingWriter.draw(tBuildingWriter_colon, loc_x_var, y);
                break;
            case "!":
                tBuildingWriter.draw(tBuildingWriter_exclamation, loc_x_var, y);
                break;
            default://do nothing, character not recognised
                break;
            }
            loc_x_var = loc_x_var + 100;
        }
    };

    return tBuildingWriter;
})();
