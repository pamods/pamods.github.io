$(function () {

    function loadTemplate(element, url) {
        element.load(url, function () {
            ko.applyBindings(model, element.get(0));
        });
    }

    createFloatingFrame('tBuildingWriter_frame', 200, 60, {'offset': 'leftCenter', 'left': 0});
    loadTemplate($('#tBuildingWriter_frame_content'), 'coui://ui/mods/tBuildingWriter/live_game/tBuildingWriter.html');

});
