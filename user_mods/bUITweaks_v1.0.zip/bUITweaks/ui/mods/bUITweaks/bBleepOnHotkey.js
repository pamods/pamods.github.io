
//Audio taken from http://www.soundjay.com/button-sounds-1.html
var energyOn = new Audio('coui://ui/mods/bUITweaks/audio/highBleep.wav');
var energyOff = new Audio('coui://ui/mods/bUITweaks/audio/lowBleep.wav');
var continuousSound = new Audio('coui://ui/mods/bUITweaks/audio/continuous.wav');
var normalSound = new Audio('coui://ui/mods/bUITweaks/audio/normal.wav');

//Fire orders ( fire at will / return fire / hold fire )

//Move orders ( manuever / roam / hold position )

//Energy orders ( on / off )
model.toggleEnergyOrderIndex = function () {
	var index = (model.selectedEnergyOrderIndex() + 1) % model.energyOrders().length;
	var order = model.energyOrders()[index];
	if ( (order) && (model.allowEnergyOrders()) ) {
		if (index == 1) { energyOff.play(); }
		if (index == 0) { energyOn.play(); }
		engine.call('set_order_state', 'energy', order);
	}
	model.selectedEnergyOrderIndex(index);
}

//Factories build mode ( continuous / normal )
model.toggleBuildStanceOrderIndex = function () {
	var index = (model.selectedBuildStanceOrderIndex() + 1) % model.buildStanceOrders().length;
	var order = model.buildStanceOrders()[index];
	if ( (order) && (model.allowBuildStanceOrders()) ) {
		if (index == 1) { continuousSound.play(); }
		if (index == 0) { normalSound.play(); }
		engine.call('set_order_state', 'build', order);
	}
	model.selectedBuildStanceOrderIndex(index);
}