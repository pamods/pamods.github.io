/* MODEL
------------------------------------ */
model.planetPreview = ( function () {
    var pp = {};

    pp.bShowPlanetDetails = ko.observable(false);
    pp.bShowPlanetTable = ko.observable(false);

    pp.planetNameString = function (value) {
        return value || "Unnamed Planet";
    };
    pp.planetAreaString = function (value) {
        var num = 4 * value * value * Math.PI;
        num = num / 1000000;
        return num.toFixed(2);
    };
//    pp.sizeString = function (index) { //Don't need to update - Not needed
//        var sizeVar = model.loadedSystem().planets[index].planet.radius;
//        return model.planetSizeClass(sizeVar);
//    };
//    pp.areaString = function (index) { //Don't need to update - Not needed
//        var radiusVar = model.loadedSystem().planets[index].planet.radius,
//        num = 4 * radiusVar * radiusVar * Math.PI;
//        num = num / 1000000; //from m� to km�
//        return num.toFixed(2);
//    };
//    pp.seedString = function (index) { //Don't need to update - Not needed
//        var seedVar = model.loadedSystem().planets[index].planet.seed;
//        return seedVar;
//    };
//    pp.radiusString = function (index) { //Don't need to update - Not needed
//        var radiusVar = model.loadedSystem().planets[index].planet.radius;
//        return radiusVar;
//    };
    pp.biomeImageSource = function (index) {
        var biomeVar = model.loadedSystem().planets[index].planet.biome,
        tempVar = model.loadedSystem().planets[index].planet.temperature,
        ice = biomeVar === 'earth' && tempVar <= 10, //Temps of -0.5 are no longer possible.
        s = ice ? 'ice' : biomeVar || 'unknown';

        return '../shared/img/' + s + '.png';
    };
    pp.biomeImageSize = function (value) {
        var px = Math.max(Math.min(Math.floor(value/20),56),8);
        return px + "em";
    };

    return pp;
})();

$((function () { // BEGIN ====MODIFY DOM====
var $lobbyDivPlanetTbl = $( ".div_planet_selector_tbl" ),
$lobbySpanSystemSummary = $( ".div_planet_selector_cont" ).children( "div:first" ),
$lobbyDivPlanetCont = $( ".div_planet_selector_cont" ),
$lobbySiblingsSystemCont = $( ".div_system_cont" ).siblings();
//var $newDetailToggle = $( '<div style="margin: 10px;">\
//<div><span class="lbl_planet_type" data-bind="text: systemName"></span></div><span class="input_label">PLANETS: </span><span class="input_field_static" data-bind="text: numPlanets"></span>\
//<span style="font-family:DIN Medium;float:right;">\
//</span></div>' );
var $newDetailToggle = $( '<br><span style="font-family:DIN Medium;">\
<a class="text_link_btn input_label" data-bind="click: function () { model.planetPreview.bShowPlanetDetails(true); },\
visible: model.planetPreview.bShowPlanetDetails() === false,click_sound:' + "'default', rollover_sound: 'default'" + '">Show Details</a>\
<a class="text_link_btn input_label" data-bind="click: function () { model.planetPreview.bShowPlanetDetails(false); },\
visible: model.planetPreview.bShowPlanetDetails() === true,click_sound:' + "'default', rollover_sound: 'default'" + '">Hide Details</a>\
</span>' );
//var $newPlanetTable = $( '<table class="div_planet_selector_tbl">\
//<tbody><tr><td>\
//<img data-bind="attr: { src: model.imageSourceForPlanet(primaryPlanet()), height: model.planetPreview.biomeImageSize(primaryPlanet().radius), width: model.planetPreview.biomeImageSize(primaryPlanet().radius) }" />\
//</td><td>\
//<div class="input_label"><loc data-i18n="lobby:starting_planet.message" desc="">STARTING PLANET:</loc> </div>\
//<div class="input_field_static" style="text-transform: uppercase;" data-bind="text: model.planetPreview.planetNameString(primaryPlanet().name)"></div>\
//<div class="input_field_static">\
//<span>SIZE: </span><span style="text-transform:uppercase;" data-bind="text: model.planetSizeClass(primaryPlanet().radius)"></span>\
//<br><span>SURF. AREA: </span><span style="text-transform:uppercase;" data-bind="text: model.planetPreview.planetAreaString(primaryPlanet().radius)"></span><span>km&sup2</span>\
//</div></td></tr></tbody></table>' );
var $newSystemTable = $( '<div style="max-height: 355px;overflow:auto;"><table class="div_planet_selector_tbl">\
<tbody data-bind="foreach: loadedSystem().planets">\
<tr><td style="width:56px;min-height:27px;text-align:center;vertical-align:middle;">\
<img data-bind="attr: { src: model.planetPreview.biomeImageSource($index()), height: model.planetPreview.biomeImageSize($data.planet.radius), width: model.planetPreview.biomeImageSize($data.planet.radius) }" />\
</td></tr><tr><td>\
<div class="input_label" data-bind="visible: $index() === 0"><loc data-i18n="lobby:starting_planet.message" desc="">STARTING PLANET:</loc> </div>\
<div class="input_field_static" style="text-transform:uppercase;" data-bind="text: model.planetPreview.planetNameString(name)"></div>\
<div class="input_field_static">\
<span style="text-transform:uppercase;"><loc data-i18n="lobby:scale.message" desc="">SCALE</loc> </span><span style="text-transform:uppercase;" data-bind="text: model.planetSizeClass($data.planet.radius)"></span>\
<br><span style="text-transform:uppercase;">Surf. Area: </span><span style="text-transform:uppercase;" data-bind="text: model.planetPreview.planetAreaString($data.planet.radius)"></span><span>km&sup2</span>\
</div></td></tr>\
<tr data-bind="visible: model.planetPreview.bShowPlanetDetails()"><td>\
<div class="input_field_static">\
<span>Radius: </span><span style="text-transform:uppercase;" data-bind="text: $data.planet.radius"></span><span>m</span>\
<br><span>Seed: </span><span style="text-transform:uppercase;" data-bind="text: $data.planet.seed"></span>\
<br><span>Biome Scale: </span><span style="text-transform:uppercase;" data-bind="text: $data.planet.biomeScale"></span>\
<br><span>Height Range: </span><span style="text-transform:uppercase;" data-bind="text: $data.planet.heightRange"></span>\
<br><span>Water Height: </span><span style="text-transform:uppercase;" data-bind="text: $data.planet.waterHeight"></span>\
<br><span>Temperature: </span><span style="text-transform:uppercase;" data-bind="text: $data.planet.temperature"></span>\
</div></td></tr></tbody></table></div>' );

$($lobbySiblingsSystemCont).unwrap().wrap("<td></td>");
$($lobbyDivPlanetCont).attr("style","width:144px;"),$($lobbySpanSystemSummary).append($newDetailToggle),$($lobbyDivPlanetTbl).replaceWith($newSystemTable);
$( ".div_system_cont" ).attr("style","margin-bottom:0px;");
})()); //END ====MODIFY DOM====