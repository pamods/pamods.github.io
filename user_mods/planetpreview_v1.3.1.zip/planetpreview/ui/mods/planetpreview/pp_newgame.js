/* MODEL
------------------------------------ */

model.planetPreview = (function () {
    var pp = {};

    pp.bShowPlanetDetails = ko.observable(false);
    pp.planetNameString = function (value) {
        return value || "Unnamed Planet"; //Name your planets! Needs localized string.
    };
    pp.sizeString = function (index) {
        var sizeVar = model.loadedSystem().planets[index].planet.radius;
        return model.planetSizeClass(sizeVar);
    };
    pp.areaString = function (index) {
        var radiusVar = model.loadedSystem().planets[index].planet.radius,
        num = 4 * radiusVar * radiusVar * Math.PI;
        num = num / 1000000; //from m� to km�
        return num.toFixed(2);
    };
    pp.seedString = function (index) {
        var seedVar = model.loadedSystem().planets[index].planet.seed;
        return seedVar;
    };
    pp.radiusString = function (index) {
        var radiusVar = model.loadedSystem().planets[index].planet.radius;
        return radiusVar;
    };
    //pp.biomeString = function (index) {
        //var biomeVar = model.loadedSystem().planets[index].planet.biome;
        //return biomeVar;
    //};
    pp.biomeImageSource = function (index) {
        var biomeVar = model.loadedSystem().planets[index].planet.biome,
        tempVar = model.loadedSystem().planets[index].planet.temperature,
        ice = biomeVar === 'earth' && tempVar <= 10, //Temps of -0.5 are no longer possible.
        s = ice ? 'ice' : biomeVar || 'unknown';

        return '../shared/img/' + s + '.png';
    };
    pp.biomeImageSize = function (index) {
        var radiusVar = model.loadedSystem().planets[index].planet.radius,
        pixels = Math.floor(Math.min(56,Math.max(8,(radiusVar/20)))); //Fixed 14/02/25
        return pixels.toString() + "px";
    };
    pp.getRandomSeed = function (inum) {
        var syst = model.loadedSystem(),
        min = 0, max = 32767, //Default from 0 to 32767.
        planetarray = model.loadedSystem().planets, randomNum = Math.floor(Math.random() * (max - min + 1) + min);

        planetarray[inum].planet.seed = randomNum;
        syst.planets = planetarray;
        model.loadedSystem(syst);
    };
    pp.getRandomRadius = function (inum) {
        var syst = model.loadedSystem(),
        min = 100, max = 1400, //Default from 100 to 1400.
        planetarray = model.loadedSystem().planets, randomNum = Math.floor(Math.random() * (max - min + 1) + min);

        planetarray[inum].planet.radius = randomNum;
        syst.planets = planetarray;
        model.loadedSystem(syst);
    };
    pp.getRandomBiome = function (inum) {
        var syst = model.loadedSystem(),
        planetarray = model.loadedSystem().planets,
        list = ko.observableArray(model.biomes().slice(0)); //Support all biomes.

        if (model.biomes().indexOf(planetarray[inum].planet.biome) === -1) { //If unknown or invalid biome, select any biome.
            planetarray[inum].planet.biome = model.biomes()[Math.floor(Math.random() * (model.biomes().length))];
        }
        else { //Don't select a biome we already have.
            list.remove(planetarray[inum].planet.biome);
            planetarray[inum].planet.biome = list()[Math.floor(Math.random() * (list().length))];
        }
        syst.planets = planetarray;
        model.loadedSystem(syst);
    };

    return pp;
})();

/*model.pp_planetDiameterString = function (value) {
    return (2 * value);
};

model.pp_planetBiomeString = function (value) {
    return "Type: " + value;
    }

model.pp_planetRadiusString = function (value) {
    return "Radius: " + value + "m";
    }

model.pp_planetSeedString = function (value) {
    return "Seed # " + value;
    }

model.pp_planetBiomeScaleString = function (value) {
    return "Biome Scale: " + value;
    }

model.pp_planetHeightRangeString = function (value) {
    return "Height Range: " + value;
    }

model.pp_planetWaterHeightString = function (value) {
    return "Water Height: " + value;
    }

model.pp_planetTemperatureString = function (value) {
    return "Temperature: " + value;
    }*/

$((function () { // BEGIN ====MODIFY DOM====
var $newgameSpanSystemSize = $(".div_planet_selector_cont").children("div:first").children("div:last"), $newgameTablePlanetSelector = $(".div_planet_selector_tbl");
var $detailToggleSpan = $('<span class="input_label"><loc data-i18n="new_game:planets.message" desc="">PLANETS:</loc> </span><span class="input_field_static" data-bind="text: loadedSystemSize()"></span>\
<span style="font-family:DIN Medium;float:right;">\
<a class="text_link_btn input_label" data-bind="click: function () { model.planetPreview.bShowPlanetDetails(!model.planetPreview.bShowPlanetDetails()); },\
visible: model.planetPreview.bShowPlanetDetails() === false,click_sound:' + "'default', rollover_sound: 'default'" + '">Show Details</a>\
<a class="text_link_btn input_label" data-bind="click: function () { model.planetPreview.bShowPlanetDetails(!model.planetPreview.bShowPlanetDetails()); },\
visible: model.planetPreview.bShowPlanetDetails() === true,click_sound:' + "'default', rollover_sound: 'default'" + '">Hide Details</a></span>');
var $newPlanetTable = $('<table class="div_planet_selector_tbl">\
<tbody data-bind="foreach: loadedSystem().planets">\
<tr><td style="width:56px;text-align:center;vertical-align:middle;">\
<img data-bind="attr: { src: model.planetPreview.biomeImageSource($index()), height: model.planetPreview.biomeImageSize($index()), width: model.planetPreview.biomeImageSize($index()) }" />\
</td><td>\
<div class="input_label" data-bind="visible: $index() === 0"><loc data-i18n="new_game:starting_planet.message" desc="">STARTING PLANET:</loc> </div>\
<div class="input_field_static" style="text-transform:uppercase;" data-bind="text: model.planetPreview.planetNameString(name)"></div>\
<div data-bind="visible: $index() > 0" style="line-height:0.9em;">\
<a href="#" class="text_link_btn text_link_btn_small" data-bind="click: function () { model.setPrimaryPlanet($index()); },click_sound:' + "'default',rollover_sound: 'default'" + '">\
<loc data-i18n="new_game:set_as_starting_planet.message" desc="">Set As Starting Planet</loc></a>\
</div>\
<div class="input_field_static">\
<span>Size: </span><span style="text-transform:uppercase;" data-bind="text: model.planetPreview.sizeString($index())"></span>\
<br><span>Surf. Area: </span><span style="text-transform:uppercase;" data-bind="text: model.planetPreview.areaString($index())"></span><span>km&sup2</span>\
</div></td></tr>\
<tr data-bind="visible: model.planetPreview.bShowPlanetDetails()"><td style="font-size:0.75em">\
<a class="text_link_btn text_link_btn_small" data-bind="click: function () { model.planetPreview.getRandomSeed($index()); },click_sound:' + "'default',rollover_sound: 'default'" + '">New Seed</a>\
<br><a class="text_link_btn text_link_btn_small" data-bind="click: function () { model.planetPreview.getRandomRadius($index()); },click_sound:' + "'default',rollover_sound: 'default'" + '">New Radius</a>\
<br><a class="text_link_btn text_link_btn_small" data-bind="click: function () { model.planetPreview.getRandomBiome($index()); },click_sound:' + "'default',rollover_sound: 'default'" + '">New Biome</a>\
</td><td>\
<div class="input_field_static" style="margin-bottom:1.0em;" >\
<span>Radius: </span><span style="text-transform:uppercase;" data-bind="text: model.planetPreview.radiusString($index())"></span><span>m</span>\
<br><span>Seed: </span><span style="text-transform:uppercase;" data-bind="text: model.planetPreview.seedString($index())"></span>\
<br><span>Biome Scale: </span><span style="text-transform:uppercase;" data-bind="text: $data.planet.biomeScale"></span>\
<br><span>Height Range: </span><span style="text-transform:uppercase;" data-bind="text: $data.planet.heightRange"></span>\
<br><span>Water Height: </span><span style="text-transform:uppercase;" data-bind="text: $data.planet.waterHeight"></span>\
<br><span>Temperature: </span><span style="text-transform:uppercase;" data-bind="text: $data.planet.temperature"></span>\
<br></div></td></tr></tbody></table>');
$($newgameSpanSystemSize).replaceWith($detailToggleSpan);
$($newgameTablePlanetSelector).replaceWith($newPlanetTable);
})()); //END ====MODIFY DOM====