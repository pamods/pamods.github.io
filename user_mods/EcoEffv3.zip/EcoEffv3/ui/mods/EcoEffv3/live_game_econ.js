﻿(function() {
	var notEnoughEnergyBorder = 0.9;
	var notEnoughMetalBorder = 0.6;	
	var blinkSpeed = 500; //ms

	//COLOR DEFINITION
	var Green = '#1EFF1E';
	var Yellow = '#FFFF1E';
	var Orange = '#FFA51E';
	var Red = '#FF1E1E';
	var Fushia = '#FF1EFF';
	
	
	// MODIF - Satan Petit Cul 
	//-------------------------------------------------------------------------
	
	
	//--------------- Calcul - Efficiency ----------------
	model.energyEff = ko.computed(function() {
		return model.energyGain() / model.energyLoss() ;
	});	
	model.metalEff = ko.computed(function() {
		return model.metalGain() / model.metalLoss();
	});
	
	model.overallEff = ko.computed(function() {
	
		var mTemp = model.metalEff()
		var eTemp = model.energyEff()
		
		if (model.currentMetal()>2) {
			mTemp = 1;
		}
		if (model.currentEnergy() > 2) {
			eTemp = 1;
		}
		if (Math.min(eTemp, mTemp)>1){
			return 1;
		} else {
			return Math.min(eTemp, mTemp);
		}		
	});
	//-----------------------------------------------------
	
	//--------------- Calcul - ratio e/m ----------------
	model.ratioEM = ko.computed(function() {
		return model.energyGain() / model.metalGain() ;
	});	


	//--------------- Definition - Conditions -------------
	// ___Storage State____________________________________
	// ______full______
	model.metalStorageFull = ko.computed(function() {
		return model.currentMetal() >= model.maxMetal();
	});
	model.energyStorageFull = ko.computed(function() {
		return model.currentEnergy() >= model.maxEnergy();
	});
	// ______empty_____
	model.metalStorageEmpty = ko.computed(function() {
		return model.currentMetal() === 0;
	});
	model.energyStorageEmpty = ko.computed(function() {
		return model.currentEnergy() === 0;
	});
	// ______mid_______
	model.metalStorageMid = ko.computed(function() {
		return !model.metalStorageFull() && !model.metalStorageEmpty();
	});
	model.energyStorageMid = ko.computed(function() {
		return !model.energyStorageFull() && !model.energyStorageEmpty();
	});
	// ___Metal efficiency_________________________________
	model.metalEff_90plus = ko.computed(function() {
		return model.metalEff() >= 0.90;
	});
	model.metalEff_90 = ko.computed(function() {
		return model.metalEff() < 0.90 ;
	});
	model.metalEff_75 = ko.computed(function() {
		return model.metalEff() < 0.75 ;
	});
	model.metalEff_66 = ko.computed(function() {
		return model.metalEff() < 0.66;
	});
	// ___Energy efficiency________________________________
	model.energyEff_150plus = ko.computed(function() {
		return model.energyEff() >= 1.50;
	});
	model.energyEff_150 = ko.computed(function() {
		return model.energyEff() < 1.50;
	});
	model.energyEff_110 = ko.computed(function() {
		return model.energyEff() < 1.10;
	});
	model.energyEff_100 = ko.computed(function() {
		return model.energyEff() < 1;
	});
	model.energyEff_90 = ko.computed(function() {
		return model.energyEff() < 0.90;
	});
	// ___Metal vs Energy________________________________
	model.metalVsEnergy = ko.computed(function() {
		return model.energyEff() < model.metalEff();
	});
	
	model.ratioEM_125 = ko.computed(function() {
		return model.ratioEM() > 125;
	});
	//-----------------------------------------------------
        
	// **** METAL ****
	
	model.metalGreen = ko.computed(function() {
		return model.metalStorageMid() || model.metalStorageEmpty() && model.metalEff_90plus();
	});
	
	model.metalRed = ko.computed(function() {
		return model.metalStorageEmpty() && model.metalEff_66();
	});

	model.metalOrange = ko.computed(function() {
		return model.metalStorageEmpty() && model.metalEff_75() && !model.metalEff_66();
	});

	model.metalYellow = ko.computed(function() {
		return model.metalStorageEmpty() && model.metalEff_90() && !model.metalEff_75();
	});
	
	model.metalFushia = ko.computed(function() {
		return model.metalStorageFull();
	});
	
	// **** ENERGY ****

	model.energyGreen = ko.computed(function() {
		return !model.energyStorageEmpty() && !model.ratioEM_125();
	});
	
	model.energyRed = ko.computed(function() {
		return model.energyStorageEmpty() && !model.ratioEM_125();
	});
	
	model.energyFushia = ko.computed(function() {
		return model.ratioEM_125();
	});		
	
	model.overallFushia = ko.computed(function() {
		return model.metalFushia() && model.energyFushia();
	});
	
	model.overallRed = ko.computed(function() {
		return model.metalRed() || model.energyRed() ;
	});
	
	model.overallGreen = ko.computed(function() {
		return  !(model.metalFushia() && model.energyFushia()) && !(model.metalRed() || model.energyRed()) ;
	});
	
	//-------------------------------------------------------------------------
	// ___COLOR________________________________
	
	model.metalColor = ko.computed(function() {
		if (model.metalGreen()) {
			return Green;
		}
		if (model.metalRed()) {
			return Red;
		} 
		if (model.metalOrange()) {
			return Orange;
		} 
		if (model.metalYellow()) {
			return Yellow;
		} 
		if (model.metalFushia()) {
			return Fushia;
		} 
	});
	
	model.energyColor = ko.computed(function() {
		if (model.energyGreen()) {
			return Green;
		}
		if (model.energyRed()) {
			return Red;
		} 
		if (model.energyFushia()) {
			return Fushia;
		} 
	});
	
	model.overallColor = ko.computed(function() {
		if (model.metalEff() < model.energyEff()) {
			return model.metalColor();
		} else {		
			return model.energyColor();
		} 		 
	});
	
	
	//-------------------------------------------------------------------------
	model.isBlink = ko.observable(false);
	var toggleBlink = function() {
		window.setTimeout(function() {
			model.isBlink(!model.isBlink());
			toggleBlink();
		}, blinkSpeed);
	};
	toggleBlink();

	
	// bindings for the display stuff--------------------------------------------
	
	model.energyNetK = ko.computed(function() {
		return model.energyNet() / 1000;
	});
	model.energyGainK = ko.computed(function() {
		return model.energyGain() / 1000;
	});
	model.energyLossK = ko.computed(function() {
		return model.energyLoss() / 1000;
	});
	model.energyNetKStr = ko.computed(function() {
		var positive = model.energyNetK() > 0;
		var a = positive ? "+" : "";
		return '(' + a + model.energyNetK().toFixed(1) + ")";
	});
	model.energyGainKStr = ko.computed(function() {
		return "" + model.energyGainK().toFixed(1)+"";
	});
	model.energyLossKStr = ko.computed(function() {
		return model.energyLossK().toFixed(1)+" k";
	});
	model.metalGainStr = ko.computed(function() {
		return "" + model.metalGain();
	});
	
	model.metalNetStr = ko.computed(function() {
		var Temp = model.metalGain() - model.metalLoss()
		return '(' + Temp + ')';
	});
	
	var possibleInf = function(n) {
		if (!isFinite(n)) {
			return "∞   ";
		} else {
			return n;
		}
	}
	
	
	model.energyMaxK = ko.computed(function() {
		return model.maxEnergy()/1000 ;
	});
	model.energyMaxKStr = ko.computed(function() {
		return model.energyMaxK() + ' k';
	});
	
	model.metalMaxK = ko.computed(function() {
		return model.maxMetal() / 1000;
	});
	model.metalMaxKStr = ko.computed(function() {
		return model.metalMaxK() + ' k';
	});
	
	model.roundOverallEff = ko.computed(function() {		
		return '' + possibleInf(Math.floor(model.overallEff() * 100)); 
	});
	model.roundMetalEff = ko.computed(function() {		
		return '' + possibleInf((Math.floor(100 * model.metalEff()))) ;		
	});
	model.roundEnergyEff = ko.computed(function() {		
			return '' + possibleInf((Math.floor(100 * model.energyEff()))) ;		
	});
	model.roundRatioEM = ko.computed(function() {		
			return '(' + possibleInf(Math.floor(model.ratioEM())) + ')';		
	});
	
	$('.div_status_bar').empty().load("coui://ui/mods/EcoEffv3/live_game_econ.html", function() {
		ko.applyBindings(model, $('#ecoeff2container').get(0));
	});
}());
