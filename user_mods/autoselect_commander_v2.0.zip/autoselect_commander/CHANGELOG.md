# Autoselect Commander Changelog

## 2.0

- Rewrite to work in shared-army games; remove checkbox.
