//initialSettingValue("cBBB_Trans", 0);
//initialSettingValue("cBBB_Size", 65);

//$('head').append( "<link id='cBBCSS' href='' rel='stylesheet' type='text/css'>" );

//var CBB = decode(localStorage.settings).cBBB_Trans;
//console.log("cBBB: Loaded, cBBB_Trans = " + CBB);

//var CBB_Size = decode(localStorage.settings).cBBB_Size;
//console.log("CBB_Size= " + CBB_Size + "%");

//var c_Size_w = CBB_Size * 0.01 * 62;
//var c_Size_h = CBB_Size * 0.01 * 56;

/*

(function () {
$('.div_build_item').css('height', c_Size_h).css('width', c_Size_w);
})();

if (CBB === "Transparency On")
    {
    $(".div_build_bar_midspan > div").css('margin', '0px 0px 0px 0px').css('background-color', 'rgba(13, 13, 13, .7)');
    loadCSS('coui://ui/alpha/live_game/corBetterBuildBar.css')
    }
else if (CBB === "Transparency Off")
    {
    $(".div_build_bar_midspan > div").css('margin', '0px 0px 0px 0px').css('background-color', 'rgba(13, 13, 13, 1)');
    loadCSS('coui://ui/alpha/live_game/corBetterBuildBar.css')
    }
else if (CBB === "Icons Only")
    {
    $(".div_build_bar_midspan > div").css('margin', '0px 0px 0px 0px').css('background', 'none');
    loadCSS('coui://ui/alpha/live_game/corBetterBuildBarMini.css');
    }
else if (CBB === "No Borders")
    {
    $(".div_build_bar_midspan > div").css('margin', '0px 0px 0px 0px').css('background-color', 'rgba(13, 13, 13, .7)');
    loadCSS('coui://ui/alpha/live_game/corBetterBuildBarMiniWithBG.css');
    }
else if (CBB === "Trans Borders")
    {
    $(".div_build_bar_midspan > div").css('margin', '0px 0px 0px 0px').css('background-color', 'rgba(13, 13, 13, .7)');
    loadCSS('coui://ui/alpha/live_game/corBetterBuildBarWithTransBorder.css');
    }
    
*/

$(".div_build_item").css('height', '42px').css('width', '46px').css('border-left', '1px solid rgba(255,255,255,.05)').css('border-top', '1px solid rgba(255,255,255,.05)');
$("img.img_build_unit").css('height', '36px').css('width', '36px');
$(".div_build_bar_cont").css('width', '277').css('margin', '0px 0px 0px 0px').css('padding', '0px 0px 0px 0px').css('border-left', '0px').css('border-top', '0px').css('display', 'block');
$(".tab_grp_body").css('margin', '22px 0px 0px 0px');
$(".div_build_bar_tab_cont").css('margin', '3px -27px -15px -28px');
































