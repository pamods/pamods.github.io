(function () {
    model.addSetting_DropDown("Transparency: ", "cBBB_Trans", "UI", ["Transparency On", "Transparency Off", "Icons Only", "No Borders", "Trans Borders"], 0, "Better Build Bar");
    model.addSetting_Slider("Icon Size:", "cBBB_Size", "UI", 50, 100, 65, "Better Build Bar");
})();