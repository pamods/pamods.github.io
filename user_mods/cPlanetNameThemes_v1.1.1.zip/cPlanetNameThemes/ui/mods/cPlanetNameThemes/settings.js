// Uses raevn's Settings Manager
// https://forums.uberent.com/threads/rel-settings-manager-v1-4-0-58772.54588/

initialSettingValue("cPlanetNameThemes_theme", "Star Wars");
var themeNames = cPlanetNameThemes.getThemeNames()
model.addSetting_DropDown('Planet Naming Theme','cPlanetNameThemes_theme','UI',themeNames,1);
