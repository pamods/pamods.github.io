// Keep a reference to Uber's version of this function.
var original_loadRandomSystem = model.loadRandomSystem;

// Override Uber's random system generator.
// This WILL be compatible with any other mods that override the random system generator,
// but only if the other mod loads first.
model.loadRandomSystem = function () {
	// Run Uber's random system generator
	original_loadRandomSystem();

	var system = model.loadedSystem();

	// Get a new name for every planet in the system
	for(var i=0; i<system.planets.length; i++) {
		var planet = system.planets[i].planet;
		var planetName = cPlanetNameThemes.getPlanetName(planet);
     	system.planets[i].name = planetName;
	}

	// Uber's function that makes an engine call to send the new system to the server.
	model.loadedSystem(system);
}

