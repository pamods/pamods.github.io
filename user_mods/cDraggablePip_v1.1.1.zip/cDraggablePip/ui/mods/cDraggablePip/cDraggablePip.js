	model.cameraAnchors = ko.observableArray([ko.observable(false), ko.observable(false), ko.observable(false), ko.observable(false), ko.observable(false), ko.observable(false), ko.observable(false), ko.observable(false), ko.observable(false)]);

	$(".pip").wrap("<div id=\"draggable_pip\" data-bind=\"visible: showPips\"><div id=\"draggable_pip_content\"><div id=\"draggable_pip_content_inner\"></div><div id=\"draggable_pip_content_controls\"></div></div></div>");
	$("#draggable_pip_content_controls").append("<ul class=\"draggable_pip_controls_list\"><li class=\"draggable_pip_button draggable_pip_button_toggle\"><li class=\"draggable_pip_button draggable_pip_button_hide\"></li></ul>");
	$("#draggable_pip_content_controls ul").prepend("<li onclick=\"javascript:recall_pip_anchor(1);\" data-bind=\"attr: { \'class\': \'draggable_pip_button draggable_pip_button_anchor \' + anchor_button_active(1) }\">1</li><li onclick=\"javascript:recall_pip_anchor(2);\" data-bind=\"attr: { \'class\': \'draggable_pip_button draggable_pip_button_anchor \' + anchor_button_active(2) }\">2</li><li onclick=\"javascript:recall_pip_anchor(3);\" data-bind=\"attr: { \'class\': \'draggable_pip_button draggable_pip_button_anchor \' + anchor_button_active(3) }\">3</li><li onclick=\"javascript:recall_pip_anchor(4);\" data-bind=\"attr: { \'class\': \'draggable_pip_button draggable_pip_button_anchor \' + anchor_button_active(4) }\">4</li><li onclick=\"javascript:recall_pip_anchor(5);\" data-bind=\"attr: { \'class\': \'draggable_pip_button draggable_pip_button_anchor \' + anchor_button_active(5) }\">5</li><li onclick=\"javascript:recall_pip_anchor(6);\" data-bind=\"attr: { \'class\': \'draggable_pip_button draggable_pip_button_anchor \' + anchor_button_active(6) }\">6</li><li onclick=\"javascript:recall_pip_anchor(7);\" data-bind=\"attr: { \'class\': \'draggable_pip_button draggable_pip_button_anchor \' + anchor_button_active(7) }\">7</li><li onclick=\"javascript:recall_pip_anchor(8);\" data-bind=\"attr: { \'class\': \'draggable_pip_button draggable_pip_button_anchor \' + anchor_button_active(8) }\">8</li>");
	ko.applyBindings(model);

(function() {

	createFloatingFrame("draggable_pip", 0, 0, {
		"rememberPosition" : false
	});

	var _left = $("body").width() - 354 - 10;
	var _top =  $("body").height() - 10 - 45;

	$("#draggable_pip").offset({
		"left": _left,
		"top": _top
	});

	$(".draggable_pip_button_hide").click(function() {
		model.showPips(false);
	});

	$(".draggable_pip_button_toggle").click(function() {
		model.swapPips();
	});

	var endAnimation;

	$("#draggable_pip").mousedown(function() {
		endAnimation = model.pips[0].beginAnimation();
	});

	$("#draggable_pip").mouseup(function() {
		endAnimation();
	});

	$("#draggable_pip_content_controls").mouseenter(function() {
		model.holodeck.focus();
	});
})();

var old_api_camera_captureAnchor = api.camera.captureAnchor;

api.camera.captureAnchor = function (anchorIndex) {
	console.log(anchorIndex);
	model.cameraAnchors()[anchorIndex](true);
	old_api_camera_captureAnchor(anchorIndex);
}

function anchor_button_active(anchorIndex) {
	return model.cameraAnchors()[anchorIndex]() ? "draggable_pip_button_anchor_active" : "";
};

function recall_pip_anchor(pipAnchor) {
	model.swapPips();
	api.camera.recallAnchor(pipAnchor);
	model.swapPips();
}