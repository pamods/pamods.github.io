cPlanetNameThemes.themes["Stargate"] = {
	earth: new Array(
		"Amra",
		"Argos",
		"Avnil",
		"Cartago",
		"Cimmeria",
		"Dar Eshkalon",
		"Earth",
		"Galar",
		"Hanka",
		"Hebridan",
		"Juna",
		"Langara",
		"Rillaan",
		"Simarka",
		"Tegalus",
		"Volia",
		"Vyus"
	),

	ice: new Array(
		"Ghanaz",
		"KS7-535",
		"Madrona"
	),

	desert: new Array(
		"Abydos",
		"Dakara",
		"Eskal",
		"Kallana",
		"P34-353J",
		"P5X-112",
		"Prakiti",
		"Velona",
		"Vorash"
	),

	moon: new Array(
		"Adara II",
		"P5C-353"
	),

	tropical: new Array(
		"Chulak",
		"Hak'tyl",
		"K'tau",
		"Nasya",
		"Orban",
		"P3X-797",
		"P9C-882",
		"Pangar",
		"Tollana"
	),

	lava: new Array(
		"Lucia",
		"Netu",
		"Praxyon",
		"Proclarush",
		"Tagrea"
	),

	metal: new Array(
		"Atlantis",
		"Destiny"
	)
}