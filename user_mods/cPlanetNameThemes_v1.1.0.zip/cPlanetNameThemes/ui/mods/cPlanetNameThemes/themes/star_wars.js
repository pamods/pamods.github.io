// Can't wait for gas giants so we can add in Yavin and Bespin!

cPlanetNameThemes.themes["Star Wars"] = {
	earth: new Array(
		"Alderaan",
		"Ansion",
		"Boz Pity",
		"Corellia",
		"Taanab"
	),

	ice: new Array(
		"Hoth",
		"Mygeeto"
	),

	desert: new Array(
		"Dantooine",
		"Tatooine",
		"Utapau"
	),

	moon: new Array(
		"Iego",
		"Kessel",
		"Nar Shaddaa",
		"Ord Mantell",
		"Polis Massa",
		"Subterrel"
	),

	tropical: new Array(
		"Bogden",
		"Cato Neimoidia",
		"Dagobah",
		"Endor",
		"Felucia",
		"Kamino",
		"Kashyyyk",
		"Malastare",
		"Naboo",
		"Yavin IV"
	),

	lava: new Array(
		"Anoat",
		"Geonosis",
		"Mustafar",
		"Saleucami",
		"Sullust",
		"Tund"
	),

	metal: new Array(
		"Coruscant",
		"Death Star",
		"Death Star II"
	)
}