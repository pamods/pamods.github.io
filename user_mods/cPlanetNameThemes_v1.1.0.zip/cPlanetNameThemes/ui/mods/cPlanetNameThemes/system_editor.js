model.new_planet_name = function() {
	var planet = model.planetSpec().planet;
	var planetName = cPlanetNameThemes.getPlanetName(planet);

	model.planetName(planetName);
	model.system().planets[model.selectedPlanetIndex()].name = planetName;
}

