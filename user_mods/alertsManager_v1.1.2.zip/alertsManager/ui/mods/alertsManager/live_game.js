(function() {
	var alertsManagerDisplayFilterSettings = alertsManager.makeEmptyFilterSettings();
	alertsManagerDisplayFilterSettings.selectedTypes[alertsManager.WATCH_TYPES.CREATED] = alertsManagerSettings.getShowCreatedAlerts();
	alertsManagerDisplayFilterSettings.includedUnits[alertsManager.WATCH_TYPES.CREATED] = alertsManagerSettings.getIncludedUnitSpecAlertsCreated();
	alertsManagerDisplayFilterSettings.excludedUnits[alertsManager.WATCH_TYPES.CREATED] = alertsManagerSettings.getExcludedUnitSpecAlertsCreated();

	alertsManagerDisplayFilterSettings.selectedTypes[alertsManager.WATCH_TYPES.DESTROYED] = alertsManagerSettings.getShowDestroyedAlerts();
	alertsManagerDisplayFilterSettings.includedUnits[alertsManager.WATCH_TYPES.DESTROYED] = alertsManagerSettings.getIncludedUnitSpecAlertsDestroyed();
	alertsManagerDisplayFilterSettings.excludedUnits[alertsManager.WATCH_TYPES.DESTROYED] = alertsManagerSettings.getExcludedUnitSpecAlertsDestroyed();

	// changing this is not supported, if you want to try you need to read up on the alertsManager.js and modify it a (tiny) bit
	alertsManagerDisplayFilterSettings.selectedTypes[alertsManager.WATCH_TYPES.DAMAGED] = ['Commander'];
	alertsManager.replaceDisplayFilter(alertsManagerDisplayFilterSettings);

	//$(".div_alert_panel_cont").css("z-index", 1000);
	$(".div_unit_alert").each(function(index, element) {
		var oldBind = $(element).data("bind");
		var regex = /click.*,/m;
		var newBind = oldBind.replace(regex, "click: function (data, event) { $parent.acknowledge($data.id, event) }, event: {mouseover: function (data, event) { $parent.acknowledge($data.id, event) }, mouseout: function (data, event) { $parent.acknowledge($data.id, event) }, contextmenu: function (data, event) { $parent.acknowledge($data.id, event) }},");
		$(element).attr("data-bind", newBind);
	});

	var jumpTarget = undefined;

	var oldTime = handlers.time;
	handlers.time = function(payload) {
		oldTime(payload);
		if (jumpTarget) {
			var nowMs = new Date().getTime();
			var diff = nowMs - jumpTarget;
			var diffS = diff / 1000;
			var target = payload.end_time - diffS - 0.5;
			api.time.set(Number(target));
			jumpTarget = undefined;
		}
	};

	model.switchPips = function(pip_one, pip_two) {
		model.pips[pip_one].swapCamera(pip_two);
    };

	var magicAnchor = 1337 * 3;
	var magicPipAnchor = 1337 * 3 + 1;
	var inChronoView = false;
	var hoveringAlert;
	var pipShowing = "uninitialized"; // Allows values for {"show", "hide", "uninitialized"}

	var oldAck = model.unitAlertModel.acknowledge;
	model.unitAlertModel.acknowledge = function(data, event) {
		if (event.type === "contextmenu") { // right click
			if (event.ctrlKey) {
				model.unitAlertModel.close(data);
			}
		} else if (event.type === "mouseover") { // hover
			if(pipShowing === "uninitialized" || pipShowing === "show") {
				pipShowing = model.showPips() ? "show" : "hide";
			}

			var alert = model.unitAlertModel.map[data];

			var target = {
				location: alert.location,
				planet_id: alert.planet_id
			};

			if(pipShowing === "hide") {
				model.showPips(true);
			}

			model.swapPips();
			api.camera.captureAnchor(magicPipAnchor);
			hoveringAlert = data;
			engine.call('camera.lookAt', JSON.stringify(target));
			model.swapPips();
		} else if (event.type === "mouseout") { // end hover
			mouseoutAlert();
		} else {
			var alert = model.unitAlertModel.map[data];
			if (event.shiftKey) {
				jumpTarget = alert.time;
				api.camera.captureAnchor(magicAnchor);
				inChronoView = true;
				model.showTimeControls(true);
			}
			var target = {
				location: alert.location,
				planet_id: alert.planet_id
			};

			engine.call('camera.lookAt', JSON.stringify(target));
		}
	};

	function mouseoutAlert() {
			model.swapPips();
			api.camera.recallAnchor(magicPipAnchor);
			hoveringAlert = undefined;
			model.swapPips();

			if(pipShowing === "hide") {
				model.showPips(false);
				pipShowing = "uninitialized";
			}
	}

	model.unitAlertModel.original_clean = model.unitAlertModel.clean;

		model.unitAlertModel.clean = function() {
			model.unitAlertModel.original_clean();

			if(!(hoveringAlert in model.unitAlertModel.map)) {
				mouseoutAlert();
			}
	};

	var markedIds = {};

	alertsManager.addListener(function(payload) {
		var markedHits = [];
		for (var i = 0; i < payload.list.length; i++) {
			var notice = payload.list[i];
			if (markedIds[notice.id]) {
				markedHits.push(notice);
			}
		}
		if (markedHits.length > 0) {
			alertsManager.getDisplayListener()({list: markedHits});
		}
	});

	Mousetrap.bind(alertsManagerSettings.getMarkKey(), function() {
		if (model.selection()) {
			var sel = model.selection().selectionResult;
			for (var i = 0; i < sel.length; i++) {
				markedIds[sel[i]] = true;
			}
		}
	});

	model.showTimeControls.subscribe(function(v) {
		if (!v) {
			inChronoView = false;
		}
	});

	Mousetrap.bind(alertsManagerSettings.getJumpKey(), function() {
		if (inChronoView) {
			api.camera.recallAnchor(magicAnchor);
			model.showTimeControls(false);
		}
	});
}());