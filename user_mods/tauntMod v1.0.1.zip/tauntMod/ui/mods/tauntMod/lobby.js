$(document).on('ready', function(){

	//Lobby
	$(".div_chat_feed").bind("DOMSubtreeModified", function(){

		var message = $($(this).children()[$(this).children().length - 1]).text().replace(/\s+/g, '').split(":")[1];

		//Make sure it doesn't get called twice
		if(message == undefined || message == "") return;
		if($('.chat_message_text:last').attr("tauntchecked") == "tauntchecked") return;
		$('.chat_message_text:last').attr("tauntchecked", "tauntchecked");

		//Find a taunt
		if(taunts[message]){

			//Play it
			taunts[message].play();
		}
	});
});