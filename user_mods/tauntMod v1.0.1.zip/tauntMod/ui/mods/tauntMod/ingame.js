$(document).on('ready', function(){

	//In-Game
	$(".div_chat_log_feed").bind("DOMSubtreeModified", function(){

		var message = $($(this).children()[$(this).children().length - 1]).text().replace(/\s+/g, '').split(":")[1];

		//Make sure it doesn't get called twice
		if(message == undefined || message == "") return;
		if($('.chat_message_body:last').attr("tauntchecked") == "tauntchecked") return;
		$('.chat_message_body:last').attr("tauntchecked", "tauntchecked");

		//Loop through all the words
		for(i in message.split(" ")){

			//Find a taunt
			if(taunts[message.split(" ")[i]]){

				//Play it
				taunts[message.split(" ")[i]].play();
			}
		}
	});

});