dPlayersInServerBrowser
======

Mod for Planetary Annihilation to see who is in a game without actually joining the lobby.
