(function () {
    //hotkey define
    action_sets.tAutoFactory = {};
    action_sets.tAutoFactory["Manually Execute"] = function(event) { tAutoFactory.manual(); };

    default_keybinds.tAutoFactory = {};
    default_keybinds.tAutoFactory["Manually Execute"] = "\\";
    
})();
