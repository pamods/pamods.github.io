(function() {
	$(".pip").wrap("<div id=\"draggable_pip\" data-bind=\"visible: showPips\"><div id=\"draggable_pip_content\"><div id=\"draggable_pip_content_inner\"></div><div id=\"draggable_pip_content_controls\"></div></div></div>");
	$("#draggable_pip_content_controls").append("<ul class=\"draggable_pip_controls_list\"><li class=\"draggable_pip_button draggable_pip_button_toggle\"><li class=\"draggable_pip_button draggable_pip_button_hide\"></li></ul>");

	createFloatingFrame("draggable_pip", 0, 0, {
		"rememberPosition" : false
	});

	var _left = $("body").width() - 354 - 10;
	var _top =  $("body").height() - 10 - 45;

	$("#draggable_pip").offset({
		"left": _left,
		"top": _top
	});

	$(".draggable_pip_button_hide").click(function() {
		model.showPips(false);
	});

	$(".draggable_pip_button_toggle").click(function() {
			model.swapPips();
	});
})();