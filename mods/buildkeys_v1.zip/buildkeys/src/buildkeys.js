function buildFromHotkey(event, id) {
	if (model.buildItems()[id]) {
		model.executeStartBuild(event, id);
	} else {
		gameConsole.log('could not build item ' + (id + 1));
	}
}

action_sets['gameplay']['build item 1'] = function (event) {buildFromHotkey(event, 0)};
action_sets['gameplay']['build item 2'] = function (event) {buildFromHotkey(event, 1)};
action_sets['gameplay']['build item 3'] = function (event) {buildFromHotkey(event, 2)};
action_sets['gameplay']['build item 4'] = function (event) {buildFromHotkey(event, 3)};
action_sets['gameplay']['build item 5'] = function (event) {buildFromHotkey(event, 4)};
action_sets['gameplay']['build item 6'] = function (event) {buildFromHotkey(event, 5)};
action_sets['gameplay']['build item 7'] = function (event) {buildFromHotkey(event, 6)};
action_sets['gameplay']['build item 8'] = function (event) {buildFromHotkey(event, 7)};

default_keybinds['gameplay']['build item 1'] = 'f1';
default_keybinds['gameplay']['build item 2'] = 'f2';
default_keybinds['gameplay']['build item 3'] = 'f3';
default_keybinds['gameplay']['build item 4'] = 'f4';
default_keybinds['gameplay']['build item 5'] = '';
default_keybinds['gameplay']['build item 6'] = '';
default_keybinds['gameplay']['build item 7'] = '';
default_keybinds['gameplay']['build item 8'] = '';
