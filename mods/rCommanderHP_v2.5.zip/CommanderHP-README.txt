Burntcustard is thinking that his name should go at the start of Author list now ;)


### HOW TO INSTALL IF DOWNLOADED OUTSIDE OF PA MOD MANAGER ###

- Install PA Mod Manager (PAMM).
- Extract the rCommanderHP folder to \Planetary Annihilation\PA\media\ui\mods\
- Run PAMM.
- Click "installed mods".
- Tick the Commander Health Display checkbox.
- Launch PA. You don't need to run PAMM every time, even if changing the mods options.


### HOW TO CONFIGURE OPTIONS ###

By default the commander HP bar will be displayed at all times, under the energy
and metal bars.

To move the HP bar to the top right of the screen:
Rename or remove rCommanderHP.css, then rename rCommander_side.css to rCommanderHP.css

To get the HP bar showing only when your commander is damaged:
Rename or remove rCommanderHP.js, then rename r_Commander_popup.js to rCommanderHP.js 