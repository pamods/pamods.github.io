$('body').append(
'<!-- ANCHOR BUTTONS -->' +
'<div class="div_anchor_buttons">' +
	'<div class="div_anchor_bar_camera">' +
		'<table>' +
			'<tbody>' +
				'<tr>' +			
				//data-bind="click: function() { $("div.div_anchor_bar_camera").toggleClass("div.div_anchor_bar_camera_hidden"); }"
				//Can't get the above code to work when shoved into a div, halp plz.
					'<td class="div_status_bar_endcap_flat right_flat"></td>' +
					'<td class="div_status_bar_midpsan" >' +
					//	'<div class="anchor_icon_arrow">' +
					//		'<img src="img/chronocam/arrow_right.png"/>' +
					//	'</div>' +
						'<div class="anchor_icon_camera">' +
							'<img src="img/build_bar/units/radar_satellite_adv.png"/>' +
						'</div>' +
					'</td>' +						
					'<td class="div_status_bar_midpsan"><div class="anchor_seperator"/></td>' +				
					'<td class="div_status_bar_midpsan">' +
						'<div class="div_anchor_cont">' +	
							'<a href="#" class="anchor"' + 
								'data-bind="click: function () { api.camera.recallAnchor(1); api.camera.captureAnchor(1); },' +
								'event: { contextmenu: function () { api.camera.captureAnchor(1); api.audio.playSound(\'/SE/UI/UI_Click\')} },' +
								'click_sound: \'default\',' +
								'rollover_sound: \'default\'">' +
								'<span class="anchor_text">1</span>' +
							'</a>' +
						'</div>' +
					'</td>' +				
					'<td class="div_status_bar_midpsan">' +
						'<div class="div_anchor_cont">' +	
							'<a href="#" class="anchor"' + 
								'data-bind="click: function () { api.camera.recallAnchor(2); api.camera.captureAnchor(2); },' +
								'event: { contextmenu: function () { api.camera.captureAnchor(2); api.audio.playSound(\'/SE/UI/UI_Click\')} },' +
								'click_sound: \'default\',' +
								'rollover_sound: \'default\'">' +
								'<span class="anchor_text">2</span>' +
							'</a>' +
						'</div>' +
					'</td>' +
					'<td class="div_status_bar_midpsan">' +
						'<div class="div_anchor_cont">' +	
							'<a href="#" class="anchor"' + 
								'data-bind="click: function () { api.camera.recallAnchor(3); api.camera.captureAnchor(3); },' +
								'event: { contextmenu: function () { api.camera.captureAnchor(3); api.audio.playSound(\'/SE/UI/UI_Click\')} },' +
								'click_sound: \'default\',' +
								'rollover_sound: \'default\'">' +
								'<span class="anchor_text">3</span>' +
							'</a>' +
						'</div>' +
					'</td>' +				
					'<td class="div_status_bar_midpsan">' +
						'<div class="div_anchor_cont">' +	
							'<a href="#" class="anchor"' + 
								'data-bind="click: function () { api.camera.recallAnchor(4); api.camera.captureAnchor(4); },' +
								'event: { contextmenu: function () { api.camera.captureAnchor(4); api.audio.playSound(\'/SE/UI/UI_Click\')} },' +
								'click_sound: \'default\',' +
								'rollover_sound: \'default\'">' +
								'<span class="anchor_text">4</span>' +
							'</a>' +
						'</div>' +
					'</td>' +
					'<td class="div_status_bar_midpsan">' +
						'<div class="div_anchor_cont">' +	
							'<a href="#" class="anchor"' + 
								'data-bind="click: function () { api.camera.recallAnchor(5); api.camera.captureAnchor(5); },' +
								'event: { contextmenu: function () { api.camera.captureAnchor(5); api.audio.playSound(\'/SE/UI/UI_Click\')} },' +
								'click_sound: \'default\',' +
								'rollover_sound: \'default\'">' +
								'<span class="anchor_text">5</span>' +
							'</a>' +
						'</div>' +
					'</td>' +				
					'<td class="div_status_bar_midpsan">' +
						'<div class="div_anchor_cont">' +	
							'<a href="#" class="anchor"' + 
								'data-bind="click: function () { api.camera.recallAnchor(6); api.camera.captureAnchor(6); },' +
								'event: { contextmenu: function () { api.camera.captureAnchor(6); api.audio.playSound(\'/SE/UI/UI_Click\')} },' +
								'click_sound: \'default\',' +
								'rollover_sound: \'default\'">' +
								'<span class="anchor_text">6</span>' +
							'</a>' +
						'</div>' +
					'</td>' +
					'<td class="div_status_bar_midpsan">' +
						'<div class="div_anchor_cont">' +	
							'<a href="#" class="anchor"' + 
								'data-bind="click: function () { api.camera.recallAnchor(7); api.camera.captureAnchor(7); },' +
								'event: { contextmenu: function () { api.camera.captureAnchor(7); api.audio.playSound(\'/SE/UI/UI_Click\')} },' +
								'click_sound: \'default\',' +
								'rollover_sound: \'default\'">' +
								'<span class="anchor_text">7</span>' +
							'</a>' +
						'</div>' +
					'</td>' +				
					'<td class="div_status_bar_midpsan">' +
						'<div class="div_anchor_cont">' +	
							'<a href="#" class="anchor"' + 
								'data-bind="click: function () { api.camera.recallAnchor(8); api.camera.captureAnchor(8); },' +
								'event: { contextmenu: function () { api.camera.captureAnchor(8); api.audio.playSound(\'/SE/UI/UI_Click\')} },' +
								'click_sound: \'default\',' +
								'rollover_sound: \'default\'">' +
								'<span class="anchor_text">8</span>' +
							'</a>' +
						'</div>' +
					'</td>' +	
					'<td class="div_status_bar_midpsan">' +
						'<div class="div_anchor_cont">' +	
							'<a href="#" class="anchor"' + 
								'data-bind="click: function () { api.camera.recallAnchor(9); api.camera.captureAnchor(9); },' +
								'event: { contextmenu: function () { api.camera.captureAnchor(9); api.audio.playSound(\'/SE/UI/UI_Click\')} },' +
								'click_sound: \'default\',' +
								'rollover_sound: \'default\'">' +
								'<span class="anchor_text">9</span>' +
							'</a>' +
						'</div>' +
					'</td>' +					
				'</tr>' +				
			'</tbody>' +
		'</table>' +			
	'</div>' +
/* --- UNIT ANCHOR/GROUPS BAR - Currently can't reassign groups so not used ---
	'<div class="div_anchor_bar_units" data-bind="visible: model.armySize() > 0">' +
		'<table>' +
			'<tbody>' +		
				'<tr>' +
					'<td class="div_status_bar_endcap_flat right_flat"></td>' +
					'<td class="div_status_bar_midpsan">' +
					//	'<div class="anchor_icon_arrow">' +
					//		'<img src="img/chronocam/arrow_right.png"/>' +
					//	'</div>' +	
						'<div class="anchor_icon_unit">' +
							'<img src="img/build_bar/units/tank_light_laser.png"/>' +
						'</div>' +
					'</td>' +
					'<td class="div_status_bar_midpsan"><div class="anchor_seperator"/></td>' +						
					'<td class="div_status_bar_midpsan">' +
						'<div class="div_anchor_cont">' +	
							'<a href="#" class="anchor" data-bind="click: function() { api.select.recallGroup(1); api.camera.track(true); api.select.captureGroup(1)},' +
								'click_sound: \'default\',' +
								'rollover_sound: \'default\'">' +
								'<span class="anchor_text">1</span>' +
							'</a>' +
						'</div>' +
					'</td>' +
					'<td class="div_status_bar_midpsan">' +
						'<div class="div_anchor_cont">' +	
							'<a href="#" class="anchor" data-bind="click: function() { api.select.recallGroup(2); api.camera.track(true); api.select.captureGroup(2)},' +
								'click_sound: \'default\',' +
								'rollover_sound: \'default\'">' +
								'<span class="anchor_text">2</span>' +
							'</a>' +
						'</div>' +
					'</td>' +
					'<td class="div_status_bar_midpsan">' +
						'<div class="div_anchor_cont">' +	
							'<a href="#" class="anchor" data-bind="click: function() { api.select.recallGroup(3); api.camera.track(true); api.select.captureGroup(3)},' +
								'click_sound: \'default\',' +
								'rollover_sound: \'default\'">' +
								'<span class="anchor_text">3</span>' +
							'</a>' +
						'</div>' +
					'</td>' +
					'<td class="div_status_bar_midpsan">' +
						'<div class="div_anchor_cont">' +	
							'<a href="#" class="anchor" data-bind="click: function() { api.select.recallGroup(4); api.camera.track(true); api.select.captureGroup(4)},' +
								'click_sound: \'default\',' +
								'rollover_sound: \'default\'">' +
								'<span class="anchor_text">4</span>' +
							'</a>' +
						'</div>' +
					'</td>' +
					'<td class="div_status_bar_midpsan">' +
						'<div class="div_anchor_cont">' +	
							'<a href="#" class="anchor" data-bind="click: function() { api.select.recallGroup(5); api.camera.track(true); api.select.captureGroup(5)},' +
								'click_sound: \'default\',' +
								'rollover_sound: \'default\'">' +
								'<span class="anchor_text">5</span>' +
							'</a>' +
						'</div>' +
					'</td>' +
					'<td class="div_status_bar_midpsan">' +
						'<div class="div_anchor_cont">' +	
							'<a href="#" class="anchor" data-bind="click: function() { api.select.recallGroup(6); api.camera.track(true); api.select.captureGroup(6)},' +
								'click_sound: \'default\',' +
								'rollover_sound: \'default\'">' +
								'<span class="anchor_text">6</span>' +
							'</a>' +
						'</div>' +
					'</td>' +
					'<td class="div_status_bar_midpsan">' +
						'<div class="div_anchor_cont">' +	
							'<a href="#" class="anchor" data-bind="click: function() { api.select.recallGroup(7); api.camera.track(true); api.select.captureGroup(7)},' +
								'click_sound: \'default\',' +
								'rollover_sound: \'default\'">' +
								'<span class="anchor_text">7</span>' +
							'</a>' +
						'</div>' +
					'</td>' +
					'<td class="div_status_bar_midpsan">' +
						'<div class="div_anchor_cont">' +	
							'<a href="#" class="anchor" data-bind="click: function() { api.select.recallGroup(8); api.camera.track(true); api.select.captureGroup(8)},' +
								'click_sound: \'default\',' +
								'rollover_sound: \'default\'">' +
								'<span class="anchor_text">8</span>' +
							'</a>' +
						'</div>' +
					'</td>' +
					'<td class="div_status_bar_midpsan">' +
						'<div class="div_anchor_cont">' +	
							'<a href="#" class="anchor" data-bind="click: function() { api.select.recallGroup(9); api.camera.track(true); api.select.captureGroup(9)},' +
								'click_sound: \'default\',' +
								'rollover_sound: \'default\'">' +
								'<span class="anchor_text">9</span>' +
							'</a>' +
						'</div>' +
					'</td>' +					
				'</tr>' +				
			'</tbody>' +
		'</table>' +
	'</div>' +
*/
'</div>');