// #00FF00 = vert
// #68c8f8 = bleu
// #F9EC31 = jaune
// #FF0000 = rouge
// #FF8000 = orange

// HTML over-write

	//Left Panel "Metal"
	var $leftPanel;
	$leftPanel='<td style="width: 48%; text-align: right">';
	$leftPanel+='<div style="float: right; margin-right: -5px;" class="receiveMouse">';
	$leftPanel+='<table>';
	$leftPanel+='<tbody>';
	$leftPanel+='<tr>';
	$leftPanel+='<td class="div_status_bar_endcap_angle left_angle"></td>';
	$leftPanel+='<td class="div_status_bar_midpsan">';
	$leftPanel+='<div class="category_icon_metal">';
	$leftPanel+='<img src="img/status_bar/icon_status_metal.png" />';
	$leftPanel+='</div>';
	$leftPanel+='</td>';
	$leftPanel+='<td class="div_status_bar_midpsan">';
	$leftPanel+='<div class="div_status_bar_display">';
	$leftPanel+='<div class="status_bar_frame">';
	$leftPanel+='<div class="status_bar_metal" data-bind="style: { width: metalFractionString() }">';
	$leftPanel+='</div>';
	$leftPanel+='</div>';
	$leftPanel+='<div class="status_stats">';
	$leftPanel+='<span id="Span1" data-bind="text: currentMetal">8888</span>/<span id="Span2" data-bind="text: maxMetal">8888</span>';
	$leftPanel+='</div>';
	$leftPanel+='</div>';
	$leftPanel+='</td>';
	$leftPanel+='<td class="div_status_bar_midpsan">';
	$leftPanel+='<div class="div_rate_ctr_cont_modified">';
	$leftPanel+='<div class="div_plusminus_rate_cont">';
	$leftPanel+='<div class="rate_stat rate_positive" id="Div1" data-bind="text: metalGain">+8888</div>';
	$leftPanel+='<div class="rate_stat rate_negative" id="Div2" data-bind="text: metalLoss">-8888</div>';
	$leftPanel+='</div>';
	$leftPanel+='<div class="div_rate_ctr_overall_metal" id="MetalNet" data-bind="text: metalNetString">+8888</div>';
	$leftPanel+='<div class="div_metal_ratio" id="Metal_Ratio">100%</div>';
	$leftPanel+='</div>';
	$leftPanel+='</td>';
	$leftPanel+='<td class="div_status_bar_endcap_flat left_flat"></td>';
	$leftPanel+='</tr>';
	$leftPanel+='</tbody>';
	$leftPanel+='</table>';
	$leftPanel+='</div>';
	$leftPanel+='</td>';
	$(".div_status_bar>table>tbody>tr>td:first").replaceWith($leftPanel);

	//Middle Panel "Efficiency"
	var $middlePanel;
	$middlePanel='<td style="width: 4%">';
	$middlePanel+='<div style="float: left" class="receiveMouse">';
	$middlePanel+='<table>';
	$middlePanel+='<tbody>';
	$middlePanel+='<tr>';
	$middlePanel+='<td class="div_status_bar_endcap_flat_middle right_flat_middle"></td>';
	$middlePanel+='<td class="div_status_bar_middle">';
	$middlePanel+='<div class="div_economy_efficiency" id="EcoEff">100%</div>';
	$middlePanel+='</td>';
	$middlePanel+='<td class="div_status_bar_endcap_flat_middle left_flat_middle"></td>';
	$middlePanel+='</tr>';
	$middlePanel+='</tbody>';
	$middlePanel+='</table>';
	$middlePanel+='</div>';
	$middlePanel+='</td>';
	$(".div_status_bar>table>tbody>tr>td:first").after($middlePanel );

	//Right Panel "Energy"	
	var $rightPanel;
	$rightPanel='<td style="width: 48%; text-align: left">';
	$rightPanel+='<div style="float: left; margin-left: -5px;" class="receiveMouse">';
	$rightPanel+='<table>';
	$rightPanel+='<tbody>';
	$rightPanel+='<tr>';
	$rightPanel+='<td class="div_status_bar_endcap_flat right_flat"></td>';
	$rightPanel+='<td class="div_status_bar_midpsan">';
	$rightPanel+='<div class="div_rate_ctr_cont_modified">';
	$rightPanel+='<div class="div_energy_ratio" id="Energy_Ratio">100%</div>';
	$rightPanel+='<div class="div_plusminus_rate_energy_cont">';
	$rightPanel+='<div class="rate_stat rate_positive" id="Div3" data-bind="text: energyGain">+7777</div>';
	$rightPanel+='<div class="rate_stat rate_negative" id="Div4" data-bind="text: energyLoss">-8888</div>';
	$rightPanel+='</div>';
	$rightPanel+='<div class="div_rate_ctr_overall_energy" id="EnergyNetKilo" </div>';                                           
	$rightPanel+='</div>';
	$rightPanel+='</td>';
	$rightPanel+='<td class="div_status_bar_midpsan">';
	$rightPanel+='<div class="div_status_bar_display">';
	$rightPanel+='<div class="status_bar_frame">';
	$rightPanel+='<div class="status_bar_energy" data-bind="style: { width: energyFractionString() }">';
	$rightPanel+='</div>';
	$rightPanel+='</div>';
	$rightPanel+='<div class="status_stats">';
	$rightPanel+='<span id="Span3" data-bind="text: currentEnergy">8888</span>/<span id="Span4" data-bind="text: maxEnergy">8888</span>';
	$rightPanel+='</div>';
	$rightPanel+='</div>';
	$rightPanel+='</td>';
	$rightPanel+='<td class="div_status_bar_midpsan">';                                           
	$rightPanel+='<div class="category_icon_energy">';
	$rightPanel+='<img src="img/status_bar/icon_status_energy.png"/>';
	$rightPanel+='</div>';
	$rightPanel+='</td>';
	$rightPanel+='<td class="div_status_bar_endcap_angle right_angle"></td>';
	$rightPanel+='</tr>';
	$rightPanel+='</tbody>';
	$rightPanel+='</table>';
	$rightPanel+='</div>';
	$rightPanel+='</td>';
	$(".div_status_bar>table>tbody>tr>td:last").replaceWith($rightPanel);	

// HTML elements	
var EnergyKilo = $('#EnergyNetKilo');
var Metal_Net = $('#MetalNet');
var Energy_Ratio = $('#Energy_Ratio');
var Metal_Ratio = $('#Metal_Ratio');
var Eco_Eff = $('#EcoEff');

// Number elements
var energyNetKilo;
var metalRatio;
var energyRatio;
var economyEfficiency;

// Colour elements
var energyColor;
var metalColor;

setInterval(function() {

// Value Management

	// Energy Kilo
	energyNetKilo = (Math.round(model.energyNet()/100))/10;

	// Metal Ratio
	metalRatio = Math.round((model.metalGain() / ((model.metalLoss()+0.01)))*100);	

	// Energy Ratio
	energyRatio = Math.round((model.energyGain() / ((model.energyLoss()+0.01)))*100);	

	// Economy Efficiency
	var mTemp = metalRatio;
	var eTemp = energyRatio;

	if (model.currentMetal()  > 2) {
		mTemp=100  ;
	}
	if (model.currentEnergy()  > 10) {
		eTemp=100  ;
	}
	economyEfficiency = Math.min(Math.min(mTemp,eTemp),100)

// Colour Management

	// Energy colour
	if (model.currentEnergy()==model.maxEnergy()) {
		if (energyRatio  >= 150) {
			energyColor = "#68c8f8";
		}else{
			if (energyRatio  >= 110) {
				energyColor = "#00FF00";
			}else{
				energyColor = "#F9EC31";
			}
		}
	}else{
		if (model.currentEnergy() >= 10) {
			if (energyRatio >= 110) {
			energyColor = "#00FF00";
			}else{
			energyColor = "#F9EC31";
			}
		}else{
			if (energyRatio > 90) {
				energyColor = "#FF8000";
			}else{			
				energyColor = "#FF0000";
			}
		}
	}
	// Metal colour
	if (model.currentMetal()==model.maxMetal()) {
	metalColor = "#68c8f8"  ;
	}else{	
		if (model.currentMetal() >= 1) {
			metalColor = "#00FF00"  ;
		}else{
			if (metalRatio  < 100 && metalRatio > 75 ) {
				metalColor = "#00FF00"  ;
			}			
			if (metalRatio  <= 75 && metalRatio > 50) {
				metalColor = "#F9EC31"  ;
			}
			if (metalRatio  <= 50 && metalRatio > 33) {
				metalColor = "#FF8000"  ;
			}
			if (metalRatio <= 33) {
				metalColor  = "#FF0000"  ;
			}
		}
	}	
	
// Link to HTML	
	EnergyKilo.html(energyNetKilo+'k');
	
	if (metalRatio<'999'){
		Metal_Ratio.html(metalRatio+'%');
	}else{
		Metal_Ratio.html('over');
	}
	
	if (energyRatio<'999'){
		Energy_Ratio.html(energyRatio+'%');
	}else{
		Energy_Ratio.html('over');
	}
	
	Eco_Eff.html(economyEfficiency+'%');	
	
	EnergyKilo.css("color", energyColor);
	Energy_Ratio.css("color", energyColor);
	Metal_Net.css("color", metalColor);
	Metal_Ratio.css("color", metalColor);
	
	if (metalRatio<energyRatio){
		Eco_Eff.css("color", metalColor);
	}else{
		Eco_Eff.css("color", energyColor);
	}
	
});




