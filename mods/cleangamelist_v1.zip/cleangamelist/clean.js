var oldUpdateTable = model.updateTable;
model.updateTable = function() {
	try {
		var input = model.currentUbernetGames;
		var goodLst = [];
		for (var i = 0; i < input.length; i++) {
			if (input[i][3] != 'Config' && input[i][4].substring(0, 2) != "0/" && input[i][4] != "1/1") {
				goodLst.push(input[i]);
			}
		}
		model.currentUbernetGames = goodLst;
	} catch (newPatchBrokeUs) { // make sure not to break everything with a new patch
	// as this all is very likely to be fixed soonish by Uber
		console.log(newPatchBrokeUs);
	} finally {
		oldUpdateTable();
	}
}