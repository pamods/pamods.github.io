 for (var i = 1; i < 10; i++) {
	 window.setTimeout(function() {
		if (model.holodeck.region.width === 0 || model.holodeck.region.height === 0) {
			console.log("apply blackscreen fix");
			model.holodeck.update();
		}
	 }, i*1000);
 }