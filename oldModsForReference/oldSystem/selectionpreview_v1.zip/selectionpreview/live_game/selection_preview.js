ko.bindingHandlers.hackVisible = {
    init: function(element, valueAccessor) {
        var value = valueAccessor();
        $(element).toggle(ko.utils.unwrapObservable(value));
    },
    update: function(element, valueAccessor) {
        var value = valueAccessor();
		if (ko.utils.unwrapObservable(value)) {
			previewIsVisible = true;
			$(element).toggle(true);
		} // hide is handled in the interval function at the end of this file
		// this is done to prevent a flickering preview while using shift
    }
};

var lastTimeActivated = new Date().getTime();

var html = '<div id="buildPreviewDiv" data-bind="hackVisible: fabModeSelected", style="position: absolute; left: 50%;bottom: 100px">  <div style="position: relative; left: -50%;"><img class="img_build_unit" src="img/build_bar/units/build_unit_sample.png" data-bind="attr: { src: previewIcon }" /></div></div>'
$('body').append(html);

model.previewIcon = ko.observable();

var oldExecuteStartBuild = model.executeStartBuild;
model.executeStartBuild = function(event, index) {
	var item = model.buildItems()[index];
	model.previewIcon(item.icon());
	oldExecuteStartBuild(event, index);
};

model.fabModeSelected = ko.computed(function() {
	return model.mode() === 'fab' ;
});

var previewIsVisible = false;

function checkIfVisibleExpired() {
	var dt = new Date().getTime();
	if(previewIsVisible && model.mode() !== 'fab' && dt - lastTimeActivated > 1000) {
		lastTimeActivated = dt;
		$('#buildPreviewDiv').toggle(false);
		previewIsVisible = false;
	}
}

setInterval(checkIfVisibleExpired, 500);